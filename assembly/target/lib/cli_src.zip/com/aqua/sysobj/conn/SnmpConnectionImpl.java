/*
 * Created on 19/07/2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package com.aqua.sysobj.conn;

/**
 * @author guy.arieli
 *
 */
public class SnmpConnectionImpl implements SnmpConnection {

}
