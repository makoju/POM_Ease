/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jsystem.j2autoit;

import java.io.File;
import java.io.FileInputStream;
import java.lang.instrument.IllegalClassFormatException;
import java.util.Properties;

/**
 * @author Kobi Gana
 *
 */
public enum AutoItProperties {
	
	AUTOIT_PROPERTIES_FILE_NAME("autoit.properties") {
		@Override
		public <E> E getMyValue(Class<E> clazz, E defaultValue) throws Exception {
			return null;
		}
	},
	DEBUG_MODE_KEY("debugMode") {
		@Override
		public <E> E getMyValue(Class<E> clazz, E defaultValue) throws Exception {
			if(clazz.equals(Boolean.class)){
				String value = properties.getProperty(getKey());
				if (value == null){
					return defaultValue;
				}
				Boolean boolValue = new ConvertBoolean().doConverationFromString(value);
				if(boolValue == null){
					return defaultValue;
				}
				return clazz.cast(boolValue);
			}
			throw new IllegalClassFormatException();
		}
	},
	AUTO_DELETE_TEMPORARY_SCRIPT_FILE_KEY("autoDeleteTemporaryScriptFile") {
		@Override
		public <E> E getMyValue(Class<E> clazz, E defaultValue) throws Exception {
			if(clazz.equals(Boolean.class)){
				String value = properties.getProperty(getKey());
				if (value == null){
					return defaultValue;
				}
				Boolean boolValue = new ConvertBoolean().doConverationFromString(value);
				if(boolValue == null){
					return defaultValue;
				}
				return clazz.cast(boolValue);
			}
			throw new IllegalClassFormatException();
		}
	},
	AUTO_IT_SCRIPT_HISTORY_SIZE_KEY("autoItScriptHistorySize") {
		@Override
		public <E> E getMyValue(Class<E> clazz, E defaultValue) throws Exception {
			if(clazz.equals(Integer.class)){
				String value = properties.getProperty(getKey());
				if (value == null){
					return defaultValue;
				}
				Integer intValue = new ConvertInteger().doConverationFromString(value);
				if(intValue == -1){
					return defaultValue;
				}
				return clazz.cast(intValue);
			}
			throw new IllegalClassFormatException();
		}
	},
	FORCE_AUTO_IT_PROCESS_SHUTDOWN_KEY("forceAutoItProcessShutdown") {
		@Override
		public <E> E getMyValue(Class<E> clazz, E defaultValue) throws Exception {
			if(clazz.equals(Boolean.class)){
				String value = properties.getProperty(getKey());
				if (value == null){
					return defaultValue;
				}
				Boolean boolValue = new ConvertBoolean().doConverationFromString(value);
				if(boolValue == null){
					return defaultValue;
				}
				return clazz.cast(boolValue);
			}
			throw new IllegalClassFormatException();
		}
	},
	AGENT_PORT_KEY("agentPort") {
		@Override
		public <E> E getMyValue(Class<E> clazz, E defaultValue) throws Exception {
			if(clazz.equals(Integer.class)){
				String value = properties.getProperty(getKey());
				if (value == null){
					return defaultValue;
				}
				Integer intValue = new ConvertInteger().doConverationFromString(value);
				if(intValue == -1){
					return defaultValue;
				}
				return clazz.cast(intValue);
			}
			throw new IllegalClassFormatException();
		}
	},
	SERVER_UP_ON_INIT_KEY("serverUpOnInit") {
		@Override
		public <E> E getMyValue(Class<E> clazz, E defaultValue) throws Exception {
			if(clazz.equals(Boolean.class)){
				String value = properties.getProperty(getKey());
				if (value == null){
					return defaultValue;
				}
				Boolean boolValue = new ConvertBoolean().doConverationFromString(value);
				if(boolValue == null){
					return defaultValue;
				}
				return clazz.cast(boolValue);
			}
			throw new IllegalClassFormatException();
		}
	};
	protected static Properties properties = new Properties();
	static{
		try {
			File file = new File(AutoItProperties.AUTOIT_PROPERTIES_FILE_NAME.getKey());
			if(file.exists()){
				
				FileInputStream fis = new FileInputStream(file);
				properties.load(fis);

			}
		} catch (Exception e) {
		}
	}
	public abstract <E> E getMyValue(Class<E> clazz, E defaultValue) throws Exception;
	private String key = null;
	AutoItProperties(String key){
		this.key = key;
	}
	public String getKey() {
		return key;
	}

}
abstract class Convert<T>{
	public abstract T doConverationFromString(String value) throws Exception; 
}
class ConvertInteger extends Convert<Integer>{
	@Override
	public Integer doConverationFromString(String value) throws Exception {
		try{
			return Integer.parseInt(value);
		} catch (Exception e) {
			return -1;
		}
	}
}
class ConvertBoolean extends Convert<Boolean>{
	@Override
	public Boolean doConverationFromString(String value) throws Exception {
		return Boolean.parseBoolean(value);
	}
}
