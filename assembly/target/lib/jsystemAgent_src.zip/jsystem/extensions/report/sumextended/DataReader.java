/*
 * Created on 20/04/2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.extensions.report.sumextended;

/**
 * @author uri.koaz
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public interface DataReader {

	public String getTitle(String key);

	public String getDescription(String key);

}
