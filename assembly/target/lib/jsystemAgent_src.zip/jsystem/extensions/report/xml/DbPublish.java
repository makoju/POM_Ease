/*
 * Created on Nov 30, 2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */

package jsystem.extensions.report.xml;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import jsystem.framework.DBProperties;
import jsystem.framework.report.Reporter;

import jsystem.runner.agent.publisher.PublisherProgress;
import jsystem.runner.agent.reportdb.TestInfo;
import jsystem.runner.agent.reportdb.tables.Package;
import jsystem.runner.agent.reportdb.tables.PropertiesList;
import jsystem.runner.agent.reportdb.tables.Run;
import jsystem.runner.agent.reportdb.tables.Test;
import jsystem.runner.agent.reportdb.tables.TestName;
import jsystem.runner.agent.reportdb.tables.TestProperties;
import jsystem.utils.FileUtils;
import jsystem.utils.StringUtils;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Give information about the run from the xml files
 * 
 * @author guy.arieli
 * 
 */
public class DbPublish implements ReportInformation {
	private static Logger log = Logger.getLogger(DbPublish.class.getName());

	File xmlDirectory;

	int numberOfTests = 0;

	int numberOfTestsPass = 0;

	int numberOfTestsFail = 0;

	int numberOfTestsWarning = 0;

	String version = null;

	String build = null;

	String userName = null;

	String scenarioName = null;

	String sutName = null;

	String station = null;

	long startTime = 0;

	Vector<TestInfo> tests;

	Vector<File> files;

	Connection connection;
	
	private Run run;

	public DbPublish(File xmlDirectory) throws Exception {
		this.xmlDirectory = xmlDirectory;
		initXmlFiles();
	}

	public Run getRunForForm(long reportIndex){
		run = new Run();
		run.setUser(getUserName());
		run.setVersion(getVersion());
		run.setSetupName(getSutName());

		run.setScenarioName(getSecnarioName().replace("\\", "\\\\"));

		run.setBuild(getBuild());
		run.setStation(getStation());
		run.setRunTests(getNumberOfTests());
		run.setFailTests(getNumberOfTestsFail());
		run.setSuccessTests(getNumberOfTestsPass());
		run.setWarningTests(getNumberOfTestsWarning());
		run.setStartTime(getStartTime());

		run.setHtmlDir("results/" + Long.toString(reportIndex));
		run.setIsDeleted(false);
		
		return run;
	}
	
	public int addRunInfo(long reportIndex, Connection conn) throws Exception {
		try {
			run.add(conn, true);
		} catch (SQLException e) {
			log.log(Level.WARNING, "fail to add entry to DB Table",e);
			return -1;
		}
		return run.getRunIndex();
	}

	@SuppressWarnings("unused")
	private void showMsgWithTime(String msg) {

		System.out.println(getTime() + " " + msg);
	}

	private String getTime() {
		Calendar cal = new GregorianCalendar();
		int hour24 = cal.get(Calendar.HOUR_OF_DAY); // 0..23
		int min = cal.get(Calendar.MINUTE); // 0..59
		int sec = cal.get(Calendar.SECOND); // 0..59
		return hour24 + ":" + min + ":" + sec;
	}

	public void publishTestsInfo(Connection conn, PublisherProgress progressBar, int runIndex) throws Exception {
		int currentProgres = 0;
		if (progressBar!=null) {
			currentProgres = progressBar.getMaxValue() / 2;
		}
		for (int i = 0; i < files.size(); i++) {
			Document doc = FileUtils.readDocumentFromFile((File) files.elementAt(i));
			NodeList elements = (NodeList) XPathAPI.selectNodeList(doc, "/reports/test");
			for (int index = 0; index < elements.getLength(); index++) {
				if (progressBar!=null) {
					progressBar.setBarValue(currentProgres);
					currentProgres = currentProgres + 2;
				}
				if (elements.item(index) instanceof Element) {
					Element e = (Element) elements.item(index);
					TestInfo info = new TestInfo();
					info.setName(e.getAttribute("name"));
					info.setPackageName(e.getAttribute("package"));

					String status = e.getAttribute("status");
					if (status.equals("true")) {
						info.setStatus(Reporter.PASS);
					} else if (status.equals("false")) {
						info.setStatus(Reporter.FAIL);
					} else {
						info.setStatus(Reporter.WARNING);
					}
					String startTime = e.getAttribute("startTime");
					if (startTime != null) {
						info.setStartTime(Long.parseLong(startTime));
					}
					String endTime = e.getAttribute("endTime");
					if (endTime != null) {
						try {
							// //// patch for runner halt bug ////////////

							if (endTime != "") {
								info.setEndTime(Long.parseLong(endTime));
							} else {
								info.setEndTime(1111111111111L);
							}
							// ////////////////////////////////////////////

						} catch (Throwable t) {
							log.log(Level.WARNING, "no endTime for test: " + e.getAttribute("name"), t);
						}
					}

					info.setFailCause(e.getAttribute("failCause"));
					info.setSteps(e.getAttribute("steps"));
					info.setDocumentation(e.getAttribute("documentaion"));
					info.setParams(e.getAttribute("params"));
					info.setCount(Integer.parseInt(e.getAttribute("count")));

					Test test = new Test();

					test.setStartTime(info.getStartTime());
					test.setEndTime(info.getEndTime());
					test.setSteps(info.getSteps());
					test.setDocumentation(info.getDocumentation());
					test.setFailCause(info.getFailCause());
					test.setRunIndex(runIndex);
					test.setStatus(info.getStatus());
					test.setGraphsXml(info.getGraphXml());
					test.setGraphsXml(info.getGraphXml());
					test.setCount(info.getCount());
					test.setParams(info.getParams());
					TestName tName = new TestName();
					// tName.checkExist(conn);
					tName.setTestName(info.getName());
					tName.add(conn, true);
					test.setTestId(tName.getTestId());

					// TODO: add Fail cause

					Package pName = new Package();
					pName.checkExist(conn);
					pName.setPackageName(info.getPackageName());
					pName.add(conn, true);
					test.setPackageId(pName.getPackageId());
					test.add(conn, true);

					int testIndex = test.getTestIndex();
					// publish tests properties
					String propertiesString = e.getAttribute("properties");
					Properties p = StringUtils.stringToProperties(propertiesString);
					Enumeration<?> keys = p.propertyNames();
					String key;
					while (keys.hasMoreElements()) {
						key = (String)keys.nextElement();
						publishPropertiesInfo(conn, testIndex, key, p.getProperty(key));
					}
				}
			}
		}
	}

	private void publishPropertiesInfo(Connection conn, int testIndex, String key, String val) throws Exception {
		TestProperties prop = new TestProperties();
		PropertiesList list = new PropertiesList();

		int propertyIndex = list.getIndexForKey(conn, key);

		prop.setTestIndex(testIndex);
		prop.setPropertyIndex(propertyIndex);
		prop.setPropertyValue(val);
		prop.add(conn, true);
	}

	private void initXmlFiles() throws Exception {
		tests = new Vector<TestInfo>();
		files = new Vector<File>();

		int i = 0;

		while (true) {
			File f = new File(xmlDirectory, "reports." + i + ".xml");
			if (!f.exists()) {
				if (i == 0) {
					throw new Exception("File not found: " + f.getPath());
				}
				return;
			}

			files.addElement(f);
			DocumentBuilder db;
			db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document doc = db.parse(f);

			if (i == 0) {
				sutName = ((Element) doc.getFirstChild()).getAttribute(DBProperties.SETUP);
				version = ((Element) doc.getFirstChild()).getAttribute(DBProperties.VERSION);
				userName = ((Element) doc.getFirstChild()).getAttribute("User");
				build = ((Element) doc.getFirstChild()).getAttribute(DBProperties.BUILD);
				scenarioName = ((Element) doc.getFirstChild()).getAttribute("Scenario");
				station = ((Element) doc.getFirstChild()).getAttribute(DBProperties.STATION);
				startTime = Long.parseLong(((Element) doc.getFirstChild()).getAttribute("startTime"));
			}
			i++;

			/**
			 * Convert the xmls files to vector of TestInfo
			 */
			NodeList elements = (NodeList) XPathAPI.selectNodeList(doc, "/reports/test");
			for (int index = 0; index < elements.getLength(); index++) {
				if (elements.item(index) instanceof Element) {
					numberOfTests++;

					Element e = (Element) elements.item(index);
					// Element p = (Element) e.getParentNode();

					String status = e.getAttribute("status");
					if (status.equals("true")) {
						numberOfTestsPass++;
					} else if (status.equals("false")) {
						numberOfTestsFail++;
					} else {
						numberOfTestsWarning++;
					}
					String startTime = e.getAttribute("startTime");
					if (startTime != null) {
						// info.setStartTime(Long.parseLong(startTime));
					}
					String endTime = e.getAttribute("endTime");
					if (endTime != null) {
						try {
							// //// patch for runner halt bug ////////////

							if (endTime != "") {
								// info.setEndTime(Long.parseLong(endTime));
							} else {
								// info.setEndTime(1111111111111L);
							}
							// ////////////////////////////////////////////

						} catch (Throwable t) {
							log.log(Level.WARNING, "no endTime for test: " + e.getAttribute("name"), t);
						}
					}
				}
			}
		}
	}

	public int getNumberOfTests() {
		return numberOfTests;
	}

	public int getNumberOfTestsPass() {
		return numberOfTestsPass;
	}

	public int getNumberOfTestsFail() {
		return numberOfTestsFail;
	}

	public int getNumberOfTestsWarning() {
		return numberOfTestsWarning;
	}

	public String getVersion() {
		return version;
	}

	public String getBuild() {
		return build;
	}

	public String getUserName() {
		return userName;
	}

	public String getSecnarioName() {
		return scenarioName;
	}

	public String getSutName() {
		return sutName;
	}

	public long getStartTime() {
		return startTime;
	}

	public String getTestClassName(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getPackageName();
	}

	public String getTestName(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getName();
	}

	public String getParams(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getParams();
	}

	public int getCount(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getCount();
	}

	public int getTestStatus(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getStatus();
	}

	public String getTestGraphXml(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getGraphXml();
	}

	public String getTestSteps(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getSteps();
	}

	public String getTestFailCause(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getFailCause();
	}

	public File[] getXmlFiles() {
		Object[] os = files.toArray();
		File[] fs = new File[os.length];
		System.arraycopy(os, 0, fs, 0, os.length);
		return fs;
	}

	public String getTestInfo(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).toString();
	}

	public static void main(String[] args) {
		try {
			DbPublish xml = new DbPublish(new File("C:\\work\\projects\\automation\\jsystem\\log\\current"));
			for (int i = 0; i < xml.getNumberOfTests(); i++) {
				log.log(Level.INFO, xml.getTestInfo(i));
			}
		} catch (Exception e) {
			log.log(Level.WARNING, "fail to publish to DB");
		}
	}

	public long getTestStartTime(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getStartTime();
	}

	public long getTestEndTime(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getEndTime();
	}

	public String getStation() {
		return station;
	}

	public void setStation(String station) {
		this.station = station;
	}

	public String getTestDocumentation(int testIndex) {
		return ((TestInfo) tests.elementAt(testIndex)).getDocumentation();
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
}
