/*
 * Created on Nov 30, 2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */

package jsystem.extensions.report.xml;

import java.sql.Connection;

/**
 * Define an interface into test group results
 * 
 * @author guy.arieli
 * 
 */
public interface ReportInformation {
	public int getNumberOfTests();

	public int getNumberOfTestsPass();

	public int getNumberOfTestsFail();

	public int getNumberOfTestsWarning();

	public String getVersion();

	public String getBuild();

	public String getUserName();

	public String getSecnarioName();

	public String getSutName();

	public long getStartTime();

	// public long getEndTime();
	public String getTestClassName(int testIndex);

	public String getTestName(int testIndex);

	public int getTestStatus(int testIndex);

	public String getTestSteps(int testIndex);

	public String getTestDocumentation(int testIndex);

	public String getTestFailCause(int testIndex);

	public long getTestStartTime(int testIndex);

	public long getTestEndTime(int testIndex);

	public int addRunInfo(long reportIndex, Connection conn) throws Exception;

}
