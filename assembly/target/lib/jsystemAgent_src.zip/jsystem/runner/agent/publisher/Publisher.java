/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.publisher;

/**
 * The publisher is used to manage the output results. You can move them to an
 * Ftp server like FtpPublisher or put them in an SQL server ...
 * 
 * @author guy.arieli
 * 
 */
public interface Publisher {
	/**
	 * publish the changed report
	 * 
	 */
	void publish();
}
