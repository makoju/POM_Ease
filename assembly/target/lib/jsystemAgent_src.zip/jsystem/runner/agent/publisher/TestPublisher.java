/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.publisher;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsystem.extensions.report.xml.DbPublish;
import jsystem.extensions.report.xml.XmlReporter;
import jsystem.framework.FrameworkOptions;
import jsystem.framework.JSystemProperties;
import jsystem.framework.report.ListenerstManager;
import jsystem.framework.report.Reporter;
import jsystem.framework.report.RunnerListenersManager;
import jsystem.framework.report.TestReporter;
import jsystem.runner.WaitDialog;
import jsystem.framework.DBProperties;
import jsystem.runner.agent.reportdb.tables.Package;
import jsystem.runner.agent.reportdb.tables.PropertiesList;
import jsystem.runner.agent.reportdb.tables.Run;
import jsystem.runner.agent.reportdb.tables.Step;
import jsystem.runner.agent.reportdb.tables.Test;
import jsystem.runner.agent.reportdb.tables.TestName;
import jsystem.runner.agent.reportdb.tables.TestProperties;
import jsystem.runner.agent.tests.PublishTest.ActionType;
import jsystem.runner.remote.RemoteTestRunner.RemoteMessage;
import jsystem.utils.StringUtils;
import jsystem.utils.UploadRunner;

/**
 * this class publish current scenario results to the database and to the web
 * server. jsystem use this class when the user add publish test (test that it's
 * job is to publish)
 * 
 * @author Yuval Ohayon
 * 
 */

public class TestPublisher implements Publisher {

	public static Reporter report = ListenerstManager.getInstance();

	boolean debug = true;

	private Run run;

	// Shows the progress of sending via FTP and storint in DB
	// private PublisherProgress progressBar;

	private static Logger log = Logger.getLogger(TestPublisher.class.getName());

	private DbPublish reportInfo;

	private long reportIndex;

	private static Connection conn;

	private UploadRunner uploader;

	private boolean withGUI = true;

	public Thread thread;

	/**
	 * publish the changed report
	 * 
	 * @param p
	 *            properties that contains all the test parameters : Description,
	 *            Setup Name,Version,Build
	 * @throws Exception
	 */
	public jsystem.runner.remote.Message publish(HashMap<String, Object> p) throws Exception {
		jsystem.runner.remote.Message m = null;
		
		((RunnerListenersManager) RunnerListenersManager.getInstance()).flush();
		
		ActionType at = ActionType.valueOf(p.get(DBProperties.ACTION_TYPE).toString());


		try {

			if (at == ActionType.publish || at == ActionType.publish_and_email) {
				createReport(p);
				m = generateRunDetailsMessage(true);
			} else { // if (at == ActionType.email) {
				m = generateRunDetailsMessage(false);
			}

			if (p.get(DBProperties.INIT_REPORT).toString().equalsIgnoreCase(Boolean.TRUE.toString())) {
				((RunnerListenersManager) RunnerListenersManager.getInstance()).initReporters();
			}

		} catch (Exception e) {
			String title = "Publish error- fail to connect to the Database";
			String msg = "Fail to connect to the Database\n\n" + "Try the following :\n\n" + "1)Check that Database Server is on\n\n"
					+ "2)Check You Database Properties \n\n" + StringUtils.getStackTrace(e);

			report.report(title, msg, false);
			m = generateRunDetailsMessage(false);
		}
		return m;

	}

	/**
	 * generates remote message to deliver to publish test. contains all the
	 * parameters that relevant for this scenario
	 * 
	 * @param isPublished
	 *            if false - send parameters only for email, if true - send all
	 *            parameters
	 * @return remote message
	 * @throws Exception
	 */
	private jsystem.runner.remote.Message generateRunDetailsMessage(boolean isPublished) throws Exception {

		File reportCurrent = new File(JSystemProperties.getInstance().getPreference(FrameworkOptions.LOG_FOLDER), "current");
		ArrayList<TestReporter> listeners = ((RunnerListenersManager) RunnerListenersManager.getInstance()).getAllReporters();
		for (int i = 0; i < listeners.size(); i++)
			if (listeners.get(i).getClass() == XmlReporter.class) {
				((XmlReporter) listeners.get(i)).readElements();
			}
		reportInfo = new DbPublish(reportCurrent);

		jsystem.runner.remote.Message m = new jsystem.runner.remote.Message();

		m.setType(RemoteMessage.M_PUBLISH);

		m.addField(reportInfo.getSecnarioName());
		m.addField(reportInfo.getSutName());
		m.addField(reportInfo.getVersion());
		m.addField(reportInfo.getBuild());
		m.addField(reportInfo.getUserName());
		m.addField(Long.toString(reportInfo.getStartTime())); // start time
		m.addField(Integer.toString(reportInfo.getNumberOfTests())); // run.getRunTests()
		m.addField(Integer.toString(reportInfo.getNumberOfTestsFail())); // run.getFailTests()
		m.addField(Integer.toString(reportInfo.getNumberOfTestsPass())); // run.getSuccessTests()
		m.addField(Integer.toString(reportInfo.getNumberOfTestsWarning())); // run.getWarningTests()
		m.addField(reportInfo.getStation()); // run.getWarningTests()

		if (isPublished) {
			m.addField(run.getDescription());
			m.addField(run.getHtmlDir());
			m.addField(Integer.toString(run.getRunIndex()));
		}
		return m;

	}
	/**
	 * create a publish form
	 * 
	 * @throws Exception
	 */
	private void createReport(HashMap<String, Object> p) throws Exception {

		reportIndex = System.currentTimeMillis();

		StringUtils.showMsgWithTime("publish.bypass = true");
		File reportCurrent = new File(JSystemProperties.getInstance().getPreference(FrameworkOptions.LOG_FOLDER), "current");
		ArrayList<TestReporter> listeners = ((RunnerListenersManager) RunnerListenersManager.getInstance()).getAllReporters();
		for (int i = 0; i < listeners.size(); i++)
			if (listeners.get(i).getClass() == XmlReporter.class) {
				((XmlReporter) listeners.get(i)).readElements();
			}
		reportInfo = new DbPublish(reportCurrent);

		/**
		 * display the Run Form
		 */
		run = reportInfo.getRunForForm(reportIndex);
		run.setDescription(p.get(DBProperties.DESCRIPTION).toString());
		run.setVersion(p.get(DBProperties.VERSION).toString());
		run.setBuild(p.get(DBProperties.BUILD).toString());
		run.setScenarioName(p.get(DBProperties.SCENARIO_NAME).toString());
		run.setStation(p.get(DBProperties.STATION).toString());
		run.setSetupName(p.get(DBProperties.SETUP).toString());
		startPublish();

		/**
		 * check if db.properties file exist
		 */

		// return;
		try {
			DBProperties.getInstance();
		} catch (Exception e) {
			throw new Exception(DBProperties.DB_PROPERTIES_FILE + " file wasn't found");
		}

	}

	/**
	 * start the publishing: a. zip and upload file b. publish to DB
	 * 
	 * @throws Exception
	 * 
	 */
	public void startPublish() throws Exception {
		checkDBConnection();
		/**
		 * first, check connection to DB and check that all tables exist conn
		 * will be null if no connection exists or tables were missing
		 */
		int numOfTests = reportInfo.getNumberOfTests() - 1;

		/**
		 * zip current log directory and try to upload false means fail to
		 * upload
		 */
		uploadFile(reportInfo, reportIndex);

		/**
		 * finally, if upload was successfull, add to db false means problem
		 * with insertion to DB
		 */

		writeToDB(reportInfo, reportIndex, conn, numOfTests);

		closeConnectionIfExists();
	}

	/**
	 * check if all tables exist
	 * 
	 * @param conn
	 *            the current Connection
	 */
	private boolean allNecessaryTablesCreated(Connection conn) {

		boolean allCreated = true;
		try {
			allCreated = new Run().check(conn) && new TestProperties().check(conn) && new Package().check(conn)
					&& new PropertiesList().check(conn) && new Step().check(conn) && new Test().check(conn) && new TestName().check(conn);
		} catch (SQLException e) {

			String title = "Publish error - couldn't check the tables";
			String msg = "Necessary Tables in DB were not created,please run the reports application first\n\n"
					+ StringUtils.getStackTrace(e);
				report.report(title, msg, false);

			return false;
		}
		return allCreated;
	}

	/**
	 * checks that there is a connection to the DB and that all necessary tables
	 * were created updates conn implemented as a thread because of the
	 * waitDialog
	 */

	private void checkDBConnection() throws Exception {
		closeConnectionIfExists();
		if (this.isWithGUI()) {
			WaitDialog.launchWaitDialog("Connecting to DB");
		}

		StringUtils.showMsgWithTime("creating connection to the database");

		try {
			conn = DBProperties.getInstance().getConnection();

		} catch (Throwable e) {
			conn = null;
			if (this.isWithGUI()) {
				WaitDialog.endWaitDialog();
			}
			StringUtils.showMsgWithTime("problem connecting to DB");

			String title = "Publish error- fail to connect to the Database";
			String msg = "Fail to connect to the Database\n\n" + "Try the following:\n\n" + "1) Check that The Database Server is on\n\n"
					+ "2) Check You Database Properties \n\n" + StringUtils.getStackTrace(e);

			handleException(e, title, msg);

			return;
		}

		if (!allNecessaryTablesCreated(conn)) {
			conn = null;
			if (this.isWithGUI()) {
				WaitDialog.endWaitDialog();
			}
			StringUtils.showMsgWithTime("problem connecting to DB");
			String title = "Publish error - missing tables in DB";
			String msg = "Necessary Tables in DB were not created,\n" + "please run the reports application first\n\n";

			handleException(new Exception(title + "\n\n" + msg), title, msg);

			return;
		}
		if (this.isWithGUI()) {
			WaitDialog.endWaitDialog();
		}
		StringUtils.showMsgWithTime("connection to db is ok");
	}

	/**
	 * zip and upload log files to server
	 * 
	 * 
	 * 1.You need to add to db.properties line serverIP="you server ip"
	 * 
	 * 2.If you server use port other than 8080 you must also change this in
	 * db.properties ->browser.port
	 * 
	 * 
	 * serverUploadUrl=http://"you server ip"/reports/upload
	 * 
	 * @throws Exception
	 * 
	 */
	private boolean uploadFile(DbPublish reportInfo, long reportIndex) throws Exception {
		File tempDir = new File(JSystemProperties.getInstance().getPreference(FrameworkOptions.LOG_FOLDER));

		File tempCurrentDir = new File(tempDir, "current");
		uploader = new UploadRunner(tempCurrentDir, reportIndex);

		StringUtils.showMsgWithTime("Uploading file to reports Server");

		try {
			uploader.zipFile();
		} catch (Exception e) {

			String title = "Publish error- fail to zip file for publishing";
			String msg = "check that there is enought space for zipping\n\n" + StringUtils.getStackTrace(e);

			handleException(e, title, msg);

			return false;
		}

		try {
			uploader.upload();
		} catch (Throwable e) {

			String title = "Publish error- fail to upload file to reports server";
			String msg = "check that the reports server is running\n\n" + StringUtils.getStackTrace(e);
			handleException(e, title, msg);

			return false;
		}
		return true;
	}

	/**
	 * handle exception according to the user selection if
	 * throwExceptionToUser=true, open gui window with the exception if
	 * throwExceptionToUser=false, the publish test fails, and it continue to
	 * the next tests
	 * 
	 * @param e
	 * @param title
	 * @param msg
	 * @throws Exception
	 */
	private void handleException(Throwable e, String title, String msg) throws Exception {
		report.report(title, msg, false);
		throw new Exception(e);
	}

	/**
	 * write all data to DB
	 * 
	 * @param reportInfo
	 *            the DbPublish object
	 * @param reportIndex
	 *            the long id of the report
	 * @param conn
	 *            the connection to the DB
	 * @param numOfTests
	 *            the number of tests to publish
	 * @return true if all succeeded
	 * @throws Exception
	 */
	private boolean writeToDB(DbPublish reportInfo, long reportIndex, Connection conn, int numOfTests) throws Exception {
		try {

			StringUtils.showMsgWithTime("creating report information from xml files");
			System.out.println(conn);
			System.out.println(reportIndex);
			final int runIndex = reportInfo.addRunInfo(reportIndex, conn);
			System.out.println(runIndex);
			if (runIndex == -1) {

				return false;
			}

			// publish tests info

			reportInfo.publishTestsInfo(conn, null, runIndex);

			StringUtils.showMsgWithTime("setings tests data");
			StringUtils.showMsgWithTime("finished processing tests information for publish");

			/**
			 * close PublisherRunInfoFrame
			 */

//			MenuBuilder.getInstance(null).menuItemPublish.setEnabled(true);
			StringUtils.showMsgWithTime("finished publishing");
			log.log(Level.FINEST, "finished publishing");
			return true;

		} catch (Exception e) {

			String title = "Publish error- fail to to connect to the Database";
			String msg = "Fail to connect to the Database\n\n" + "Try the following :\n\n" + "1)Check that Database Server is on\n\n"
					+ "2)Check You Database Properties \n\n" + StringUtils.getStackTrace(e);

			handleException(e, title, msg);

		}
		return false;
	}

	public void closeConnectionIfExists() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				log.log(Level.WARNING, "problem closing connection to DB");
			}
		}
	}

	public void publish() {
		// not relevant in this class, here we use publish(HashMap<String,
		// Object> p)

	}

	public boolean isWithGUI() {
		return withGUI;
	}

	public void setWithGUI(boolean withGUI) {
		this.withGUI = withGUI;
	}

}