/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.reportdb;

import jsystem.framework.report.Reporter;
import jsystem.runner.agent.reportdb.tables.SqlField;
import jsystem.runner.agent.reportdb.tables.SqlObject;

public class OnlineRun extends SqlObject {
	public static final int TYPE_START_TEST = 0;

	public static final int TYPE_END_TEST = 1;

	public static final int TYPE_START_RUN = 2;

	public static final int TYPE_END_RUN = 3;

	public static final int TYPE_REPORT = 4;

	public static final int TYPE_START_SECTION = 5;

	public static final int TYPE_END_SECTION = 6;

	public static final int TYPE_SAVE_FILE = 7;

	public static final int TYPE_SET_DATA = 8;

	SqlField runIndex;

	SqlField stepIndex;

	SqlField type;

	SqlField title;

	SqlField message;

	SqlField status;

	SqlField bold;

	SqlField html;

	SqlField link;

	SqlField count;

	SqlField parameters;

	public OnlineRun() {
		super("onlinerun");
		runIndex = new SqlField(null, "runIndex", SqlField.INTEGER);
		stepIndex = new SqlField(null, "stepIndex", SqlField.INT_AUTO_INCREMENT);
		stepIndex.setPrimery(true);
		stepIndex.setIgnoreOnAdd(true);
		type = new SqlField(null, "type", SqlField.INTEGER);
		title = new SqlField(null, "title", SqlField.VARCHAR_256);
		message = new SqlField(null, "message", SqlField.TEXT_LARGE);
		status = new SqlField(null, "status", SqlField.SMALL_INT);
		bold = new SqlField("0", "bold", SqlField.SMALL_INT);
		html = new SqlField("0", "html", SqlField.SMALL_INT);
		link = new SqlField("0", "link", SqlField.SMALL_INT);
		count = new SqlField(null, "count", SqlField.INTEGER);
		parameters = new SqlField(null, "parameters", SqlField.VARCHAR_8192);

		fields = new SqlField[11];
		fields[0] = runIndex;
		fields[1] = stepIndex;
		fields[2] = type;
		fields[3] = title;
		fields[4] = message;
		fields[5] = status;
		fields[6] = bold;
		fields[7] = html;
		// fields[8] = endTime;
		fields[8] = link;
		fields[9] = count;
		fields[10] = parameters;

	}

	public OnlineRun(int runIndex, int type) {
		this();
		setRunIndex(runIndex);
		setType(type);
		// setStepIndex(stepIndex);
		setStatus(Reporter.PASS);
		setBold(false);
		setHtml(false);
		setLink(false);
		setCount(0);
		setParameters("");
	}

	public boolean getBold() {
		if (Integer.parseInt(bold.getValue().toString()) == 0)
			return false;
		else
			return true;
	}

	public void setBold(boolean bold) {
		if (bold)
			this.bold.setValue("1");
		else
			this.bold.setValue("0");
	}

	public boolean getHtml() {
		if (Integer.parseInt(html.getValue().toString()) == 0)
			return false;
		else
			return true;
	}

	public void setHtml(boolean html) {
		if (html)
			this.html.setValue("1");
		else
			this.html.setValue("0");
	}

	public boolean getLink() {
		if (Integer.parseInt(link.getValue().toString()) == 0)
			return false;
		else
			return true;
	}

	public void setLink(boolean link) {
		if (link)
			this.link.setValue("1");
		else
			this.link.setValue("0");
	}

	public String getMessage() {
		return message.getValue().toString();
	}

	public void setMessage(String message) {
		this.message.setValue(message);
	}

	public String getParameters() {
		return parameters.getValue().toString();
	}

	public void setParameters(String parameters) {
		this.parameters.setValue(parameters);
	}

	public int getRunIndex() {
		return Integer.parseInt(runIndex.getValue().toString());
	}

	public void setRunIndex(int runIndex) {
		this.runIndex.setValue(Integer.toString(runIndex));
	}

	public int getStatus() {
		return Integer.parseInt(status.getValue().toString());
	}

	public void setStatus(int status) {
		this.status.setValue(Integer.toString(status));
	}

	public String getTitle() {
		return title.getValue().toString();
	}

	public void setTitle(String title) {
		this.title.setValue(title);
	}

	public int getType() {
		return Integer.parseInt(type.getValue().toString());
	}

	public void setType(int type) {
		this.type.setValue(Integer.toString(type));
	}

	public void setCount(int count2) {
		this.count.setValue(Integer.toString(count2));
	}

	public void setStepIndex(int index) {
		this.stepIndex.setValue(Integer.toString(index));
	}
}
