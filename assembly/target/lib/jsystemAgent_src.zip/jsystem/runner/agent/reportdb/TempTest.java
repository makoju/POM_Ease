/*
 * Created on Aug 22, 2005
 * 
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.reportdb;

import java.sql.Connection;
import java.sql.DriverManager;

import jsystem.runner.agent.reportdb.tables.Run;

/**
 * @author YoramS
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class TempTest {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection conn = DriverManager
					.getConnection("jdbc:mysql://localhost/jsystem?user=root&password=jsystem01");
			Run r = new Run();
			r.checkExist(conn);
			r.setDescription("Run description");
			// r.setEndTime(System.currentTimeMillis());
			r.setFailTests(7);
			r.setRunTests(45);
			r.setSetupName("setup1");
			r.setStartTime(System.currentTimeMillis() - 5000000);
			r.setStation("xxx");
			r.setUser(System.getProperty("user.name"));
			r.setVersion("3.5");
			r.setBuild("b1456");
			r.add(conn, false);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
