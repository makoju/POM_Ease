/*
 * Created on Sep 2, 2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.reportdb.tables;

import java.sql.Connection;
import java.sql.SQLException;

import jsystem.framework.DBProperties;

/**
 * @author guy.arieli
 * 
 */
public class Package extends SqlObject {
	SqlField packageId = null;

	SqlField packageName = null;

	SqlField packageDescription = null;

	/**
	 */
	public Package() {
		super("package_description");
		packageId = new SqlField(null, "packageId", SqlField.INT_AUTO_INCREMENT);
		packageId.setPrimery(true);
		packageId.setIgnoreOnAdd(true);
		packageName = new SqlField(null, "packageName", SqlField.VARCHAR_256);
		packageDescription = new SqlField(null, "packageDescription", SqlField.VARCHAR_2048);
		fields = new SqlField[3];
		fields[0] = packageId;
		fields[1] = packageName;
		fields[2] = packageDescription;
	}

	public void add(Connection conn, boolean ignore) throws SQLException {

		stmt = conn.createStatement();
		rs = stmt.executeQuery("SELECT " + packageId.getFieldName() + " FROM " + tableName + " WHERE "
				+ packageName.getFieldName() + "='" + packageName.getValue() + "'");

		if (rs.next()) { // as values
			setPackageId(rs.getInt(1));
			rs.close();
			return;
		}
		rs.close();
		stmt.close();
		super.add(conn, false);

		String getLastID = null;
		if (getDbType(conn) == DBProperties.DB_TYPE_MYSQL)
			getLastID = "SELECT LAST_INSERT_ID()";
		else if (getDbType(conn) == DBProperties.DB_TYPE_ORACLE)
			getLastID = "select " + getTableName() + "_SEQUENCE.currval from dual";

		rs = stmt.executeQuery(getLastID);
		// Developing Applications with MySQL and Java using Connector/
		// J8
		if (rs.next()) {
			packageId.setValue(Integer.toString(rs.getInt(1)));
		} else {
			// throw an exception from here
		}
		rs.close();
		stmt.close();
	}

	public String getPackageDescription() {
		return packageDescription.getValue().toString();
	}

	public void setPackageDescription(String packageDescription) {
		this.packageDescription.setValue(packageDescription);
	}

	public int getPackageId() {
		return Integer.parseInt(packageId.getValue().toString());
	}

	public void setPackageId(int packageId) {
		this.packageId.setValue(Integer.toString(packageId));
	}

	public String getPackageName() {
		return packageName.getValue().toString();
	}

	public void setPackageName(String packageName) {
		this.packageName.setValue(packageName);
	}
}
