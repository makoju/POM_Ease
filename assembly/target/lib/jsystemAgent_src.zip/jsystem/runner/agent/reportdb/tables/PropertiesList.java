package jsystem.runner.agent.reportdb.tables;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import jsystem.framework.DBProperties;

/**
 * an sql object for the properties_list table
 * @author nizanf
 *
 */
public class PropertiesList extends SqlObject {

	SqlField propertyId = null;

	SqlField propertyKey = null;

	public PropertiesList() {
		super("properties_list");
		propertyId = new SqlField(null, "propertyId", SqlField.INT_AUTO_INCREMENT);
		propertyId.setPrimery(true);
		propertyId.setIgnoreOnAdd(true);
		propertyKey = new SqlField(null, "propertyKey", SqlField.VARCHAR_256);

		fields = new SqlField[2];
		fields[0] = propertyId;
		fields[1] = propertyKey;
	}

	public PropertiesList(ResultSet rs) throws SQLException {
		this();
		setPropertyId(rs.getInt("propertyId"));
		setPropertyKey(rs.getString("propertyKey"));
	}

	public void add(Connection conn, boolean ignore) throws SQLException {
		super.add(conn, false);
		String getLastID = null;
		if (getDbType(conn) == DBProperties.DB_TYPE_MYSQL)
			getLastID = "SELECT LAST_INSERT_ID()";
		else if (getDbType(conn) == DBProperties.DB_TYPE_ORACLE)
			getLastID = "select " + getTableName() + "_SEQUENCE.currval from dual";
		System.out.println(getLastID);
		rs = stmt.executeQuery(getLastID);

		if (rs.next()) {
			propertyId.setValue(Integer.toString(rs.getInt(1)));
		} else {
			// throw an exception from here
		}
		rs.close();
		stmt.close();
	}

	/**
	 * @return Returns the propertyId.
	 */
	public int getPropertyId() {
		return Integer.parseInt(propertyId.getValue().toString());
	}

	/**
	 * @param propertyId
	 *            The property id set.
	 */
	public void setPropertyId(int propertyId) {
		this.propertyId.setValue(Integer.toString(propertyId));
	}

	/**
	 * 
	 * @return the property key
	 */
	public String getPropertyKey() {
		return this.propertyKey.getValue().toString();
	}

	/**
	 * 
	 * @param propertyKey 
	 * 			  the property key to set
	 */
	public void setPropertyKey(String propertyKey) {
		this.propertyKey.setValue(propertyKey);
	}
	
	/**
	 * search db for the property index if exists
	 * return -1 if new key
	 * @param key
	 * 			property key to search for
	 * @return
	 * 			property index/-1 if not found
	 * @throws SQLException 
	 */
	public int getIndexForKey(Connection conn,String key) throws SQLException{
		String getIndex = null;
		if (getDbType(conn) == DBProperties.DB_TYPE_MYSQL)
			getIndex = "SELECT p.propertyId FROM properties_list p WHERE p.propertyKey = \""+key+"\";";
		else if (getDbType(conn) == DBProperties.DB_TYPE_ORACLE)
			getIndex = "select " + getTableName() + "_SEQUENCE.currval from dual";
		//System.out.println(getIndex);
		stmt = conn.createStatement();
		rs = stmt.executeQuery(getIndex);

		int index = 0;
		if (rs.next()) {
			index = rs.getInt(1);
		} else {
			setPropertyKey(key);
			add(conn, false);
			index = getPropertyId();
		}
		rs.close();
		stmt.close();
		
		return index;
	}
	
}
