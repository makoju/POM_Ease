/*
 * Created on Aug 22, 2005
 * 
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.reportdb.tables;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import jsystem.framework.DBProperties;


/**
 * RunIndex - a run unique index. Setup - the setup name. Version - used for sw
 * version. build - used for hw version. Station - the runner station ip
 * address. User - the runner station user name. StartTime - run start time.
 * EndTime - run end time. RunTests - number of run tests. FailTests - number of
 * fail tests.
 * 
 * @author YoramS
 * 
 */
public class Run extends SqlObject {
	SqlField runIndex = null;

	SqlField scenarioName = null;

	SqlField description = null;

	SqlField setupName = null;

	SqlField version = null;

	SqlField build = null;

	SqlField station = null;

	SqlField user = null;

	SqlField startTime = null;

	SqlField runTests = null;

	SqlField failTests = null;

	SqlField successTests = null;

	SqlField warningTests = null;

	SqlField htmlDir = null;

	SqlField isDeleted = null;

	SqlField lastUpdate = null;

	public Run() {
		super("published_runs_01");
		runIndex = new SqlField(null, "runIndex", SqlField.INT_AUTO_INCREMENT);
		runIndex.setPrimery(true);
		runIndex.setIgnoreOnAdd(true);
		scenarioName = new SqlField(null, "scenarioName", SqlField.VARCHAR_256);
		setupName = new SqlField(null, "setupName", SqlField.VARCHAR_256);
		version = new SqlField(null, "version", SqlField.VARCHAR_64);
		build = new SqlField(null, "build", SqlField.VARCHAR_64);
		station = new SqlField(null, "station", SqlField.VARCHAR_64);
		user = new SqlField(null, "user_r", SqlField.VARCHAR_64);
		startTime = new SqlField(null, "startTime", SqlField.DATE);
		runTests = new SqlField(null, "runTest", SqlField.INTEGER);
		failTests = new SqlField(null, "failTests", SqlField.INTEGER);
		successTests = new SqlField(null, "successTests", SqlField.INTEGER);
		warningTests = new SqlField(null, "ignoreTests", SqlField.INTEGER);
		description = new SqlField(null, "description", SqlField.VARCHAR_2048);
		htmlDir = new SqlField(null, "htmlDir", SqlField.VARCHAR_256);
		isDeleted = new SqlField(null, "isDeleted", SqlField.SMALL_INT);
		lastUpdate = new SqlField(null, "lastUpdate", SqlField.DATE);

		fields = new SqlField[16];
		fields[0] = runIndex;
		fields[1] = scenarioName;
		fields[2] = setupName;
		fields[3] = version;
		fields[4] = build;
		fields[5] = station;
		fields[6] = user;
		fields[7] = startTime;
		fields[8] = runTests;
		fields[9] = failTests;
		fields[10] = successTests;
		fields[11] = warningTests;
		fields[12] = description;
		fields[13] = htmlDir;
		fields[14] = isDeleted;
		fields[15] = lastUpdate;
		setLastUpdate(System.currentTimeMillis());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jsystem.extensions.report.db.SqlObject#add(java.sql.Connection)
	 */
	public void add(Connection conn, boolean ignore) throws SQLException {
		super.add(conn, false);
		// Use the MySQL LAST_INSERT_ID()
		// function to do the same thing as getGeneratedKeys()
		//
		// select PUBLISHED_RUNS_01_SEQUENCE .currval from dual;
		String getLastID = null;
		if (getDbType(conn) == DBProperties.DB_TYPE_MYSQL)
			getLastID = "SELECT LAST_INSERT_ID()";
		else if (getDbType(conn) == DBProperties.DB_TYPE_ORACLE)
			getLastID = "select " + getTableName() + "_SEQUENCE.currval from dual";
		// @ TODO change it to regular select with last word
		System.out.println(getLastID);
		rs = stmt.executeQuery(getLastID);

		// Developing Applications with MySQL and Java using Connector/
		// J
		// 8
		if (rs.next()) {
			runIndex.setValue(Integer.toString(rs.getInt(1)));
		} else {
			// throw an exception from here
		}
		rs.close();
		stmt.close();
	}

	/**
	 * @return Returns the failTests.
	 */
	public int getFailTests() {
		return Integer.parseInt(failTests.getValue().toString());
	}

	/**
	 * @param failTests
	 *            The failTests to set.
	 */
	public void setFailTests(int failTests) {
		this.failTests.setValue(Integer.toString(failTests));
	}

	/**
	 * @return Returns the runIndex.
	 */
	public int getRunIndex() {
		return Integer.parseInt(runIndex.getValue().toString());
	}

	/**
	 * @param runIndex
	 *            The runIndex to set.
	 */
	public void setRunIndex(int runIndex) {
		this.runIndex.setValue(Integer.toString(runIndex));
	}

	/**
	 * @return Returns the runTests.
	 */
	public int getRunTests() {
		return Integer.parseInt(runTests.getValue().toString());
	}

	/**
	 * @param runTests
	 *            The runTests to set.
	 */
	public void setRunTests(int runTests) {
		this.runTests.setValue(Integer.toString(runTests));
	}

	/**
	 * @return Returns the success tests.
	 */
	public int getSuccessTests() {
		return Integer.parseInt(successTests.getValue().toString());
	}

	/**
	 * @param successTests
	 *            The success tests to set.
	 */
	public void setSuccessTests(int successTests) {
		this.successTests.setValue(Integer.toString(successTests));
	}

	/**
	 * @return Returns the warning tests.
	 */
	public int getWarningTests() {
		return Integer.parseInt(warningTests.getValue().toString());
	}

	/**
	 * @param warning
	 *            The warning tests to set.
	 */
	public void setWarningTests(int warning) {
		this.warningTests.setValue(Integer.toString(warning));
	}

	/**
	 * @return Returns the setupName.
	 */
	public String getSetupName() {
		return setupName.getValue().toString();
	}

	/**
	 * @param setupName
	 *            The setupName to set.
	 */
	public void setSetupName(String setupName) {
		this.setupName.setValue(setupName);
	}

	/**
	 * @return Returns the startTime.
	 */
	public long getStartTime() {
		return ((Timestamp) startTime.getValue()).getTime();
	}

	/**
	 * @param startTime
	 *            The startTime to set.
	 */
	public void setStartTime(long startTime) {
		this.startTime.setValue(new Timestamp(startTime));
	}

	/**
	 * @return Returns the station.
	 */
	public String getStation() {
		return station.getValue().toString();
	}

	/**
	 * @param station
	 *            The station to set.
	 */
	public void setStation(String station) {
		this.station.setValue(station);
	}

	/**
	 * @return Returns the user.
	 */
	public String getUser() {
		return user.getValue().toString();
	}

	/**
	 * @param user
	 *            The user to set.
	 */
	public void setUser(String user) {
		this.user.setValue(user);
	}

	/**
	 * @return Returns the version.
	 */
	public String getVersion() {
		return version.getValue().toString();
	}

	/**
	 * @param version
	 *            The version to set.
	 */
	public void setVersion(String version) {
		this.version.setValue(version);
	}

	/**
	 * @return Returns the build.
	 */
	public String getBuild() {
		return build.getValue().toString();
	}

	/**
	 * @param build
	 *            The build to set.
	 */
	public void setBuild(String build) {
		this.build.setValue(build);
	}

	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description.getValue().toString();
	}

	/**
	 * @param description
	 *            The description to set.
	 */
	public void setDescription(String description) {
		this.description.setValue(description);
	}

	public void setHtmlDir(String htmlDir) {
		this.htmlDir.setValue(htmlDir);
	}

	public String getHtmlDir() {
		return this.htmlDir.getValue().toString();
	}

	public void setScenarioName(String scenario) {
		this.scenarioName.setValue(scenario);
	}

	public String getScenarioName() {
		return this.scenarioName.getValue().toString();
	}

	public boolean getIsDeleted() {
		if (Integer.parseInt(isDeleted.getValue().toString()) == 0)
			return false;
		else
			return true;
	}

	public void setIsDeleted(boolean isDeleted) {
		if (isDeleted == true)
			this.isDeleted.setValue("1");
		else
			this.isDeleted.setValue("0");
	}

	public String getUpdateWhere() {
		return runIndex.getFieldName() + " = " + runIndex.toSqlString();
	}

	/**
	 * @return Returns the startTime.
	 */
	public long getLastUpdate() {
		return ((Timestamp) lastUpdate.getValue()).getTime();
	}

	/**
	 * @param startTime
	 *            The startTime to set.
	 */
	public void setLastUpdate(long startTime) {
		this.lastUpdate.setValue(new Timestamp(startTime));
	}

	public static Run fromResultSet(ResultSet rs) throws SQLException {
		Run r = new Run();
		r.setRunIndex(rs.getInt("runIndex"));
		r.setScenarioName(rs.getString("scenarioName"));
		r.setSetupName(rs.getString("setupName"));
		r.setVersion(rs.getString("version"));
		r.setBuild(rs.getString("build"));
		r.setStation(rs.getString("station"));
		r.setUser(rs.getString("user"));
		Date d = rs.getDate("startTime");
		if (d != null) {
			r.setStartTime(d.getTime());
		}
		r.setRunTests(rs.getInt("RunTest"));
		r.setFailTests(rs.getInt("failTests"));
		r.setSuccessTests(rs.getInt("successTests"));
		r.setWarningTests(rs.getInt("ignoreTests"));
		r.setDescription(rs.getString("description"));
		r.setHtmlDir(rs.getString("htmlDir"));
		if (rs.getInt("isDeleted") == 0) {
			r.setIsDeleted(false);
		}

		return r;
	}

}
