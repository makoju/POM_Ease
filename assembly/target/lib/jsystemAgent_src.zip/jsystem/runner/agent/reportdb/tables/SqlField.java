/*
 * Created on Aug 22, 2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.reportdb.tables;

import java.sql.SQLException;

import jsystem.framework.DBProperties;

/**
 * @author YoramS
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class SqlField {
	public static final int VARCHAR_64 = 0;

	public static final int VARCHAR_256 = 1;

	public static final int INTEGER = 2;

	public static final int BIGINT = 3;

	public static final int INT_AUTO_INCREMENT = 4;

	public static final int DATE = 5;

	public static final int VARCHAR_2048 = 6;

	public static final int VARCHAR_8192 = 7;

	public static final int SMALL_INT = 8;

	public static final int TEXT = 9;

	public static final int TEXT_LARGE = 10;

	Object value;

	int type;

	String fieldName;

	boolean ignoreOnAdd = false;

	boolean primery = false;

	String[][] allDBTypes = null;

	// int identity(1,1) not null

	protected String[] TYPES_STRING = null;

	public SqlField() {
		if (TYPES_STRING != null)
			return;

		allDBTypes = new String[3][];

		allDBTypes[DBProperties.DB_TYPE_MYSQL] = new String[] { "varchar(64)", "varchar(256)", "INTEGER", "BIGINT",
				"INT NOT NULL AUTO_INCREMENT", "TIMESTAMP", "varchar(2048)", "varchar(8192)", "SMALLINT", "TEXT",
				"LONGTEXT" };

		allDBTypes[DBProperties.DB_TYPE_ORACLE] = new String[] {

		"VARCHAR2(64)", "VARCHAR2(256)", "NUMBER", "INTEGER(40)", // 40 digits
																	// number
				"INT NOT NULL", // PRBLEM HERE IN ORACLE
				// CREATE TABLE SYSTEM.aaaaaaa
				// (
				// aaaa VARCHAR2(1) NOT NULL,
				// CONSTRAINT PK_aaaaaaa PRIMARY KEY (aaaa )
				// )
				//

				"TIMESTAMP", // OR DATE
				"VARCHAR2(2048)", "VARCHAR2(4000)", "SMALLINT", "TEXT", // ??????????
				"LONGTEXT" // ???????/
		};

		allDBTypes[DBProperties.DB_TYPE_MS_SQL] = new String[] { "VARCHAR(64)", "VARCHAR(256)", "INT", "BIGINT",
				"INT IDENTITY NOT NULL", "DATETIME", // OR DATE
				"VARCHAR(2048)", "VARCHAR(8192)", "SMALLINT", "TEXT", // ??????????
				"TEXT" // ???????/
		};

		try {
			TYPES_STRING = allDBTypes[DBProperties.getInstance().getDbType()];
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @return Returns the primery.
	 */
	public boolean isPrimery() {
		return primery;
	}

	/**
	 * @param primery
	 *            The primery to set.
	 */
	public void setPrimery(boolean primery) {
		this.primery = primery;
	}

	/**
	 * @return Returns the ignoreOnAdd.
	 */
	public boolean isIgnoreOnAdd() {
		return ignoreOnAdd;
	}

	/**
	 * @param ignoreOnAdd
	 *            The ignoreOnAdd to set.
	 */
	public void setIgnoreOnAdd(boolean ignoreOnAdd) {
		this.ignoreOnAdd = ignoreOnAdd;
	}

	public SqlField(Object value, String fieldName, int type) {
		this();
		this.value = value;
		this.fieldName = fieldName;
		this.type = type;
	}

	/**
	 * @return Returns the fieldName.
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName
	 *            The fieldName to set.
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return Returns the type.
	 */
	public int getType() {
		return type;
	}

	/**
	 * @param type
	 *            The type to set.
	 */
	public void setType(int type) {
		this.type = type;
	}

	public String getTypeAsString() {
		return TYPES_STRING[type];
	}

	/**
	 * @return Returns the value.
	 */
	public Object getValue() {
		if (value == null) {
			value = "";
		}
		return value;
	}

	/**
	 * @param value
	 *            The value to set.
	 */
	public void setValue(Object value) {
		this.value = value;
	}

	public String toString() {
		return value.toString();
	}

	public String toSqlString() {
		switch (type) {
		case VARCHAR_64:
		case VARCHAR_256:
		case VARCHAR_2048:
		case VARCHAR_8192:
		case TEXT:
		case TEXT_LARGE:
			fixLength();
			return "'" + toString().replaceAll("\\'", "-") + "'";
		case DATE:
			fixLength();
			String ret = toString().replaceAll("\\'", "-");
			return "'" + ret.substring(0, ret.indexOf(".")) + "'";// ,'2006-08-15
																	// 17:43:19.125'
		default:
			return toString().replaceAll("\\'", "-");
		}
	}

	private void fixLength() {
		switch (type) {
		case VARCHAR_64:
			if (toString().length() > 64) {
				value = value.toString().substring(0, 58) + "...";
			}
		case VARCHAR_256:
			if (toString().length() > 256) {
				value = value.toString().substring(0, 250) + "...";
			}
		case VARCHAR_2048:
			if (toString().length() > 2048) {
				value = value.toString().substring(0, 2042) + "...";
			}
		case VARCHAR_8192:
			if (toString().length() > 8192) {
				value = value.toString().substring(0, 8186) + "...";
			}
		case TEXT:
		case DATE:
		default:
		}
	}

	public static void main(String[] args) {
		System.out.println("xxx'xxx".replaceAll("\\'", "d"));
	}
}
