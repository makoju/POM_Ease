/*
 * Created on Aug 22, 2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.reportdb.tables;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsystem.framework.DBProperties;

/**
 * @author YoramS
 * 
 */
public abstract class SqlObject {

	private static Logger log = Logger.getLogger(SqlObject.class.getName());

	protected String tableName;

	protected SqlField[] fields;

	protected Statement stmt = null;

	protected ResultSet rs = null;

	protected int dbType = -1;

	public SqlObject(String tableName) {
		String dbType;
		try {
			dbType = DBProperties.getInstance().getProperty("db.type");
			if (dbType.equals("oracle")) {
				String databaseName = DBProperties.getInstance().getProperty("db.dbname");
				this.tableName = databaseName + "." + tableName;
			} else {
				this.tableName = tableName;
			}
		} catch (Exception e) {
			log.log(Level.SEVERE, "Failed to read database params from property file");
		}
	}

	public String getTableName() {
		return tableName;
	}

	/**
	 * add raw to the table.
	 * 
	 * @param conn
	 * @param closeStatements
	 * @throws SQLException
	 */
	public void add(Connection conn, boolean closeStatements) throws SQLException {

		// Create a Statement instance that we could use for
		// 'normal' result sets.
		stmt = conn.createStatement();

		// Insert one row that will generate an AUTO INCREMENT
		// key in the 'priKey' field
		StringBuffer sqlCommand = new StringBuffer();
		sqlCommand.append("INSERT INTO "); // SQL insert command
		sqlCommand.append(getTableName());
		sqlCommand.append(" (");

		boolean isFirst = true;

		for (int i = 0; i < fields.length; i++) {
			if (fields[i].ignoreOnAdd || fields[i].getValue() == null) {
				continue;
			}
			if (!isFirst) {
				sqlCommand.append(" ,");
			}
			sqlCommand.append(fields[i].getFieldName());
			isFirst = false;
			/**
			 * Don't add it in the last field
			 */
		}
		sqlCommand.append(") VALUES (");
		isFirst = true;
		for (int i = 0; i < fields.length; i++) {
			if (fields[i].ignoreOnAdd || fields[i].getValue() == null) {
				continue;
			}
			if (!isFirst) {
				sqlCommand.append(" ,");
			}
			isFirst = false;
			if ((fields[i].getType() == SqlField.DATE) && (this.getDbType(conn) == DBProperties.DB_TYPE_ORACLE)) {
				sqlCommand.append("to_date(" + fields[i].toSqlString() + ",'yyyy-mm-dd hh24:mi:ss')");
			} else {
				sqlCommand.append(fields[i].toSqlString());
			}

		}
		sqlCommand.append(")");

		// excute SQL command
		String update = sqlCommand.toString();
		stmt.executeUpdate(update);
		if (closeStatements) {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
	}

	protected int getDbType(Connection conn) throws SQLException {
		String vendor = null;
		if (dbType == -1) {
			DatabaseMetaData meta = conn.getMetaData();
			vendor = meta.getDatabaseProductName();

			if (vendor.equalsIgnoreCase("MySQL"))
				dbType = DBProperties.DB_TYPE_MYSQL;
			if (vendor.equalsIgnoreCase("Oracle"))

				dbType = DBProperties.DB_TYPE_ORACLE;
			if (vendor.equalsIgnoreCase("microsoft sql"))
				dbType = DBProperties.DB_TYPE_MS_SQL;
		}

		return dbType;
	}

	private void addSequenceAndTrigger(int primeryIndex) throws SQLException {

		StringBuffer sqlCommand = new StringBuffer();
		sqlCommand.append("CREATE SEQUENCE ");
		sqlCommand.append(getTableName());
		sqlCommand.append("_sequence ");
		sqlCommand.append("START WITH 1 INCREMENT BY 1");
		stmt.executeUpdate(sqlCommand.toString());

		sqlCommand = new StringBuffer();
		sqlCommand.append("CREATE OR REPLACE TRIGGER ");
		sqlCommand.append(getTableName());
		sqlCommand.append("_trigger ");
		sqlCommand.append("BEFORE INSERT ON ");
		sqlCommand.append(getTableName());
		sqlCommand.append(" REFERENCING NEW AS NEW FOR EACH ROW ");
		sqlCommand.append("BEGIN SELECT ");
		sqlCommand.append(getTableName());
		sqlCommand.append("_sequence.nextval");
		sqlCommand.append(" INTO :NEW.");
		sqlCommand.append(fields[primeryIndex].getFieldName());
		sqlCommand.append(" FROM dual; END;");
		System.out.println(sqlCommand.toString());
		stmt.executeUpdate(sqlCommand.toString());

		// ,'2006-08-15 17:43:19.125'

		// sqlCommand.append(".ID FROM dual;");
		// .ID FROM dual;");
		// CREATE OR REPLACE TRIGGER test_trigger
		// BEFORE INSERT
		// ON test
		// REFERENCING NEW AS NEW
		// FOR EACH ROW
		// BEGIN
		// SELECT test_sequence.nextval INTO :NEW.ID FROM dual;
		// END;
	}

	private void createTableInDB(Connection conn) throws Exception {
		StringBuffer sqlCommand = new StringBuffer();
		sqlCommand.append("CREATE TABLE ");
		sqlCommand.append(getTableName());
		sqlCommand.append(" ( ");
		int primeryIndex = -1;
		for (int i = 0; i < fields.length; i++) {
			if (fields[i].isPrimery()) {
				primeryIndex = i;
			}
			sqlCommand.append(fields[i].getFieldName());
			sqlCommand.append(" ");
			sqlCommand.append(fields[i].getTypeAsString());
			if (i != (fields.length - 1)) {
				sqlCommand.append(", ");
			}
		}
		if (primeryIndex >= 0) {
			if (DBProperties.getInstance().getDbType() == DBProperties.DB_TYPE_MYSQL) {
				sqlCommand.append(", ");
				sqlCommand.append("PRIMARY KEY (");
				sqlCommand.append(fields[primeryIndex].getFieldName());
				sqlCommand.append(")");
			}
			if (DBProperties.getInstance().getDbType() == DBProperties.DB_TYPE_ORACLE) {
				sqlCommand.append(", CONSTRAINT PK_");
				sqlCommand.append(fields[primeryIndex].getFieldName());
				sqlCommand.append(" PRIMARY KEY (");
				sqlCommand.append(fields[primeryIndex].getFieldName());
				sqlCommand.append(")");
			}
		}
		sqlCommand.append(")");
		if (DBProperties.getInstance().getDbType() == DBProperties.DB_TYPE_ORACLE) {
			sqlCommand.append("tablespace ");
			sqlCommand.append(DBProperties.getInstance().getProperty("db.dbname"));
			sqlCommand.append("_DATA storage (initial 64K minextents 1 maxextents unlimited)");
		}

		stmt.executeUpdate(sqlCommand.toString());

		if (DBProperties.getInstance().getDbType() == DBProperties.DB_TYPE_ORACLE) {
			addSequenceAndTrigger(primeryIndex);
		}
	}

	/**
	 * check if the table exists - creats if not
	 * @param conn
	 * @throws SQLException
	 */
	public void checkExist(Connection conn) throws SQLException {
		stmt = conn.createStatement();
		try {
			try {
				rs = stmt.executeQuery("SELECT * from " + getTableName());

				/**
				 * Scan all fields to check if exists. If not create them.
				 */
				for (int i = 0; i < fields.length; i++) {
					try {
						stmt.executeQuery("SELECT " + fields[i].getFieldName() + " from " + getTableName());
					} catch (Exception e1) {
						StringBuffer addCoulmnCommand = new StringBuffer();
						addCoulmnCommand.append("alter table ");
						addCoulmnCommand.append(getTableName());
						addCoulmnCommand.append(" add column ");
						addCoulmnCommand.append(fields[i].getFieldName() + " ");
						addCoulmnCommand.append(fields[i].getTypeAsString());

						stmt.executeUpdate(addCoulmnCommand.toString());
					}
				}

				return;
			} catch (Exception e) {

			}

			createTableInDB(conn);

		} catch (Exception e) {
			System.out.println(e.getStackTrace());
			e.printStackTrace();
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		}
	}

	/**
	 * checks that table was constructed - doesn't create one if not
	 * @param conn
	 * @throws SQLException
	 */
	public boolean check(Connection conn) throws SQLException {
		stmt = conn.createStatement();
		try {
			rs = stmt.executeQuery("SELECT count(*) from " + getTableName());
			/**
			 * Scan all fields to check if exists.
			 */
			for (int i = 0; i < fields.length; i++) {
				try {
					stmt.executeQuery("SELECT count(" + fields[i].getFieldName() + ") from " + getTableName());
				} catch (Exception e1) {
					return false;
				}
			}
		} catch (Exception e) {
			return false;
		}finally {
			stmt.close();
		}
		return true;

	}

	public void update(Connection conn) throws SQLException {
		stmt = conn.createStatement();
		StringBuffer sqlCommand = new StringBuffer();
		sqlCommand.append("UPDATE ");
		sqlCommand.append(getTableName());
		sqlCommand.append(" SET ");

		boolean isFirst = true;

		for (int i = 0; i < fields.length; i++) {
			if (fields[i].ignoreOnAdd || fields[i].getValue() == null) {
				continue;
			}
			if (!isFirst) {
				sqlCommand.append(" ,");
			}
			sqlCommand.append(fields[i].getFieldName());
			sqlCommand.append(" = ");
			sqlCommand.append(fields[i].toSqlString());

			isFirst = false;
			/**
			 * Don't add it in the last field
			 */
		}
		sqlCommand.append(" WHERE ");
		sqlCommand.append(getUpdateWhere());
		stmt.executeUpdate(sqlCommand.toString());
	}

	public String getUpdateWhere() {
		return null;
	}
}
