/*
 * Created on Aug 23, 2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.reportdb.tables;

import java.sql.Timestamp;


/**
 * @author YoramS TestName - test class name. MethodName - the test method name.
 *         RunIndex - the run index as defined in the runs table. TestIndex -
 *         the test index in the run. Title - the report title. Message - the
 *         report message. Status - the report status. IsBold - is the report
 *         bold. Time - report time.
 * 
 */
public class Step extends SqlObject {
	public static final int STATUS_FALSE = 0;

	public static final int STATUS_TRUE = 1;

	public static final int STATUS_WARNING = 2;

	SqlField stepIndex = null;

	SqlField testIndex = null;

	SqlField title = null;

	SqlField message = null;

	SqlField status = null;

	SqlField isBold = null;

	SqlField time = null;

	public Step() {
		super("published_step_01");
		stepIndex = new SqlField(null, "stepIndex", SqlField.INT_AUTO_INCREMENT);
		testIndex = new SqlField(null, "testIndex", SqlField.INTEGER);
		stepIndex.setIgnoreOnAdd(true);
		stepIndex.setPrimery(true);
		title = new SqlField(null, "title", SqlField.VARCHAR_2048);
		message = new SqlField(null, "message", SqlField.VARCHAR_2048);
		status = new SqlField(null, "status", SqlField.SMALL_INT);
		isBold = new SqlField(null, "isBold", SqlField.SMALL_INT);
		time = new SqlField(null, "time", SqlField.DATE);

		fields = new SqlField[7];
		fields[0] = stepIndex;
		fields[1] = testIndex;
		fields[2] = title;
		fields[3] = message;
		fields[4] = status;
		fields[5] = isBold;
		fields[6] = time;
	}

	/**
	 * @return Returns the isBold.
	 */
	public int getIsBold() {
		return Integer.parseInt(isBold.getValue().toString());
	}

	/**
	 * @param isBold
	 *            The isBold to set.
	 */
	public void setIsBold(int isBold) {
		this.isBold.setValue(Integer.toString(isBold));
	}

	/**
	 * @return Returns the message.
	 */
	public String getMessage() {
		return message.getValue().toString();
	}

	/**
	 * @param message
	 *            The message to set.
	 */
	public void setMessage(String message) {
		this.message.setValue(message);
	}

	/**
	 * @return Returns the status.
	 */
	public int getStatus() {
		return Integer.parseInt(status.getValue().toString());
	}

	/**
	 * @param status
	 *            The status to set.
	 */
	public void setStatus(int status) {
		this.status.setValue(Integer.toString(status));
	}

	/**
	 * @return Returns the stepIndex.
	 */
	public int getStepIndex() {
		return Integer.parseInt(stepIndex.getValue().toString());
	}

	/**
	 * @param stepIndex
	 *            The stepIndex to set.
	 */
	public void setStepIndex(int stepIndex) {
		this.stepIndex.setValue(Integer.toString(stepIndex));
	}

	/**
	 * @return Returns the testIndex.
	 */
	public int getTestIndex() {
		return Integer.parseInt(testIndex.getValue().toString());
	}

	/**
	 * @param testIndex
	 *            The testIndex to set.
	 */
	public void setTestIndex(int testIndex) {
		this.testIndex.setValue(Integer.toString(testIndex));
	}

	/**
	 * @return Returns the time.
	 */
	public long getTime() {
		return ((Timestamp) time.getValue()).getTime();
	}

	/**
	 * @param time
	 *            The time to set.
	 */
	public void setTime(long time) {
		this.time.setValue(new Timestamp(time));
	}

	/**
	 * @return Returns the title.
	 */
	public String getTitle() {
		return title.getValue().toString();
	}

	/**
	 * @param title
	 *            The title to set.
	 */
	public void setTitle(String title) {
		this.title.setValue(title);
	}

}
