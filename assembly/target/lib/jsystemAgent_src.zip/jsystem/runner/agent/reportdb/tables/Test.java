/*
 * Created on Aug 23, 2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.reportdb.tables;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;

import jsystem.framework.DBProperties;

/**
 * @author YoramS
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class Test extends SqlObject {
	SqlField testIndex = null;

	SqlField runIndex = null;

	SqlField packageId = null;

	SqlField testId = null;

	SqlField message = null;

	SqlField status = null;

	SqlField startTime = null;

	SqlField endTime = null;

	SqlField steps = null;

	SqlField failCause = null;

	SqlField documentation = null;

	SqlField graphsXml = null;

	SqlField params = null;

	SqlField count = null;

	public Test() {
		super("published_test_01");
		testIndex = new SqlField(null, "testIndex", SqlField.INT_AUTO_INCREMENT);
		testIndex.setIgnoreOnAdd(true);
		testIndex.setPrimery(true);
		runIndex = new SqlField(null, "runIndex", SqlField.INTEGER);
		packageId = new SqlField(null, "testPackage", SqlField.INTEGER);
		testId = new SqlField(null, "testName", SqlField.INTEGER);
		message = new SqlField(null, "message", SqlField.VARCHAR_256);
		status = new SqlField(null, "status", SqlField.SMALL_INT);
		startTime = new SqlField(null, "startTime", SqlField.DATE);
		endTime = new SqlField(null, "endTime", SqlField.DATE);
		steps = new SqlField(null, "steps", SqlField.VARCHAR_8192);
		failCause = new SqlField(null, "failCause", SqlField.VARCHAR_8192);
		documentation = new SqlField(null, "documentation", SqlField.VARCHAR_8192);
		graphsXml = new SqlField(null, "grpahsXml", SqlField.VARCHAR_8192);
		params = new SqlField(null, "params", SqlField.VARCHAR_2048);
		count = new SqlField(null, "count", SqlField.INTEGER);

		fields = new SqlField[14];
		fields[0] = testIndex;
		fields[1] = runIndex;
		fields[2] = packageId;
		fields[3] = testId;
		fields[4] = message;
		fields[5] = status;
		fields[6] = startTime;
		fields[7] = endTime;
		fields[8] = steps;
		fields[9] = failCause;
		fields[10] = documentation;
		fields[11] = graphsXml;
		fields[12] = params;
		fields[13] = count;
	}

	public void add(Connection conn, boolean ignore) throws SQLException {
		super.add(conn, false);
		// Use the MySQL LAST_INSERT_ID()
		// function to do the same thing as getGeneratedKeys()
		//
		String getLastID = null;
		if (getDbType(conn) == DBProperties.DB_TYPE_MYSQL)
			getLastID = "SELECT LAST_INSERT_ID()";
		else if (getDbType(conn) == DBProperties.DB_TYPE_ORACLE)
			getLastID = "select " + getTableName() + "_SEQUENCE.currval from dual";

		rs = stmt.executeQuery(getLastID);
		// Developing Applications with MySQL and Java using Connector/
		// J
		// 8
		if (rs.next()) {
			testIndex.setValue(Integer.toString(rs.getInt(1)));
		} else {
			// throw an exception from here
		}
		rs.close();
		stmt.close();
	}

	/**
	 * @return graphs as xml string.
	 */
	public String getGraphsXml() {
		return (String) graphsXml.getValue();
	}

	/**
	 * set value for graphsXml.
	 * 
	 * @param graphsXml
	 */
	public void setGraphsXml(String graphsXml) {
		this.graphsXml.setValue(graphsXml);
	}

	/**
	 * @return Returns the endTime.
	 */
	public long getEndTime() {
		return ((Timestamp) endTime.getValue()).getTime();
	}

	/**
	 * @param endTime
	 *            The endTime to set.
	 */
	public void setEndTime(long endTime) {
		this.endTime.setValue(new Timestamp(endTime));
	}

	/**
	 * @return Returns the message.
	 */
	public String getMessage() {
		return message.getValue().toString();
	}

	/**
	 * @param message
	 *            The message to set.
	 */
	public void setMessage(String message) {
		this.message.setValue(message);
	}

	/**
	 * @return Returns the runIndex.
	 */
	public int getRunIndex() {
		return Integer.parseInt(runIndex.getValue().toString());
	}

	/**
	 * @param runIndex
	 *            The runIndex to set.
	 */
	public void setRunIndex(int runIndex) {
		this.runIndex.setValue(Integer.toString(runIndex));
	}

	/**
	 * @return Returns the startTime.
	 */
	public long getStartTime() {
		return ((Timestamp) startTime.getValue()).getTime();
	}

	/**
	 * @param startTime
	 *            The startTime to set.
	 */
	public void setStartTime(long startTime) {
		this.startTime.setValue(new Timestamp(startTime));
	}

	/**
	 * @return Returns the status.
	 */
	public int getStatus() {
		return Integer.parseInt(status.getValue().toString());
	}

	/**
	 * @param status
	 *            The status to set.
	 */
	public void setStatus(int status) {
		this.status.setValue(Integer.toString(status));
	}

	/**
	 * @return Returns the testIndex.
	 */
	public int getTestIndex() {
		return Integer.parseInt(testIndex.getValue().toString());
	}

	/**
	 * @param testIndex
	 *            The testIndex to set.
	 */
	public void setTestIndex(int testIndex) {
		this.testIndex.setValue(Integer.toString(testIndex));
	}

	/**
	 * @return Returns the testName.
	 */
	public int getTestId() {
		return Integer.parseInt(testId.getValue().toString());
	}

	/**
	 * @param testId
	 *            The testName to set.
	 */
	public void setTestId(int testId) {
		this.testId.setValue(Integer.toString(testId));
	}

	/**
	 * @return Returns the testPackage.
	 */
	public int getPackageId() {
		return Integer.parseInt(packageId.getValue().toString());
	}

	/**
	 * @param packageId
	 *            The testPackage to set.
	 */
	public void setPackageId(int packageId) {
		this.packageId.setValue(Integer.toString(packageId));
	}

	public String getDocumentation() {
		if (documentation.getValue() == null) {
			return null;
		}
		return documentation.getValue().toString();
	}

	public void setDocumentation(String documentation) {
		this.documentation.setValue(documentation);
	}

	public String getFailCause() {
		if (failCause.getValue() == null) {
			return null;
		}
		return failCause.getValue().toString();
	}

	public void setFailCause(String failCause) {
		this.failCause.setValue(failCause);
	}

	public String getSteps() {
		if (steps.getValue() == null) {
			return null;
		}
		return steps.getValue().toString();
	}

	public void setSteps(String steps) {
		this.steps.setValue(steps);
	}

	public String getParams() {
		if (params.getValue() == null) {
			return null;
		}
		return params.getValue().toString();
	}

	public void setParams(String params) {
		this.params.setValue(params);
	}

	public int getCount() {
		return Integer.parseInt(count.getValue().toString());
	}

	public void setCount(int count) {
		this.count.setValue(Integer.toString(count));
	}
}
