/*
 * Created on Sep 2, 2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */

package jsystem.runner.agent.reportdb.tables;

import java.sql.Connection;
import java.sql.SQLException;

import jsystem.framework.DBProperties;

/**
 * @author guy.arieli
 * 
 */
public class TestName extends SqlObject {
	SqlField testId = null;

	SqlField testName = null;

	SqlField testDescription = null;

	/**
	 */
	public TestName() {
		super("test_description");
		testId = new SqlField(null, "testId", SqlField.INT_AUTO_INCREMENT);
		testId.setPrimery(true);
		testId.setIgnoreOnAdd(true);
		testName = new SqlField(null, "testName", SqlField.VARCHAR_256);
		testDescription = new SqlField(null, "testDescription", SqlField.VARCHAR_2048);
		fields = new SqlField[3];
		fields[0] = testId;
		fields[1] = testName;
		fields[2] = testDescription;
	}

	public void add(Connection conn, boolean ignore) throws SQLException {
		stmt = conn.createStatement();
		rs = stmt.executeQuery("SELECT " + testId.getFieldName() + " FROM " + tableName + " WHERE "
				+ testName.getFieldName() + "='" + testName.getValue() + "'");

		if (rs.next()) { // as values
			setTestId(rs.getInt(1));
			rs.close();
			return;
		}
		rs.close();
		stmt.close();
		super.add(conn, false);
		// Use the MySQL LAST_INSERT_ID()
		// function to do the same thing as getGeneratedKeys()
		//

		String getLastID = null;
		if (getDbType(conn) == DBProperties.DB_TYPE_MYSQL)
			getLastID = "SELECT LAST_INSERT_ID()";
		else if (getDbType(conn) == DBProperties.DB_TYPE_ORACLE)
			getLastID = "select " + getTableName() + "_SEQUENCE.currval from dual";

		rs = stmt.executeQuery(getLastID);
		// Developing Applications with MySQL and Java using Connector/
		// J
		// 8
		if (rs.next()) {
			setTestId(rs.getInt(1));
		} else {
			// throw an exception from here
		}
		rs.close();
		stmt.close();
	}

	public String getTestDescription() {
		return testDescription.getValue().toString();
	}

	public void setTestDescription(String testDescription) {
		this.testDescription.setValue(testDescription);
	}

	public int getTestId() {
		return Integer.parseInt(testId.getValue().toString());
	}

	public void setTestId(int packageId) {
		this.testId.setValue(Integer.toString(packageId));
	}

	public String getTestName() {
		return testName.getValue().toString();
	}

	public void setTestName(String testName) {
		this.testName.setValue(testName);
	}
}
