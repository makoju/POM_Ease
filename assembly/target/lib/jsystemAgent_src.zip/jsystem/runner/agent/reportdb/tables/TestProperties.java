/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.reportdb.tables;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import jsystem.framework.DBProperties;

/**
 * an sql object for the test_properties table
 * @author nizanf
 *
 */
public class TestProperties extends SqlObject {

	SqlField index1 = null;

	SqlField testIndex = null;

	SqlField propertyIndex = null;

	SqlField propertyValue = null;

	public TestProperties() {
		super("test_properties");
		index1 = new SqlField(null, "index1", SqlField.INT_AUTO_INCREMENT);
		index1.setPrimery(true);
		index1.setIgnoreOnAdd(true);
		testIndex = new SqlField(null, "testIndex", SqlField.INTEGER);
		propertyIndex = new SqlField(null, "propertyIndex", SqlField.INTEGER);
		propertyValue = new SqlField(null, "propertyValue", SqlField.VARCHAR_256);

		fields = new SqlField[4];
		fields[0] = index1;
		fields[1] = testIndex;
		fields[2] = propertyIndex;
		fields[3] = propertyValue;
	}

	public TestProperties(ResultSet rs) throws SQLException {
		this();
		setIndex(rs.getInt("index1"));
		setTestIndex(rs.getInt("testIndex"));
		setPropertyIndex(rs.getInt("propertyIndex"));
		setPropertyValue(rs.getString("propertyValue"));
	}

	public void add(Connection conn, boolean ignore) throws SQLException {
		super.add(conn, false);
		String getLastID = null;
		if (getDbType(conn) == DBProperties.DB_TYPE_MYSQL)
			getLastID = "SELECT LAST_INSERT_ID()";
		else if (getDbType(conn) == DBProperties.DB_TYPE_ORACLE)
			getLastID = "select " + getTableName() + "_SEQUENCE.currval from dual";
		System.out.println(getLastID);
		rs = stmt.executeQuery(getLastID);

		if (rs.next()) {
			index1.setValue(Integer.toString(rs.getInt(1)));
		} else {
			// throw an exception from here
		}
		rs.close();
		stmt.close();
	}

	/**
	 * @return Returns the index.
	 */
	public int getIndex() {
		return Integer.parseInt(index1.getValue().toString());
	}

	/**
	 * @param index
	 *            The index to set.
	 */
	public void setIndex(int index) {
		this.index1.setValue(Integer.toString(index));
	}

	/**
	 * @return Returns the testIndex.
	 */
	public int getTestIndex() {
		return Integer.parseInt(testIndex.getValue().toString());
	}

	/**
	 * @param testIndex
	 *            The testIndex to set.
	 */
	public void setTestIndex(int testIndex) {
		this.testIndex.setValue(Integer.toString(testIndex));
	}

	/**
	 * 
	 * @return the property key
	 */
	public String getPropertyIndex() {
		return this.propertyIndex.getValue().toString();
	}

	/**
	 * 
	 * @param propertyIndex 
	 * 			  the property key to set
	 */
	public void setPropertyIndex(int propertyIndex) {
		this.propertyIndex.setValue(propertyIndex);
	}

	/**
	 * 
	 * @return the property value
	 */
	public String getPropertyValue() {
		return this.propertyValue.getValue().toString();
	}

	/**
	 * 
	 * @param propertyValue
	 * 			  the property value to set
	 */
	public void setPropertyValue(String propertyValue) {
		this.propertyValue.setValue(propertyValue);
	}

}
