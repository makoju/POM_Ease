/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner.agent.tests;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsystem.framework.DBProperties;
import jsystem.framework.FrameworkOptions;
import jsystem.framework.JSystemProperties;
import jsystem.framework.RunProperties;
import jsystem.framework.TestProperties;
import jsystem.framework.common.CommonResources;
import jsystem.framework.report.Summary;
import jsystem.framework.scenario.Parameter;
import jsystem.runner.agent.publisher.TestPublisher;
import jsystem.runner.remote.Message;
import jsystem.runner.remote.RemoteTestRunner;
import jsystem.runner.remote.RemoteTestRunner.RemoteMessage;
import jsystem.utils.Encryptor;
import jsystem.utils.FileUtils;
import jsystem.utils.MailUtil;
import jsystem.utils.StringUtils;
import junit.framework.SystemTestCase;
import junit.framework.Test;

/**
 * This class contains a pre-defined test that can be used for notification - email or publish to DB, with
 * or without initializing the reports.
 * 
 * @author YuvalO, yoram.shamir
 * 
 */
public class PublishTest extends SystemTestCase {

	protected static Logger log = Logger.getLogger(PublishTest.class.getName());

	public final static String delimiter = ":ABCDEDCBA:";
	/**
	 * properties to be written to run.properties for publish URL
	 */
	public final static String LAST_PUBLISH_FULL_REPORT_URL = "last.publish.full.report.url";
	public final static String LAST_PUBLISH_DETAIL_URL = "last.publish.detail.url";

	/**
	 * all the parameters that may be needed for the publish/email sending
	 */
	protected enum MsgType {
		SCENARIO,
		SUT,
		VERSION,
		BUILD,
		USER,
		START_TIME,
		NUM_TEST,
		NUM_TEST_FAIL,
		NUM_TEST_PASS,
		NUM_TEST_WARNING,
		STATION,
		RUN_INDEX,
		DESCRIPTION,
		HTML
	}

	/**
	 * Notification type
	 * <br>
	 * publish - only publish, email - only send email, publish_and_email - publish and send email,
	 * init_reports_only - only initialize reports
	 */
	public enum ActionType {
		publish,
		email,
		publish_and_email,
		init_reports_only;
	}

	/**
	 * current action type that the user select
	 */
	public ActionType actionType = ActionType.publish;

	/**
	 * the separator for the files
	 */
	public static final String VALUES_SEPARATOR = CommonResources.DELIMITER;

	/**
	 * description of the publish - input from the user
	 */
	public String description = "";

	public String[] descriptionOptions = null;

	public final static String descriptionString = DBProperties.DESCRIPTION;

	/**
	 * version of the dut - input from the user
	 */
	public String version = "";

	public String[] versionOptions = null;

	public final static String versionString = DBProperties.VERSION;

	/**
	 * build of the dut- input from the user
	 */
	public String build = "";

	public String[] buildOptions = null;

	public final static String buildString = DBProperties.BUILD;

	private String valuesFile = System.getProperty("user.dir") + "\\publishEventOptions.properties";

	private Properties valueProperties;

	protected Summary summary = Summary.getInstance();

	protected JSystemProperties jsysProperties = JSystemProperties.getInstance();

	/**
	 * this hash map contains all the parameters that we want to send via the
	 * email
	 */
	protected HashMap<MsgType, String> msgHash = null;

	/**
	 * If true, initialize reporter (delete all html/xml/any reporter data) after publish/email
	 */
	public boolean initReporter = false;

	/**
	 * email clients addresses can contains more than one email client. if we
	 * want send email to more than one client we should seperate it with ; .
	 * for example jsystemtest@gmail.com; info@ignissoft.com
	 */
	private String sendTo;

	/**
	 * the scenario name that will be published to the reports
	 */
	private String scenarioName = "";

	private String station = "";

	private String sut = "";

	private String password;

	protected String mailSubject;
	private String messageHeader;

	private String attachments;

	private boolean addSummaryReport = false;

	public PublishTest() {
		super();
		parsePublishFile();
	}

	/**
	 * parse the publish properties file
	 * 
	 */
	private void parsePublishFile() {
		if (new File(valuesFile).exists()) {
			try {
				valueProperties = FileUtils.loadPropertiesFromFile(valuesFile);
				versionOptions = getOptionsArray(versionString);
				descriptionOptions = getOptionsArray(descriptionString);
				buildOptions = getOptionsArray(buildString);
			} catch (IOException e) {
				log.fine("couldn't find file " + valuesFile);
			}
		}
		initParametersValues();
	}

	/**
	 * set initial values to parameters (if there are values in a file)
	 * 
	 */
	protected void initParametersValues() {
		if (versionOptions != null && versionOptions.length > 0) {
			version = versionOptions[0];
		}
		if (descriptionOptions != null && descriptionOptions.length > 0) {
			description = descriptionOptions[0];
		}
		if (buildOptions != null && buildOptions.length > 0) {
			build = buildOptions[0];
		}

		sendTo = jsysProperties.getPreference(FrameworkOptions.MAIL_SEND_TO);

		mailSubject = jsysProperties.getPreference(FrameworkOptions.MAIL_SUBJECT);

		if (StringUtils.isEmpty(mailSubject)) {
			mailSubject = "Automatic message from Jsystem - publish/send email";
		}

		messageHeader = jsysProperties.getPreference(FrameworkOptions.MAIL_HEADER);

		attachments = jsysProperties.getPreference(FrameworkOptions.MAIL_ATTACHMENTS);

		password = jsysProperties.getPreference(FrameworkOptions.MAIL_FROM_PASSWORD);
		if (password != null && !Encryptor.isEncrypted(password)) {
			try {
				password = Encryptor.encrypt(password);
				jsysProperties.setPreference(FrameworkOptions.MAIL_FROM_PASSWORD, password);
			} catch (Exception e1) {
				log.fine("failed to encrypt Password ");
			}
		}
	}

	/**
	 * get the options from the properties
	 * 
	 * @param key
	 *            the key to get options for
	 * @return
	 */
	private String[] getOptionsArray(String key) {
		String values = valueProperties.getProperty(key);
		if (values == null || values.trim().equals("")) {
			return null;
		}
		String[] tmpValues = values.split(VALUES_SEPARATOR);
		ArrayList<String> valuesCollection = new ArrayList<String>();
		for (String value : tmpValues) {
			if (value != null && !value.trim().equals("")) {
				valuesCollection.add(value.trim());
			}
		}
		String[] toReturn = new String[valuesCollection.size()];
		toReturn = valuesCollection.toArray(toReturn);
		return toReturn;
	}

	public String getBuild() {
		return build;
	}

	public String[] getBuildOptions() {
		return buildOptions;
	}

	/**
	 * set build
	 * 
	 * @param build
	 */
	public void setBuild(String build) {
		this.build = build;
	}

	public String getDescription() {
		return description;
	}

	public String[] getDescriptionOptions() {
		return descriptionOptions;
	}

	/**
	 * set description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	public String getVersion() {
		return version;
	}

	public String[] getVersionOptions() {
		return versionOptions;
	}

	/**
	 * set version
	 * 
	 * @param version
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	public boolean isInitReporter() {
		return initReporter;
	}

	/**
	 * 
	 * 
	 * @param isInitReporter
	 *            if true, init reporter after publish tests
	 */
	public void setInitReporter(boolean initReporter) {
		this.initReporter = initReporter;
	}

	/**
	 * 
	 * @param p
	 *            properties that contains the description, setup name, version
	 *            and build (field name and values)
	 * @param fieldName
	 *            TestPublisher.DESCRIPTION,TestPublisher.SETUP_NAME,TestPublisher
	 *            .VERSION or TestPublisher.BUILD must be const
	 * @return string that contains field name , delimiter and it's value
	 */
	private String createStrForPublishMessage(HashMap<String, Object> p, String fieldName) {
		Object fieldValue = p.get(fieldName).toString();
		StringBuilder sb = new StringBuilder();
		sb.append(fieldName);
		sb.append(delimiter);
		sb.append(fieldValue);
		return sb.toString();
	}

	public Message createPublishMessage(HashMap<String, Object> theMap,	Test test) {
		Message message = new Message();
		message.setType(RemoteMessage.M_PUBLISH);
		message.addField(this.getFullUUID());
		message.addField(createStrForPublishMessage(theMap,	DBProperties.ACTION_TYPE));
		message.addField(createStrForPublishMessage(theMap,	DBProperties.DESCRIPTION));
		message.addField(createStrForPublishMessage(theMap,	DBProperties.INIT_REPORT));
		message.addField(createStrForPublishMessage(theMap,	DBProperties.VERSION));
		message.addField(createStrForPublishMessage(theMap, DBProperties.BUILD));
		message.addField(createStrForPublishMessage(theMap,	DBProperties.SCENARIO_NAME));
		message.addField(createStrForPublishMessage(theMap,	DBProperties.STATION));
		message.addField(createStrForPublishMessage(theMap, DBProperties.SETUP));
		return message;
	}

	@TestProperties(name = "Send notification. type = ${ActionType}")
	public void publish() {
		
		report.step("Notifying...");
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		hashMap.put(DBProperties.ACTION_TYPE, getActionType());
		hashMap.put(DBProperties.DESCRIPTION, getValue(getDescription(), descriptionString));
		hashMap.put(DBProperties.VERSION, getValue(getVersion(), versionString));
		hashMap.put(DBProperties.BUILD, getValue(getBuild(), buildString));
		hashMap.put(DBProperties.INIT_REPORT, isInitReporter());
		hashMap.put(DBProperties.SCENARIO_NAME, getScenarioName());
		hashMap.put(DBProperties.STATION, getStation());
		hashMap.put(DBProperties.SETUP, getSut());

		// In case there is a runner - try to send to it
		String emailMessage;
		jsystem.runner.remote.Message publishMessage = null;
		if (RemoteTestRunner.getInstance() != null) {
			report.report("RemoteTestRunner is not null");
			publishMessage = createPublishMessage(hashMap, this);
			try {
				publishMessage = RemoteTestRunner.getInstance().sendPublishMessage(publishMessage, this);
			} catch (Exception e) {
				log.log(Level.SEVERE, "problem Publishing to DB!\n\n" + StringUtils.getStackTrace(e));
				report.report("problem Publishing to DB!", StringUtils.getStackTrace(e), false);
			}
		} else {
			report.report("RemoteTestRunner is null");
			try {
				TestPublisher tb = new TestPublisher();
				tb.setWithGUI(false);
				publishMessage = tb.publish(hashMap);
			} catch (Throwable t) {
				log.fine("Failed publishing");
			}
		}

		generateMsgHashMap(publishMessage);
		updateRunPropertiesWithPublishURL();
		log.fine("got publish message. Publish ended.");

		// send email only in publish_and_email or in email Action type
		if (actionType == ActionType.email || actionType == ActionType.publish_and_email) {
			String error = wereMailParametersDefined();

			if (error != null) {
				report.report("Can't email results, since "	+ error	+ " Is not configured in the JSystem properties", false);
				return;
			}
			emailMessage = generateMsgForEmail(publishMessage);
			String fromAddress = jsysProperties.getPreference(FrameworkOptions.MAIL_FROM_ACCOUNT_NAME);
			String user = jsysProperties.getPreference(FrameworkOptions.MAIL_FROM_USER_NAME);
			String hostName = jsysProperties.getPreference(FrameworkOptions.MAIL_HOST);
			boolean ssl = Boolean.parseBoolean(jsysProperties.getPreference(FrameworkOptions.MAIL_SSL));
			int smtpPort = Integer.parseInt(jsysProperties.getPreference(FrameworkOptions.MAIL_SMTP_PORT));
			MailUtil mail = new MailUtil();
			mail.setDebug(false);
			mail.setFromAddress(fromAddress);
			String actualPassword = "";

			if (password == null) {
				actualPassword = null;
			} else {
				try {
					actualPassword = Encryptor.decrypt(password);
				} catch (Exception e1) {
					log.fine("failed to decrypt Password");
				}
			}
			mail.setPassword(actualPassword);
			log.fine("password is " + actualPassword);
			mail.setSendTo(sendTo.trim().split(VALUES_SEPARATOR));
			report.report("send to is "	+ sendTo.trim().split(VALUES_SEPARATOR));
			attachments = addSummaryFileToAttachments();
			if (attachments != null) {
				mail.setAttachments(attachments.trim().split(VALUES_SEPARATOR));
			}
			mail.setSmtpHostName(hostName);
			report.report("smtp host is " + hostName);
			mail.setSsl(ssl);
			report.report("ssl is " + ssl);
			mail.setSmtpPort(smtpPort);
			report.report("smtp port is " + smtpPort);
			mail.setUserName(user);
			report.report("user name is " + user);
			report.step("Sending mail to " + sendTo);
			messageHeader = messageHeader == null ? "" : messageHeader;
			report.report("message header is " + messageHeader);

			try {
				mail.sendMail(mailSubject, messageHeader + "\n\n" + emailMessage);
			} catch (Exception e) {
				log.log(Level.SEVERE, "Problem sending mail!\n\n" + StringUtils.getStackTrace(e));
				report.report("Problem sending mail! \n" + e.getMessage(), StringUtils.getStackTrace(e), false);
			}
		}
	}

	private String wereMailParametersDefined() {
		FrameworkOptions[] optionsToCheck = new FrameworkOptions[] {
				FrameworkOptions.MAIL_FROM_USER_NAME,
				FrameworkOptions.MAIL_HOST, FrameworkOptions.MAIL_SMTP_PORT,
				FrameworkOptions.MAIL_FROM_ACCOUNT_NAME };
		for (FrameworkOptions option : optionsToCheck) {
			if (JSystemProperties.getInstance().getPreference(option) == null) {
				return option.toString();
			}
		}
		return null;
	}

	private void updateRunPropertiesWithPublishURL() {
		try {
			// base URL
			StringBuilder baseUrl = new StringBuilder("");
			baseUrl.append("http://").append(
					DBProperties.getInstance().getProperty("serverIP")).append(
					":").append(DBProperties.getInstance().getProperty("browser.port"));
			// detail report URL
			StringBuilder runDetailurl = new StringBuilder("");
			runDetailurl.append(baseUrl.toString()).append("/reports/runDetails.jsp?runIndex=").append(msgHash.get(MsgType.RUN_INDEX));
			// full report URL
			StringBuilder fullReportUrl = new StringBuilder("");
			fullReportUrl.append(baseUrl.toString()).append("/").append(msgHash.get(MsgType.HTML));
			// update run properties with publish URL for run detail report
			RunProperties.getInstance().setRunProperty(LAST_PUBLISH_DETAIL_URL,	runDetailurl.toString());
			// update run properties with publish URL for full report
			RunProperties.getInstance().setRunProperty(LAST_PUBLISH_FULL_REPORT_URL, fullReportUrl.toString());
		} catch (Exception e) {
			report.report("Failed writing publish url to run props  "
					+ e.getMessage(), StringUtils.getStackTrace(e), true);
			log.log(Level.WARNING, "Failed writing publish url to run props");
		}
	}

	private String addSummaryFileToAttachments() {
		if (!addSummaryReport) {
			return attachments;
		}
		String dir = JSystemProperties.getInstance().getPreference(FrameworkOptions.LOG_FOLDER)
				+ File.separator + "current" + File.separator + "summary.html";
		if (dir.startsWith(File.separator)) {
			dir = dir.substring(1);
		}
		return attachments == null ? dir : dir + CommonResources.DELIMITER + attachments;
	}

	/**
	 * if the current value is not empty , return it, otherwise check the
	 * summary
	 * 
	 * @param currentValue
	 *            the current value
	 * @param summarykey
	 *            the summary key to search
	 * @return
	 */
	private Object getValue(String currentValue, String summarykey) {
		if (!StringUtils.isEmpty(currentValue)) {
			return currentValue;
		}
		Object summaryValue = summary.getProperty(summarykey);
		if (!StringUtils.isEmpty((String) summaryValue)) {
			return summaryValue;
		}
		return "";
	}

	public ActionType getActionType() {
		return actionType;
	}

	/**
	 * publish, send email or publish and send email
	 * 
	 * @param actionType
	 */
	public void setActionType(ActionType actionType) {
		this.actionType = actionType;
	}

	public String getSendTo() {
		return sendTo;
	}

	/**
	 * 
	 * @param sendTo
	 *            email address which we want to send them email. we can send to
	 *            more than one email account by separating list of EMails
	 *            addresses with ;
	 */
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	/**
	 * generates message that will be send as email message if the user
	 * published the data to the webServer it will add the relevant links
	 * 
	 * @param msg
	 *            message that was get from the RemoteTestRunner class
	 * @return message that will be send via the email
	 * @throws Exception
	 */
	protected String generateMsgForEmail(jsystem.runner.remote.Message msg) {
		StringBuilder stringBuilder = new StringBuilder("");
		stringBuilder.append("This is automatically email that was sent by the Jsystem\n");

		boolean publishSuccessfull = (msgHash.get(MsgType.RUN_INDEX) != null);
		if (publishSuccessfull) {
			report.report("Results where published to Reports server");
		} else if (actionType != ActionType.email) {
			report.report("Results where not published to Reports server", false);
		}

		if (actionType != ActionType.email && publishSuccessfull) {
			stringBuilder.append("\nRun index number : ").append(msgHash.get(MsgType.RUN_INDEX));
		}

		stringBuilder.append("\nScenario Name : ").append(msgHash.get(MsgType.SCENARIO));
		stringBuilder.append("\nSetup Name : ").append(msgHash.get(MsgType.SUT));
		stringBuilder.append("\nVersion : ").append(msgHash.get(MsgType.VERSION));
		stringBuilder.append("\nBuild : ").append(msgHash.get(MsgType.BUILD));
		stringBuilder.append("\nStation : ").append(msgHash.get(MsgType.STATION));
		stringBuilder.append("\nUser Name : ").append(msgHash.get(MsgType.USER));
		stringBuilder.append("\nStart Time : ").append(msgHash.get(MsgType.START_TIME));

		stringBuilder.append("\n\nRun Tests : ").append(msgHash.get(MsgType.NUM_TEST));
		stringBuilder.append("\nFailed Tests : ").append(msgHash.get(MsgType.NUM_TEST_FAIL));
		stringBuilder.append("\nPass Tests : ").append(msgHash.get(MsgType.NUM_TEST_PASS));
		stringBuilder.append("\nWarning Tests : ").append(msgHash.get(MsgType.NUM_TEST_WARNING));

		if (actionType != ActionType.email) {
			if (publishSuccessfull) {
				try {
					stringBuilder.append("\nDescription : ").append(msgHash.get(MsgType.DESCRIPTION));
					stringBuilder.append("\nLink to html reports : http://").append(
									DBProperties.getInstance().getProperty("serverIP")).append(":").append(
									DBProperties.getInstance().getProperty("browser.port")).append("/").append(
									msgHash.get(MsgType.HTML));
					stringBuilder.append("\n\nThis scenario was published to the reports system\nLinks");
					stringBuilder.append("\nRun details report : ").append(
							"http://").append(DBProperties.getInstance().getProperty("serverIP")).append(":").append(
									DBProperties.getInstance().getProperty("browser.port")).append(
									"/reports/runDetails.jsp?runIndex=").append(msgHash.get(MsgType.RUN_INDEX));
				} catch (Exception e) {
					log.warning("Failed reading DBProperties values");
				}
			} else {
				stringBuilder.append("\n\nFailed publishing This scenario to the reports system!");
			}
		} else {
			stringBuilder.append("\n\nThis scenario wasn't published to the reports system");
		}

		return stringBuilder.toString();
	}

	/**
	 * extract parameters from the message that we get from RemoteTestRunner and
	 * put each parameter in HashMap.
	 * 
	 * @param msg
	 *            message that we get from RemoteTestRunner
	 */
	protected void generateMsgHashMap(jsystem.runner.remote.Message msg) {
		msgHash = new HashMap<MsgType, String>();
		// surround a problem by getting "version" and "build" direct and not
		// from the "report.0.xml"
		// like it was before. this is a workaround for a problem that should be
		// solved
		// (by updating the reports.0.xml file from the given values)
		msgHash.put(MsgType.SCENARIO, scenarioName);// msg.getField(0));
		msgHash.put(MsgType.SUT, sut); // msg.getField(1));
		msgHash.put(MsgType.VERSION, getValue(getVersion(), versionString).toString());
		msgHash.put(MsgType.BUILD, getValue(getBuild(), buildString).toString());
		msgHash.put(MsgType.USER, msg.getField(4));
		msgHash.put(MsgType.START_TIME, convertLongToDate(Long.parseLong(msg.getField(5))));
		msgHash.put(MsgType.NUM_TEST, msg.getField(6));
		msgHash.put(MsgType.NUM_TEST_FAIL, msg.getField(7));
		msgHash.put(MsgType.NUM_TEST_PASS, msg.getField(8));
		msgHash.put(MsgType.NUM_TEST_WARNING, msg.getField(9));
		msgHash.put(MsgType.STATION, getStation());

		// Checking the size to avoid exception. Happens when a publish fails
		// but we still
		// want to send an email
		if (actionType != ActionType.email && msg.getFields().size() > 11) {
			msgHash.put(MsgType.DESCRIPTION, msg.getField(11));
			msgHash.put(MsgType.HTML, msg.getField(12));
			msgHash.put(MsgType.RUN_INDEX, msg.getField(13));
		}

	}

	/**
	 * convert long number to string date
	 * 
	 * @param time
	 *            the in long format
	 * @return string date
	 */
	private String convertLongToDate(long time) {
		Date date = new Date(time);
		Calendar cal = new GregorianCalendar();
		cal.setTime(date);
		return cal.getTime() + "";
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public String getMessageHeader() {
		return messageHeader;
	}

	public void setMessageHeader(String messageHeader) {
		this.messageHeader = messageHeader;
	}

	public void handleUIEvent(HashMap<String, Parameter> map, String methodName) throws Exception {

		if (!"publish".equals(methodName)) {
			return;
		}

		Parameter param = map.get("ActionType");
		param.setSection("General");

		if (ActionType.valueOf(param.getValue().toString()) == ActionType.init_reports_only) {
			// init reports only
			setEditable(map, false);
			map.get("InitReporter").setValue(true);
			toggleSendEmail(map, false);
			togglePublish(map, false);
		} else if (ActionType.valueOf(param.getValue().toString()) == ActionType.publish_and_email) {
			// publish and email
			setEditable(map, true);
			toggleSendEmail(map, true);
			togglePublish(map, true);
		} else if (ActionType.valueOf(param.getValue().toString()) == ActionType.publish) {
			// publish only
			setEditable(map, true);
			toggleSendEmail(map, false);
			togglePublish(map, true);
		} else {
			// email only
			setEditable(map, true);
			toggleSendEmail(map, true);
			togglePublish(map, false);
		}

	}
	
	private void setEditable(HashMap<String, Parameter> map, boolean status) {
		map.get("Sut").setEditable(status);
		map.get("InitReporter").setEditable(status);
		map.get("Station").setEditable(status);
		map.get("Build").setEditable(status);
		map.get("Version").setEditable(status);
		map.get("ScenarioName").setEditable(status);
	}

	/**
	 * toggle all send email parameters visible or not visible
	 * 
	 * @param map
	 * @param isVisible
	 */
	private void toggleSendEmail(HashMap<String, Parameter> map, boolean isVisible) {
		String[] params = new String[] { "SendTo", "MailSubject", "MessageHeader", "Attachments", "AddSummaryReport" };
		toggleParameters(map, isVisible, params, "Email");
	}

	/**
	 * toggle all publish parameters visible or not visible
	 * 
	 * @param map
	 * @param isVisible
	 */
	private void togglePublish(HashMap<String, Parameter> map, boolean isVisible) {
		String[] params = new String[] { "Description" };
		toggleParameters(map, isVisible, params, "Publish");
	}

	/**
	 * handle jsystem test info GUI sets on/off specific test parameters
	 * 
	 * @param map
	 * @param isVisible
	 *            true - set visible the parameters else set it as not visible
	 * @param params
	 *            list of paramteres that we want to set
	 * @param section
	 */
	private void toggleParameters(HashMap<String, Parameter> map, boolean isVisible, String[] params, String section) {
		Parameter param = null;
		for (int i = 0; i < params.length; i++) {
			param = map.get(params[i]);
			param.setSection(section);
			param.setVisible(isVisible);
		}
	}

	public String getScenarioName() {
		if (StringUtils.isEmpty(scenarioName)) {
			scenarioName = JSystemProperties.getInstance().getPreference(FrameworkOptions.CURRENT_SCENARIO);
		}
		return scenarioName;
	}

	public void setScenarioName(String scenarioName) {
		this.scenarioName = scenarioName;
	}

	public String getStation() {
		if (StringUtils.isEmpty(station)) {
			try {
				station = InetAddress.getLocalHost().getHostAddress();
			} catch (UnknownHostException e) {
				log.fine("Failed to get station value " + e);
			}
		}
		return station;
	}

	public void setStation(String station) {
		this.station = station;
	}

	public String getSut() {
		if (StringUtils.isEmpty(sut)) {
			sut = sut().getSetupName();
		}
		return sut;
	}

	public void setSut(String sut) {
		this.sut = sut;
	}

	public String getAttachments() {
		return attachments;
	}

	/**
	 * add several ";" separated files
	 * 
	 * @param attachments
	 */
	public void setAttachments(String attachments) {
		this.attachments = attachments;
	}

	public boolean isAddSummaryReport() {
		return addSummaryReport;
	}

	/**
	 * Should the Summary report be attached to the mail?
	 * 
	 * @param addSummaryReport
	 */
	public void setAddSummaryReport(boolean addSummaryReport) {
		this.addSummaryReport = addSummaryReport;
	}

}
