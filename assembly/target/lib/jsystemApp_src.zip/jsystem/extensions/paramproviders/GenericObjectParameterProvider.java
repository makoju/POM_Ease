/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.extensions.paramproviders;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Dialog.ModalityType;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsystem.framework.scenario.Parameter;
import jsystem.framework.scenario.ParameterProvider;
import jsystem.framework.scenario.RunnerTest;
import jsystem.framework.scenario.Scenario;
import jsystem.runner.loader.LoadersManager;
import jsystem.treeui.utilities.PropertiesDialog;
import jsystem.utils.beans.BeanDefaultsExtractor;
import jsystem.utils.beans.BeanElement;
import jsystem.utils.beans.BeanUtils;

public class GenericObjectParameterProvider implements ParameterProvider{

	private static Logger log = Logger.getLogger(GenericObjectParameterProvider.class.getName());
	
	public GenericObjectParameterProvider(){
	}

	@Override
	public String getAsString(Object o) {
		// if the input object is null or is of type String return
		if(o == null){
			return null;
		}
		if(o instanceof String){
			return (String)o;
		}
		
		StringBuffer buf = new StringBuffer();
		// append the class name then ';'
		buf.append(o.getClass().getName());buf.append(';');
		ArrayList<BeanElement> beanElements = BeanUtils.getBeans(o.getClass(), true, true, BeanUtils.getBasicTypes());
		
		// build properties object from the given object
		Properties propertier = new Properties();
		for(BeanElement be: beanElements){
			if(be.getGetMethod() == null){
				continue;
			}
			try {
				Object value = be.getGetMethod().invoke(o, new Object[0]);
				if(value != null){
					propertier.setProperty(be.getName(), value.toString());
				}
			} catch (Exception e) {
				log.log(Level.WARNING,"Fail to invoke the getter: " + be.getName(), e);
			}
		}
		StringWriter writer = new StringWriter();
		try {
			propertier.store(writer, null);
		} catch (IOException e) {
			log.log(Level.WARNING, "Fail to store the property object to the StringWriter", e);
		}
		// append the properties string
		buf.append(writer.getBuffer().toString());
		
		return buf.toString();
	}

	@Override
	public Object getFromString(String stringRepresentation) throws Exception {
		// if the input is null return null object
		if(stringRepresentation == null){
			return null;
		}
		// first extract the class name
		int classEndIndex = stringRepresentation.indexOf(';');
		if(classEndIndex < 0){
			return null;
		}
		String className = stringRepresentation.substring(0, classEndIndex);
		
		// then extract the string to be load as properties object
		String propertiesString = stringRepresentation.substring(classEndIndex + 1);
		Properties properties = new Properties();
		try {
			properties.load(new StringReader(propertiesString));
		} catch (IOException e1) {
			log.log(Level.WARNING, "Fail to load properties: " + propertiesString, e1);
			return null;
		}
		// create the class from the input string
		Class<?> c;
		try {
			c = LoadersManager.getInstance().getLoader().loadClass(className);
		} catch (ClassNotFoundException e) {
			log.log(Level.WARNING, "Fail to create class: " + className, e);
			return null;
		}
		// create the object and init it using the properties
		return BeanUtils.propertiesToObject(c, propertiesToMap(properties));
	}

	@Override
	public boolean isFieldEditable() {
		return false;
	}

	@Override
	public synchronized Object showUI(Component parent, Scenario s, RunnerTest test, Class<?> c, Object o,Parameter p) throws Exception {
		ArrayList<BeanElement> beanElements = BeanUtils.getBeans(c, true, true, BeanUtils.getBasicTypes());

		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
		String[] properties = getProeprties(beanElements);
		Properties prop = BeanDefaultsExtractor.getBeanDefaults(c, properties);
		for(BeanElement be: beanElements){
			map.put(be.getName(), prop.getProperty(be.getName()));
		}
		if(o != null){
			if((!(c.isAssignableFrom(o.getClass())))){
				o = getFromString(o.toString());
			}

			Properties oProperties = BeanUtils.objectToProperties(o, beanElements);
			for(BeanElement be: beanElements){
				String value = oProperties.getProperty(be.getName());
				if(value != null){
					map.put(be.getName(), value);
				}
			}
		}
		PropertiesTableModel model = new PropertiesTableModel(map, beanElements);
		PropertiesDialog dialog = new PropertiesDialog("Bean properties", model);

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		dialog.setLocation(screenWidth / 4, screenHeight / 5);

		dialog.setModalityType(ModalityType.APPLICATION_MODAL);
		if(dialog.showAndWaitForApprove()){
			return BeanUtils.propertiesToObject(c, map);
		}
		return o;
	}
	private static String[] getProeprties(ArrayList<BeanElement> beanElements){
		String[] properties = new String[beanElements.size()];
		for(int i = 0; i < beanElements.size(); i++){
			properties[i] = beanElements.get(i).getName();
		}
		return properties;
	}
	
	private static LinkedHashMap<String, String> propertiesToMap(Properties properties){
		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
		Set<Object> keys = properties.keySet();
		for(Object key: keys){
			map.put(key.toString(), properties.getProperty(key.toString()));
		}
		return map;
	}

	@Override
	public void setProviderConfig(String... args) {
	}
}
