/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.extensions.paramproviders;

import java.awt.Component;

import jsystem.framework.common.CommonResources;
import jsystem.framework.scenario.Parameter;
import jsystem.framework.scenario.ParameterProvider;
import jsystem.framework.scenario.RunnerTest;
import jsystem.framework.scenario.Scenario;
import jsystem.utils.StringUtils;

/**
 * @author golan.derazon
 */
public class StringArrayOptionsParameterProvider implements ParameterProvider {


	@Override
	public String getAsString(Object o) {
		if (o == null){
			return "";
		}
		return StringUtils.objectArrayToString(CommonResources.DELIMITER,(Object[])o);
	}

	@Override
	public Object getFromString(String stringRepresentation) {
		return StringUtils.split(stringRepresentation,CommonResources.DELIMITER);
	}

	@Override
	public Object showUI(Component parent, Scenario s, RunnerTest test, Class<?>c, Object o,Parameter p) {
		OptionsMultiSelectDialog dialog = new OptionsMultiSelectDialog();
		String[] selected = (String[])o;
		dialog.initDialog(p.getOptions(),selected);
		if (dialog.isOkay()){
			return dialog.getSelectedOptions();
		}else {
			return selected;
		}
	}

	@Override
	public boolean isFieldEditable() {
		return false;
	}

	@Override
	public void setProviderConfig(String... args) {
	}

}
