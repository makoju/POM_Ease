/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui;

import java.awt.Cursor;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Properties;
import java.util.logging.Logger;

import javax.swing.RootPaneContainer;

import jsystem.framework.DBProperties;
import jsystem.framework.report.ListenerstManager;
import jsystem.framework.report.Reporter;
import jsystem.runner.ErrorLevel;
import jsystem.runner.WaitDialog;
import jsystem.runner.agent.reportdb.tables.Package;
import jsystem.runner.agent.reportdb.tables.PropertiesList;
import jsystem.runner.agent.reportdb.tables.Run;
import jsystem.runner.agent.reportdb.tables.Step;
import jsystem.runner.agent.reportdb.tables.Test;
import jsystem.runner.agent.reportdb.tables.TestName;
import jsystem.runner.agent.reportdb.tables.TestProperties;
import jsystem.treeui.publisher.DefineDbPropertiesDialog;
import jsystem.treeui.publisher.PublishErrorDialog;
import jsystem.utils.StringUtils;
import jsystem.utils.UploadRunner;

/**
 * checks connectivity to the Tomcat url and Mysql DB and showes an error window if needed
 * 
 * @author NorthTeam
 *
 */
public class DbGuiUtility {
	public static Reporter report = ListenerstManager.getInstance();
	static boolean debug = true;
	private static Logger log = Logger.getLogger(DbGuiUtility.class.getName());
	
	/**
	 * save the dialog values to a file<br>
	 * NOTE: the values are not verified! verify values first by <I>validateDialogParams</I>
	 * 
	 * @param db
	 * @param conn
	 */
	public static void saveDialogToDb(DefineDbPropertiesDialog db, Connection conn) {
		boolean saveAccomplishe = DBProperties.saveRunData(getDialogDbDriver(db), getDialogDbType(db), getDialogDbHost(db), getDialogDbName(db), getDialogDbUser(db), getDialogDbPassword(db), getDialogApplicationServerPort(db), getDialogApplicationServerUrl(db));
		if (saveAccomplishe) {
			db.dispose();
			DBProperties.closeConnectionIfExists(conn);
			TestRunner.treeView.refreshOpenReportsButton(true);
		} 
	}
	
	public static void cancleDialogEdit(DefineDbPropertiesDialog db, Connection conn) {
		db.dispose();
		DBProperties.closeConnectionIfExists(conn);
		TestRunner.treeView.refreshOpenReportsButton();
	}
	
	
	public static void validateDialogParams(DBConnectionListener listener,DefineDbPropertiesDialog db, boolean errorMessageRequiered) {
		DbGuiUtility.changeCursor(db, true);
		if (!validateUrl(db, errorMessageRequiered)){
			listener.connectionIsOk(false,null);
		}else{
			checkDBConnection(listener,getDialogDbDriver(db), getDialogDbHost(db), getDialogDbName(db),getDialogDbType(db), getDialogDbUser(db), getDialogDbPassword(db));
		}
		DbGuiUtility.changeCursor(db, false);
	}
	
	public static void validateDialogParams(DBConnectionListener listener, boolean errorMessageRequiered){
		Properties p = null;
		try {
			p = DBProperties.getDbProperties();
		} catch (IOException e) {
			log.fine("problem reading db properties file");
		}
		if (!validateUrl(p.getProperty("browser.port"),p.getProperty("serverIP"))){
			listener.connectionIsOk(false,null);
		}else{
			checkDBConnection(listener,p.getProperty("db.driver"),p.getProperty("db.host") , p.getProperty("db.dbname"),p.getProperty("db.type"), p.getProperty("db.user"), p.getProperty("db.password"));
		}
	}
	
	/**
	 * 
	 * @param errorMessageRequiered
	 * @return:
	 * 	True - If a connection to the application server have been accomplished with the dialog parameters
	 * 	False - If a failure occured while trying to connect to the application server with the dialog parameters
	 * Description:
	 * 	Try to connect the application server with the dialog parameters.
	 * 	If an error occured and errorMessageRequiered = true, the method show an error message to the user
	 */
	public static boolean validateUrl(String applicationServerPort, String applicationServerUrl) {
		return UploadRunner.validateUrl("http://" + applicationServerUrl + ":" + applicationServerPort + "/reports");
		
	}
	
	
	/**
	 * 
	 * @param errorMessageRequiered
	 * @return:
	 * 	True - If a connection to the application server have been accomplished with the dialog parameters
	 * 	False - If a failure occured while trying to connect to the application server with the dialog parameters
	 * Description:
	 * 	Try to connect the application server with the dialog parameters.
	 * 	If an error occured and errorMessageRequiered = true, the method show an error message to the user
	 */

	private static boolean validateUrl(DefineDbPropertiesDialog db, boolean errorMessageRequiered) {
		String url = "http://" + getDialogApplicationServerUrl(db) + ":" + getDialogApplicationServerPort(db) + "/reports";
		boolean result = true;
		
		if (!UploadRunner.validateUrl(url)){
			result = false;
			if ( errorMessageRequiered ) {
				String title = "Unable to connect to: " + url + ".\n"
					+ "Check server connection. \n"
					+ "If the given parameters are incorrect you will "
					+ "not be able to publish test results to the server. \n";
				String message = "Try the following: \n"
					+ "1) Check application server url and port. \n"
					+ "2) Verify the Apache server service is running. \n";
				WaitDialog.endWaitDialog();
				StringUtils.showMsgWithTime(message);
				report.report(title, message, false);
				publishError(title, message, ErrorLevel.Error);
			}
		}
		return result;
	}
	
	/**
	 * check if there is a connection with the Mysql server<br>
	 * pass a listener to handle event for each case<br>
	 * connection is using the parameters from the db.properties file
	 * 
	 * @param listener
	 */
	public static void checkDBConnection(final DBConnectionListener listener) {
		Properties p;
		try {
			p = DBProperties.getDbProperties();
			checkDBConnection(listener,p.getProperty("db.driver"),p.getProperty("db.host") , p.getProperty("db.dbname"),p.getProperty("db.type"), p.getProperty("db.user"), p.getProperty("db.password"));
		} catch (IOException e) {
			log.fine("problem reading db properties file");
		}
		
	}
	
	/**
	 * check if there is a connection with the Mysql server<br>
	 * pass a listener to handle event for each case<br>
	 * connection is using the given parameters
	 * 
	 * @param listener	the listener who changes the gui according to the connection varification
	 * @param dbDriver
	 * @param dbHost
	 * @param dbName
	 * @param dbType
	 * @param dbUser
	 * @param dbPassword
	 */
	public static void checkDBConnection(final DBConnectionListener listener,final String dbDriver,final String dbHost, final String dbName, final String dbType,final String dbUser, final String dbPassword) {
		WaitDialog.launchWaitDialog("Connecting to DB");
		showMsgWithTime("creating connection to the database");
		
		(new Thread() { // a thread is used to avoid interfering with the WaitDialog progress bar
			public void run() {
				Connection conn;
				try {
					if (dbDriver !=null){
						conn = DBProperties.getInstance().getConnection(dbDriver, dbHost, dbName, dbType, dbUser, dbPassword);
					}else{
						conn = DBProperties.getInstance().getConnection();
					}
				} catch (Exception e) {
					conn = null;
					WaitDialog.endWaitDialog();
					showMsgWithTime("problem connecting to DB");
					DbGuiUtility.publishError("Publish error- fail to connect to the Database", "Fail to connect to the Database\n\n"
							+ "Try the following:\n\n" + "1) Check that The Database Server is on\n\n"
							+ "2) Check You Database Properties \n\n" + StringUtils.getStackTrace(e), ErrorLevel.Error);
					listener.connectionIsOk(false,null);
					return;
				}

				if (! allNecessaryTablesCreated(conn)) {
					conn = null;
					WaitDialog.endWaitDialog();
					showMsgWithTime("problem connecting to DB");
					DbGuiUtility.publishError("Publish error - missing tables in DB", "Necessary Tables in DB were not created,\n"
							+ "please run the reports application first\n\n", ErrorLevel.Error);
					listener.connectionIsOk(false,null);
					return;
				}
				WaitDialog.endWaitDialog();
				showMsgWithTime("connection to db is ok");
				listener.connectionIsOk(true,conn);
			}
		}).start();
	}
	
	
	/**
	 * Description:
	 * Verify the database contains all necessary tables for proper operation
	 * @param conn - A Connection object to the database.
	 * @return:
	 * True - If database contains all necessary tables
	 * False - If database does not contain all necessary tables
	 */

	public static boolean allNecessaryTablesCreated(Connection conn) {
		boolean allCreated = true;
		
		try {
			allCreated = new Run().check(conn) && new TestProperties().check(conn) && new Package().check(conn)
				&& new PropertiesList().check(conn) && new Step().check(conn) && new Test().check(conn) && new TestName().check(conn);
		} catch (SQLException e) {
			allCreated = false;
		}
		return allCreated;
	}
	
	/**
	 * shows a msg with time to the console if on debug mode
	 * @param msg
	 * 			the message to show
	 */
	public static void showMsgWithTime(String msg) {
		if (debug)
			System.out.println(getTime() + " " + msg);
	}
	
	
	/**
	 * get current time as a String
	 * @return	the current time String
	 */
	public static String getTime() {
		Calendar cal = new GregorianCalendar();
		int hour24 = cal.get(Calendar.HOUR_OF_DAY); // 0..23
		int min = cal.get(Calendar.MINUTE); // 0..59
		int sec = cal.get(Calendar.SECOND); // 0..59
		return hour24 + ":" + min + ":" + sec;
	}
	

	/**
	 * Description:
	 * Print out an error message to the report, and call for publishError() method to continue handling the error
	 * @param e - an exception object holding the exception information
	 * @param title - The error occured
	 * @param msg - Some more details concerning the error occured
	 * @throws Exception
	 */
	public static void handleException(Exception e, String title, String msg) throws Exception {
		publishError(title, msg, ErrorLevel.Error);
		report.report(title, msg, false);
		throw e;
	}

	
	/**
	 * Description:
	 * Show an error message to the user, allow him to get some information on the error occured
	 * @param title- The error occured
	 * @param message - Some more details concerning the error occured
	 * @param errorLevel - Indicator for the error sevirity.
	 */
	public static void publishError(String title, String message, ErrorLevel errorLevel) {
		PublishErrorDialog d = new PublishErrorDialog(title, message, errorLevel);
		d.init();
		d.repaint();
		d.setAlwaysOnTop(true);
	}

	/**
	 * 
	 * @param db - the dialog that should prresent the cursor
	 * @param requiereToWait - A boolean parameter indicates if we would like to present 
	 * 		Wait cursor, or default cursor
	 */
	public static void changeCursor(DefineDbPropertiesDialog db, boolean requiereToWait) {
		RootPaneContainer root = (RootPaneContainer)db;
		
		if (requiereToWait) {
			root.getGlassPane().setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		} else {
			root.getGlassPane().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		}
		
		root.getGlassPane().setVisible(requiereToWait);
	}
	
	
	/**
	 * @return a String holding the database type
	 */
	private static String getDialogDbType(DefineDbPropertiesDialog db) {
		return db.getDb().getDialogDbType();
	}
	
	/**
	 * @return a String holding the database driver
	 */
	private static String getDialogDbDriver(DefineDbPropertiesDialog db) {
		return db.getDb().getDialogDbDriver();
	}
	
	/**
	 * @return a String holding the database host
	 */
	private static String getDialogDbHost(DefineDbPropertiesDialog db) {
		return db.getDb().getDialogDbHost();
	}
	
	/**
	 * @return a String holding the database name
	 */
	private static String getDialogDbName(DefineDbPropertiesDialog db) {
		return db.getDb().getDialogDbName();
	}
	
	/**
	 * @return a String holding the database user name
	 */
	private static String getDialogDbUser(DefineDbPropertiesDialog db) {
		return db.getDb().getDialogDbUser();
	}
	
	/**
	 * @return a String holding the database password
	 */
	private static String getDialogDbPassword(DefineDbPropertiesDialog db) {
		return db.getDb().getDialogDbPassword();
	}
	
	/**
	 * @return a String holding the application server port
	 */
	private static String getDialogApplicationServerPort(DefineDbPropertiesDialog db) {
		return db.getDb().getDialogApplicationServerPort();
	}
	
	/**
	 * @return a String holding the application server url
	 */
	private static String getDialogApplicationServerUrl(DefineDbPropertiesDialog db) {
		return db.getDb().getDialogApplicationServerUrl();
	}

}
