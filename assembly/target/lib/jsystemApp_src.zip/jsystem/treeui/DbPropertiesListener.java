/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import jsystem.framework.DBProperties;
import jsystem.framework.report.ListenerstManager;
import jsystem.framework.report.Reporter;
import jsystem.treeui.publisher.DefineDbPropertiesDialog;

/**
 * this class is responsible for handling the database dialog opened through the menu item.
 * it handles all action commands
 * 
 * @author NorthTeam
 *
 */
public class DbPropertiesListener implements ActionListener,DBConnectionListener {
	public static Reporter report = ListenerstManager.getInstance();
	private DefineDbPropertiesDialog db;
	private DBProperties dbP = null;
	private Connection conn = null;

	/**
	 * Default constructor
	 * @param db - An object from type DefineDbPropertiesDialog, that allow the user to edit the database parameters
	 * Description: get the database attributes from the file db.properties, 
	 * and try to establish a connection to the database
	 */
	public DbPropertiesListener(DefineDbPropertiesDialog db) {
		try {
			this.db = db;
			dbP = DBProperties.getInstance();
			conn = dbP.getConnection();
		} catch (Exception e){
			System.out.println("Fail to connect the database");
		}
	}

	
	/**
	 * @param e - Holds the name of the button the user has pressed
	 * Description:
	 * According to the action performed by the user, the method makes the following decisions:
	 * If the user pressed ok:
	 * 		- The methods verify the parameter correctness
	 * 		- If all parameters are correct: 
	 * 			- The parameters from the dialog are saved into the db.properties file.
	 * 			- Enable the "Open Reports application" button.
	 * 			- Close the dialog.
	 * 		- If some of the parameters are wrong:
	 * 			- The mothod show an error message, and return to the dialog after the user approve message reading
	 * 			- Disable the "Open Reports application" button.
	 * If the user pressed cancel:
	 * 		- The methods verify the parameter correctness:
	 * 		- If some of the parameters are wrong:
	 * 			- The mothod show an error message, and close the dialog after the user approve message reading
	 * 			- Disable the "Open Reports application" button.
	 * 		- If all parameters are correct, the method close the dialog, and enable
	 * 			- The mothod closes the dialog.
	 * 			- Enable the "Open Reports application" button.  
	 */
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		
		if (source.equals(DefineDbPropertiesDialog.okButton)) {
			DbGuiUtility.validateDialogParams(this, db, true);
			
		} else if (source.equals(DefineDbPropertiesDialog.cancelButton)) {
			DbGuiUtility.cancleDialogEdit(db, conn);
		}
	}


	public void connectionIsOk(boolean status,Connection con) {
		conn = con;
		if (status){
			DbGuiUtility.saveDialogToDb(db, conn);
		}
	}

}
