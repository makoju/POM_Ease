/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Observable;
import java.util.Observer;
import java.util.Properties;

import jsystem.framework.DBProperties;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

public class FtpServer extends Observable {
	private String username;

	private String password;

	private String serverName;

	// private String regressionDir = "regressions";
	private String resultsDir = "results";

	public FtpServer(String serverNameP, String usernameP, String passwordP) {
		this.serverName = serverNameP;
		this.username = usernameP;
		this.password = passwordP;
	}

	public FtpServer(String serverNameP, String usernameP, String passwordP, Observer observ) {
		addObserver(observ);
		this.serverName = serverNameP;
		this.username = usernameP;
		this.password = passwordP;
	}

	public void put(File localFile, String destination) throws Exception {
		FTPClient ftp = new FTPClient();
		boolean status;
		try {
			login(ftp);
			status = ftp.changeWorkingDirectory(destination);
			if (!status)
				throw new Exception("FTP fail to change directory to: " + destination);
			ftp.storeFile(destination + "/" + localFile.getName(), new FileInputStream(localFile));
		} finally {
			ftp.disconnect();
		}
	}

	public String publishResults(File directory, long index) throws Exception {
		FTPClient ftp = new FTPClient();
		boolean status;
		String regNameDir;
		try {
			login(ftp);
			regNameDir = "/" + resultsDir + "/" + index;
			status = ftp.changeWorkingDirectory("/" + resultsDir);
			if (!status) {
				status = ftp.makeDirectory(resultsDir);
				if (!status) {
					throw new Exception("FTP fail to create directory to: " + resultsDir);
				}
				status = ftp.changeWorkingDirectory(resultsDir);
				if (!status) {
					throw new Exception("FTP fail to change directory to: " + resultsDir);
				}
			}
			status = ftp.changeWorkingDirectory(Long.toString(index));
			if (!status) {
				status = ftp.makeDirectory(Long.toString(index));
				if (!status) {
					throw new Exception("FTP fail to create directory to: " + Long.toString(index));
				}
				status = ftp.changeWorkingDirectory(Long.toString(index));
				if (!status) {
					throw new Exception("FTP fail to change directory to: " + Long.toString(index));
				}
			}
			ftp.makeDirectory(Long.toString(index));
			// collectFiles(directory, directory, fileCollect, dirs);
			// createDirectories(ftp, dirs);
			// copyFiles(ftp,directory.listFiles(),regNameDir);
			copyFilesTree(ftp, regNameDir, directory, directory, 0);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			ftp.disconnect();
		}
		return "http://" + serverName + regNameDir + "/index.html";
	}

	private void login(FTPClient ftp) throws Exception {
		boolean status;
		int reply;
		ftp.connect(serverName);
		// After connection attempt, you should check the reply code to verify
		// success.
		reply = ftp.getReplyCode();

		if (!FTPReply.isPositiveCompletion(reply)) {
			throw new Exception("FTP server refused connection");
		}
		status = ftp.login(username, password);
		if (!status)
			throw new Exception("FTP fail to login");

		// Use passive mode as default because most of us are
		// behind firewalls these days.
		ftp.enterLocalPassiveMode();
		// added the ability to copy binary files
		ftp.setFileType(FTPClient.BINARY_FILE_TYPE);

	}

	private void copyFilesTree(FTPClient ftp, String currentRemoteDir, File rootDirLocal, File currentDirectory,
			int count) throws Exception {
		File[] filesInBase = currentDirectory.listFiles();
		ftp.changeWorkingDirectory(currentRemoteDir);
		for (int i = 0; i < filesInBase.length; i++) {
			if (filesInBase[i].isDirectory()) {
				ftp.makeDirectory(filesInBase[i].getName());
				copyFilesTree(ftp, currentRemoteDir + "/" + filesInBase[i].getName(), rootDirLocal, filesInBase[i],
						count);
			} else {
				count++;
				copyFile(ftp, filesInBase[i], currentRemoteDir, count);
			}
		}
		ftp.changeToParentDirectory();
	}

	private void copyFile(FTPClient ftp, File file, String dir, int count) throws Exception {
		for (int j = 0; j < 5; j++) {
			try {
				InputStream in = new FileInputStream(file);
				try {
					ftp.storeFile(dir + "/" + file.getName(), in);
				} finally {
					in.close();
				}
				// ftp.completePendingCommand();
				break;
			} catch (Exception e) {
				System.out.println("File transfer failed");
				if (j == 4) {
					throw e;
				}
			}
		}

		// Notify the observers that a single file was stored
		setChanged();
		notifyObservers(new Integer(count));

	}

	public static FtpServer getFtpClient() throws IOException {
		FtpServer ftp;
		File propertiesFile = new File(DBProperties.DB_PROPERTIES_FILE);
		if (!propertiesFile.exists()) {
		}
		Properties p = new Properties();
		FileInputStream in = null;
		try {
			in = new FileInputStream(propertiesFile);
			p.load(in);
		} catch (Exception e1) {
			e1.printStackTrace();
		}finally{
			if (in!=null){
				in.close();
			}
		}

		ftp = new FtpServer(p.getProperty("ftp.server"), p.getProperty("ftp.user"), p.getProperty("ftp.password"));
		return ftp;
	}

}
