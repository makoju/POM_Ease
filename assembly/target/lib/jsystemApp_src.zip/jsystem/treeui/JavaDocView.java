/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui;

import java.awt.Color;

public interface JavaDocView {

	    public void setContent(String content);
	    
	    public void setBGColor(Color bgColor);

}
