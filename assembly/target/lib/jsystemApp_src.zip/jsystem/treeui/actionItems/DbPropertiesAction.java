/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.actionItems;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;

import jsystem.guiMapping.JsystemMapping;
import jsystem.treeui.DbPropertiesListener;
import jsystem.treeui.publisher.DefineDbPropertiesDialog;

public class DbPropertiesAction extends IgnisAction {

	private static final long serialVersionUID = 1L;
	
	private static DbPropertiesAction action;
	
	private DbPropertiesAction(){
		super();
		putValue(Action.NAME, "Database Properties");
		putValue(Action.SHORT_DESCRIPTION, JsystemMapping.getInstance().getDefineDatabasePropertiesMenuItem());
		putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.ALT_MASK));
		putValue(Action.ACTION_COMMAND_KEY, "define-database-properties");
	}
	
	public static DbPropertiesAction getInstance(){
		if (action == null){
			action =  new DbPropertiesAction();
		}
		return action;
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		DefineDbPropertiesDialog db = new DefineDbPropertiesDialog("Database Properties", true, null);
		DbPropertiesListener dbPropertiesListener = new DbPropertiesListener(db);
		DefineDbPropertiesDialog.okButton.addActionListener(dbPropertiesListener);
		DefineDbPropertiesDialog.cancelButton.addActionListener(dbPropertiesListener);
		db.requestFocus();
		db.setVisible(true);
		db.dispose();
	}

}
