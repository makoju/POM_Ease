/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.actionItems;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.Action;
import javax.swing.KeyStroke;

import jsystem.guiMapping.JsystemMapping;
import jsystem.treeui.TestRunner;
import jsystem.treeui.images.ImageCenter;
import jsystem.treeui.publisher.PublisherManager;
import jsystem.treeui.publisher.PublisherRunInfoFrame;

public class PublishXmlResultAction extends IgnisAction {

	private static final long serialVersionUID = 1L;
	
	private static PublishXmlResultAction action;
	
	private PublishXmlResultAction(){
		super();
		putValue(Action.NAME, "Publish Xml Result");
		putValue(Action.SHORT_DESCRIPTION, JsystemMapping.getInstance().getPublishButton());
		putValue(Action.SMALL_ICON, ImageCenter.getInstance().getImage(ImageCenter.ICON_PUBLISH));
		putValue(Action.LARGE_ICON_KEY, ImageCenter.getInstance().getImage(ImageCenter.ICON_PUBLISH));
		putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.ALT_MASK));
		putValue(Action.ACTION_COMMAND_KEY, "publish-xml-result");
	}
	
	public static PublishXmlResultAction getInstance(){
		if (action == null){
			action =  new PublishXmlResultAction();
		}
		return action;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		PublisherRunInfoFrame.setParent(TestRunner.treeView);
		(new Thread() {
			public void run() {
				PublisherManager.getInstance().getPublisher().publish();
			}
		}).start();
	}

}
