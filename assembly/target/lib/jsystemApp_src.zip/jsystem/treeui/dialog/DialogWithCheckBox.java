/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.dialog;

import java.awt.GridLayout;

import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import jsystem.framework.FrameworkOptions;
import jsystem.framework.JSystemProperties;
import jsystem.treeui.TestRunner;

/**
 * General dialog with checkBox for different Framework options 
 * 
 * @author Nizan Freedman
 *
 */
public class DialogWithCheckBox extends JDialog {

	private static final long serialVersionUID = -1570893402282756718L;
	
	/**
	 * Show a confirm dialog with given title, message and checkBox String.
	 * 
	 * @param title	The dialog title
	 * @param message	The dialog message
	 * @param checkBox	The checkBox String
	 * @param option	The FrameworkOption to be read and modified if checkbox is marked
	 * @return
	 */
	public static int showConfirmDialog(String title, String message, String checkBox, FrameworkOptions option) {
		JCheckBox cb = new JCheckBox(checkBox);

		JLabel label = new JLabel(message);

		JLabel separator = new JLabel();

		JPanel panel = new JPanel();

		panel.setLayout(new GridLayout(3, 1));

		panel.add(label);

		panel.add(separator);

		panel.add(cb);

		/**
		 * read property from jsystem.properties
		 */
		String editProperty = JSystemProperties.getInstance().getPreference(option);
		
		int answer = JOptionPane.YES_OPTION;
		
		if (editProperty == null || "false".equals(editProperty)) {
			 answer = JOptionPane.showConfirmDialog(TestRunner.treeView, panel,
					title, JOptionPane.YES_NO_CANCEL_OPTION);
		}
		
		if (cb.isSelected()) {
			JSystemProperties.getInstance().setPreference(option,true + "");
		}

		return answer;
	}


}
