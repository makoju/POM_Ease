/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.interfaces;

public interface JsystemPropertiesChangeListener {
	public void jsystemPropertiesChanged();
}
