/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.publisher;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import jsystem.framework.DBProperties;
import jsystem.guiMapping.JsystemMapping;

/**
 * 
 * panel that dispalys db properties
 * allow to save db.properties to the file
 *
 */
public class DbPropertiesPanel extends JPanel  implements ItemListener {
	public enum DbPropertiesSource {
		DEFAULT_VALUES,
		USER_DIALOG_VALUES;
	}
    
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel caption;
	JComboBox driverCombo,typeCombo; 
	JTextField hostTxt,nameTxt,userTxt,portTxt,applicationServerUrlText;
	JPasswordField passwordField;
	JPanel captionPanel,mainPanel;
	private String driversNames[]={"com.mysql.jdbc.Driver"};
	private String typeNames[]={   "mysql                                          "};
	private DBProperties db;
	private String prDriver,prType,prHost,prName,prUser,prPassword,prPort,prServerId;
	boolean flag=true;
	DbPropertiesPanel(String title)
	{
		
		/**
		 * get db properties from file
		 * or show default properties
		 */
		int selIndx=0;
		try {
			db=DBProperties.getInstance();
			extractProperties( db);
		} catch (Exception e) {
			extractProperties(null);
		}
		
		
		/**
		 * create gui elements
		 */
		setLayout(new BorderLayout());
		captionPanel =new JPanel() ;
		caption =new JLabel(title);
		captionPanel.add(caption);
		captionPanel.setBorder(BorderFactory.createEtchedBorder());
		captionPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		mainPanel =new JPanel() ;
		mainPanel.setLayout(new GridLayout(4, 2,10,10));
		mainPanel.setBorder(BorderFactory.createEtchedBorder());
		
		
		
		
        JPanel typePanel=new JPanel();
		typeCombo=new JComboBox(typeNames);
		typeCombo.setName(JsystemMapping.getInstance().getDbPropertiesTypeJComboBox());
		typeCombo.setSelectedIndex(selIndx);
		typeCombo.setBackground(new Color(0xf6, 0xf6, 0xf6));
		typePanel.add(typeCombo);
		typePanel.setBorder(BorderFactory.createTitledBorder("Database Type"));
		typePanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		typeCombo.addItemListener(this);
		mainPanel.add(typePanel);
		
		
		
		JPanel driverPanel=new JPanel();
		driverCombo=new JComboBox(driversNames);
		driverCombo.setName(JsystemMapping.getInstance().getDbPropertiesDriverCombobox());
		driverCombo.setSelectedIndex(selIndx);
		driverCombo.setBackground(new Color(0xf6, 0xf6, 0xf6));
		driverPanel.add(driverCombo);
		driverPanel.setBorder(BorderFactory.createTitledBorder("Database Driver"));
		driverPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		driverCombo.addItemListener(this);
		mainPanel.add(driverPanel);
		
		
	
		JPanel hostPanel=new JPanel();
		hostTxt=new JTextField(prHost,20);
		hostTxt.setName(JsystemMapping.getInstance().getDbPropertiesHostTextField());
		hostPanel.setBorder(BorderFactory.createTitledBorder("Database Host"));
		hostPanel.add(hostTxt);
		hostPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		mainPanel.add(hostPanel);
	
		
		
		
		JPanel namePanel=new JPanel();
		nameTxt=new JTextField(prName,20);
		nameTxt.setName(JsystemMapping.getInstance().getDbPropertiesNameTextField());
		namePanel.setBorder(BorderFactory.createTitledBorder("Database Name"));
		namePanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		namePanel.add(nameTxt);
		mainPanel.add(namePanel);
		
		
		
		JPanel userPanel=new JPanel();
		userTxt=new JTextField(prUser,20);
		userTxt.setName(JsystemMapping.getInstance().getDbPropertiesUserTextField());
		userPanel.setBorder(BorderFactory.createTitledBorder("Database User Name"));
		userPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		userPanel.add(userTxt);
		mainPanel.add(userPanel);
		
		
		

		JPanel passwordPanel=new JPanel();
		passwordField = new JPasswordField(prPassword,20);
		passwordPanel.setName(JsystemMapping.getInstance().getDbPropertiesPasswordField());
		passwordPanel.setBorder(BorderFactory.createTitledBorder("Database Password"));
		passwordPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		passwordPanel.add(passwordField);
		mainPanel.add(passwordPanel); 

		JPanel portPanel=new JPanel();
		portTxt=new JTextField(prPort,20);
		portTxt.setName(JsystemMapping.getInstance().getDbPropertiesPortTextField());
		portPanel.setBorder(BorderFactory.createTitledBorder("Application Server Port"));
		portPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		portPanel.add(portTxt);
		mainPanel.add(portPanel);
		
		
	
		JPanel serverPanel=new JPanel();
		applicationServerUrlText=new JTextField(prServerId,20);
		applicationServerUrlText.setName(JsystemMapping.getInstance().getDbPropertiesServerIpTextField());
		serverPanel.setBorder(BorderFactory.createTitledBorder("Application Server Url"));
		serverPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		serverPanel.add(applicationServerUrlText);
		mainPanel.add(serverPanel);
		
		
		
		add(captionPanel,BorderLayout.NORTH);
		add(mainPanel,BorderLayout.CENTER);
		setBackground();
		
	}
	
	
	
	/**
	 * We call this function before the GUI was loaded, and therefore all GUI objects 
	 * Containing the db properties, yet not exists 
	 */
	public void save(DbPropertiesSource source) {
		if (source == DbPropertiesSource.DEFAULT_VALUES) {
			DBProperties.saveRunData(prDriver, prType, prHost, prName, prUser, prPassword, prPort, prServerId);
		} else {
			String driver = ((String)driverCombo.getSelectedItem()).trim();
			String type = ((String)typeCombo.getSelectedItem()).trim();
			String host = hostTxt.getText().trim();
			String dbname = nameTxt.getText().trim();
			String user = userTxt.getText().trim();
			String password = new String(passwordField.getPassword());
			String port =  portTxt.getText().trim();
			String serverIP =  applicationServerUrlText.getText().trim();
			DBProperties.saveRunData(driver, type, host, dbname, user, password, port, serverIP);
		}
	}
	

	private void setBackground() {
		setBackground(new Color(0xf6, 0xf6, 0xf6));
		mainPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
	}
	
	
	/**
	 * get properties from file or fill with default properties
	 */
	private void extractProperties(DBProperties db)
	{
		if(db==null)
		{
			 prDriver=new String("com.mysql.jdbc.Driver");
			 prType=new String("mysql");
			 prHost=new String("localhost");
			 prName=new String("jsystem");
			 prUser=new String("root");
			 prPassword=new String("root");
			 prPort=new String("8080");
			 prServerId=new String("localhost");
			 save(DbPropertiesSource.DEFAULT_VALUES);
		}
		else
		{
			 prDriver=new String(db.getProperty("db.driver"));
			 prType=new String(db.getProperty("db.type"));
			 prHost=new String(db.getProperty("db.host"));
			 prName=new String(db.getProperty("db.dbname"));
			 prUser=new String(db.getProperty("db.user"));
			 prPassword=new String(db.getProperty("db.password"));
			 prPort=new String(db.getProperty("browser.port"));
			 prServerId=new String(db.getProperty("serverIP"));
		}
	}
	
	
	public static void main(String[] args) {
		JFrame fr=new JFrame();
		 DbPropertiesPanel w=new DbPropertiesPanel("DDd");
		 fr.add(w);
		 fr.setSize(100,100);
		 fr.setVisible(true);
	}


    /**
     * set type suitable to driver and vice versa 
     */
	public void itemStateChanged(ItemEvent arg) {
		if (arg.getSource()==driverCombo && flag==true) {   
			flag=false;
			typeCombo.setSelectedIndex(driverCombo.getSelectedIndex());
		} else if(arg.getSource()==typeCombo&& flag==true) {   
			flag=false;
			driverCombo.setSelectedIndex(typeCombo.getSelectedIndex());
		} else {
			flag=true;
		}
	}

	
	public String getDialogDbType() {
		return  ( (String)typeCombo.getSelectedItem()).trim();
	}
	public String getDialogDbDriver() {
		return  ( (String)driverCombo.getSelectedItem() ).trim();
	}
	public String getDialogDbHost() {
		return  hostTxt.getText().trim();
	}
	public String getDialogDbName() {
		return  nameTxt.getText().trim();
	}
	public String getDialogDbUser() {
		return  userTxt.getText().trim();
	}
	public String getDialogDbPassword() {
		return  new String(passwordField.getPassword());
	}
	public String getDialogApplicationServerPort() {
		return  portTxt.getText().trim();
	}
	public String getDialogApplicationServerUrl() {
		return  applicationServerUrlText.getText().trim();
	}
	
	/**
	 * reset dialog window values from db file
	 * @throws Exception
	 */
	public void resetToFileData() throws Exception{
		extractProperties(DBProperties.getInstance());
		typeCombo.setSelectedItem(prType);
		driverCombo.setSelectedItem(prDriver);
		hostTxt.setText(prHost);
		nameTxt.setText(prName);
		userTxt.setText(prUser);
		passwordField.setText(prPassword);
		portTxt.setText(prPort);
		applicationServerUrlText.setText(prServerId);
	}
	
}
