/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.publisher;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.SwingUtilities;

import jsystem.extensions.report.xml.DbPublish;
import jsystem.framework.DBProperties;
import jsystem.framework.FrameworkOptions;
import jsystem.framework.JSystemProperties;
import jsystem.runner.ErrorLevel;
import jsystem.runner.agent.publisher.Publisher;
import jsystem.runner.agent.publisher.PublisherProgress;
import jsystem.runner.agent.reportdb.tables.Run;
import jsystem.treeui.DBConnectionListener;
import jsystem.treeui.DbGuiUtility;
import jsystem.utils.StringUtils;
import jsystem.utils.UploadRunner;

public class DefaultPublisher implements Publisher, ActionListener, DBConnectionListener {

	boolean debug = true;
	private Run run;

	// Shows the progress of sending via FTP and storint in DB
	private PublisherProgress progressBar;
	private static Logger log = Logger.getLogger(DefaultPublisher.class.getName());
	private PublisherRunInfoFrame frame;
	private DbPublish reportInfo;
	private long reportIndex;
	private static Connection conn;
	private UploadRunner uploader;
	public Thread thread;
	private boolean save = false;
	
	
	public void publish() {
		try {
			createReport();
		} catch (Exception e) {
			DbGuiUtility.publishError("Publish error- fail to connect to the Database", "Fail to connect to the Database\n\n"
					+ "Try the following :\n\n" + "1)Check that Database Server is on\n\n" + "2)Check You Database Properties \n\n"
					+ StringUtils.getStackTrace(e), ErrorLevel.Error);
		}

	}

	/**
	 * create a publish form
	 * @throws Exception
	 */
	private void createReport() throws Exception {
		reportIndex = System.currentTimeMillis();
		DbGuiUtility.showMsgWithTime("publish.bypass = true");
		File reportCurrent = new File(JSystemProperties.getInstance().getPreference(FrameworkOptions.LOG_FOLDER), "current");
		reportInfo = new DbPublish(reportCurrent);


		// display the Run Form
		run = reportInfo.getRunForForm(reportIndex);
		frame = new PublisherRunInfoFrame(run);

		progressBar = PublisherRunInfoFrame.getProgress();
		progressBar.setBarValue(0);

		frame.addActionListener(this);

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				frame.showMy();
			}
		});
		/**
		 * check and create db.properties file , 
		 * false means the user canceled configuration
		 */
		if (!checkDBPropertiesFile()){
			return;
		}

		frame.enableButtons(false);
		DbGuiUtility.validateDialogParams(this, frame.getDb(), true);
	}

	/**
	 * start the publishing:
	 * a. zip and upload file
	 * b. publish to DB
	 *
	 */
	public void startPublish() {
		(new Thread(){public void run(){
		frame.setStartedPublish(true);
		/**
		 * first, check connection to DB and check that all tables exist
		 * conn will be null if no connection exists or tables were missing
		 */

		int numOfTests = reportInfo.getNumberOfTests() - 1;
		progressBar.setBarMinMax(0, (numOfTests+1) * 4);
		progressBar.setBarValue(0);
		/**
		 * zip current log directory and try to upload
		 * false means fail to upload
		 */
		if (!uploadFile(reportInfo, reportIndex)) {
			publishAborted();
			return;
		}

		/**
		 * finally, if upload was successful, add to db
		 * false means problem with insertion to DB
		 */
		if (!writeToDB(reportInfo, reportIndex, conn, numOfTests)) {
			// TODO delete directory on remote
			publishAborted();
			return;
		}
		DBProperties.closeConnectionIfExists(conn);
		}}).start();

	}
	
	/**
	 * signal that a publish was terminated and do the necessary actions
	 *
	 */
	public void publishAborted(){
		progressBar.setBarValue(0);
		frame.setStartedPublish(false);
	}


	/**
	 * check that there is a db.properties file present, creates one if not
	 * @return
	 * 		true if file exists
	 */
	private boolean checkDBPropertiesFile() {
		/**
		 * if not exist db.properties file create it
		 */
		try {
			DBProperties.getInstance();
			return true;
		} catch (Exception e) {
			frame.showDBProperties();
			/**
			 * if cancel pressed return
			 */
		}
		return false;
	}


	/**
	 * zip and upload log files to server
	 * 
	 * 
	 * 1.You need to add to db.properties line serverIP="you server ip"
	 * 
	 * 2.If you server use port other than 8080 you must also change
	 * this in db.properties ->browser.port
	 *
	 * 
	 * serverUploadUrl=http://"you server ip"/reports/upload
	 * 
	 */
	private boolean uploadFile(DbPublish reportInfo, long reportIndex) {
		File tempDir = new File(JSystemProperties.getInstance().getPreference(FrameworkOptions.LOG_FOLDER));

		File tempCurrentDir = new File(tempDir, "current");
		uploader = new UploadRunner(tempCurrentDir, reportIndex);
		
		DbGuiUtility.showMsgWithTime("Uploading file to reports Server");
		int max = progressBar.getMaxValue();
		
		try {
			uploader.zipFile();
		} catch (Exception e) {
			DbGuiUtility.publishError("Publish error- fail to zip file for publishing",
					"check that there is enought space for zipping\n\n" + StringUtils.getStackTrace(e), ErrorLevel.Error);
			return false;
		}
		progressBar.setBarValue(max / 4);
		
		try {
			uploader.upload();
		} catch (Exception e) {
			DbGuiUtility.publishError("Publish error- fail to upload file to reports server",
					"check that the reports server is running\n\n" + StringUtils.getStackTrace(e), ErrorLevel.Error);
			return false;
		}
		progressBar.setBarValue(max / 2);
		return true;
	}

	/**
	 * write all data to DB
	 * @param reportInfo
	 * 			the DbPublish object
	 * @param reportIndex
	 * 			the long id of the report
	 * @param conn
	 * 			the connection to the DB
	 * @param numOfTests
	 * 			the number of tests to publish
	 * @return	true if all succeeded
	 */
	private boolean writeToDB(DbPublish reportInfo, long reportIndex, Connection conn, int numOfTests) {
		try {
			DbGuiUtility.showMsgWithTime("creating report information from xml files");
			final int runIndex = reportInfo.addRunInfo(reportIndex, conn);

			if (runIndex == -1) {
				return false;
			}

			// publish tests info
			reportInfo.publishTestsInfo(conn, progressBar, runIndex);
			progressBar.setBarValue(numOfTests);
			DbGuiUtility.showMsgWithTime("setings tests data");
			DbGuiUtility.showMsgWithTime("finished processing tests information for publish");

			/**
			 * close PublisherRunInfoFrame
			 */
			frame.close();
			PublisherTreePanel.setPublishBtnEnable(true);
			DbGuiUtility.showMsgWithTime("finished publishing");
			log.log(Level.FINEST, "finished publishing");
			return true;
			
		} catch (Exception e) {
			frame.setStartedPublish(false);
			DbGuiUtility.publishError("Publish error- fail to to connect to the Database", "Fail to connect to the Database\n\n"
					+ "Try the following :\n\n" + "1)Check that Database Server is on\n\n" + "2)Check You Database Properties \n\n"
					+ StringUtils.getStackTrace(e), ErrorLevel.Error);
		}
		return false;
	}
	
	
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source.equals(PublisherRunInfoFrame.okButton)) {
			run = frame.saveRunData();
			startPublish();
		} else if (source.equals(PublisherRunInfoFrame.cancelButton)) {
			frame.dispose();
			DBProperties.closeConnectionIfExists(conn);
		} else if (source.equals(DefineDbPropertiesDialog.okButton)) {
			save = true;
			DbGuiUtility.validateDialogParams(this, frame.getDb(), true);
		} else if (source.equals(DefineDbPropertiesDialog.cancelButton)) {
			DbGuiUtility.validateDialogParams(this, false);
		}
		

	}

	public void connectionIsOk(boolean status,Connection con) {
		DefaultPublisher.conn = con;
		frame.connectionToDbExist(status);
		if (save && status){
				DbGuiUtility.saveDialogToDb(frame.getDb(), conn);
		}
		save = false;
	}

}