/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.publisher;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import jsystem.guiMapping.JsystemMapping;
import jsystem.treeui.publisher.DbPropertiesPanel.DbPropertiesSource;

/**
 * 
 * display DbPropertiesPanel when save pressed save db properties to the file
 * 
 */
public class DefineDbPropertiesDialog extends JDialog implements ActionListener {
	
	private static final long serialVersionUID = 1L;

	private DbPropertiesPanel db;

	public static JButton okButton, cancelButton;

	boolean cancel = true;

	boolean exitOnPress = false;

	RunInfoFrameListener listener = null;
	
	public DefineDbPropertiesDialog(String caption, boolean exitOnPress,Frame parent) {
		super(parent,true);
		setAlwaysOnTop(true);
		getContentPane().setLayout(new BorderLayout());
		setTitle("Database Properties");
		db = new DbPropertiesPanel(caption);
		okButton = new JButton("Save");
		okButton.addActionListener(this);
		okButton.setName(JsystemMapping.getInstance().getDbPropertiesOkButton());

		cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(this);
		JPanel south = new JPanel();
		south.add(okButton);
		south.add(cancelButton);
		south.setBackground(new Color(0xf6, 0xf6, 0xf6));
		add(db, BorderLayout.CENTER);
		add(south, BorderLayout.SOUTH);

		setSize(600, 375);
		setLocation();
		requestFocus();
		this.exitOnPress = exitOnPress;
		setResizable(false);
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		
		/**
         * Pressing the X will be considered as pressing the cancel button
         */
        addWindowListener(new WindowAdapter() {
	           public void windowClosing(WindowEvent event) {
	        	   cancelButton.doClick();
	           } 
	        });
		setVisible(false);
		

	}
	
	public synchronized void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source.equals(cancelButton)) {
			if (listener == null && exitOnPress == false) {
				cancel = true;
				PublisherTreePanel.setPublishBtnEnable(true);
				notifyAll();
			}
			/**
			 * put PublisherRunInfoFrame to the top
			 */
			if (listener != null) {
				listener.visible(true);
			}
			if (exitOnPress)
				dispose();
		}
	}

	public synchronized int getValue() throws InterruptedException {
		wait();
		if (cancel)
			return 1;
		else
			return 0;
	}

	public void setListener(RunInfoFrameListener listener) {
		this.listener = listener;
	}

	public void setLocation() {

		Point p1 = getLocation();
		Dimension d1 = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension d2 = getSize();

		int xx = p1.x + (d1.width - d2.width) / 2;
		int yy = p1.y + (d1.height - d2.height) / 2;

		if (xx < 0) {
			xx = 0;
		}
		if (yy < 0) {
			yy = 0;
		}

		setLocation(xx, yy);
	}

	public boolean isCancel() {
		return cancel;
	}

	public void setCancel(boolean cancel) {
		this.cancel = cancel;
	}

	public void addActionListener(ActionListener listener){
		okButton.addActionListener(listener);
		cancelButton.addActionListener(listener);
	}
	
	public void runSaveDB(){
		db.save(DbPropertiesSource.USER_DIALOG_VALUES);
		cancel = false;
		/**
		 * put PublisherRunInfoFrame to the top
		 */
		if (listener != null) {
			listener.visible(true);
		}
		if (exitOnPress)
			dispose();
	}

	public DbPropertiesPanel getDb() {
		return db;
	}

	public void setDb(DbPropertiesPanel db) {
		this.db = db;
	}
	
	public void resetToFileData() throws Exception{
		db.resetToFileData();
	}
}
