/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.publisher;

import java.io.File;

import jsystem.extensions.report.html.HtmlTestReporter;
import jsystem.extensions.report.sumextended.HtmlSummaryReporterExtentsion;
import jsystem.runner.agent.publisher.Publisher;
import jsystem.treeui.FtpServer;
import jsystem.utils.BrowserLauncher;
import jsystem.utils.FileUtils;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * used to create the result html report and move them to the Ftp/Html server.
 * 
 * @author guy.arieli
 */
public class FtpPublisher implements Publisher {

	public FtpPublisher() {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jsystem.treeui.publisher.Publisher#publish()
	 */
	public void publish() {
		System.out.println("ftp publish");
		try {
			createReport();
		} catch (Exception e) {
			PublisherTreePanel.setPublishBtnEnable(true);
			e.printStackTrace();
		}

	}

	private void createReport() throws Exception {
		long reportIndex = System.currentTimeMillis();
		File tempDir = new File(System.getProperty("user.dir"), "log/tmp");
		if (tempDir.exists()) {
			FileUtils.deltree(tempDir);
		} else {
			tempDir.mkdirs();
		}
		File reportTempDir = new File(tempDir, Long.toString(reportIndex));
		reportTempDir.mkdirs();

		HtmlSummaryReporterExtentsion extReport = new HtmlSummaryReporterExtentsion(new File(reportTempDir,
				"/current/summaryExtendded.html"));
		HtmlTestReporter reporter = new HtmlTestReporter(reportTempDir.getPath(), true);
		Document doc = FileUtils.readDocumentFromFile(new File("reports.0.xml"));
		NodeList elements = (NodeList) XPathAPI.selectNodeList(doc, "/reports/package/test");
		for (int i = 0; i < elements.getLength(); i++) {
			if (elements.item(i) instanceof Element) {
				Element e = (Element) elements.item(i);
				Element p = (Element) e.getParentNode();
				String packageName = p.getAttribute("name");
				String[] name = e.getAttribute("name").split("\\.");
				extReport.startTest(null);
				boolean testStatus = true;
				;
				if (e.getAttribute("status").equals("false")) {
					testStatus = false;
					reporter.addError(null, null);
					extReport.addError(null, null);
				}
				String testMessage = e.getAttribute("message");
				if (testMessage != null) {
					reporter.report(testMessage, null, true, true, false);
				}

				NodeList steps = e.getChildNodes();
				long startTime = Long.parseLong(e.getAttribute("time"));
				long endTime = 0;
				int index = 0;
				for (int j = 0; j < steps.getLength(); j++) {
					if (steps.item(j) instanceof Element) {
						Element step = (Element) steps.item(j);
						if (index == (steps.getLength() - 1)) {
							endTime = Long.parseLong(step.getAttribute("time"));
						}
						String title = step.getAttribute("name");
						String message = step.getAttribute("message");
						boolean status = true;
						boolean ignore = false;
						if (step.getAttribute("status").equals("false")) {
							status = false;
							if (testStatus == true) {
								ignore = true;
							}
						}
						boolean bold = Boolean.getBoolean(step.getAttribute("bold"));
						reporter.report(title, message, status, bold, ignore);
						index++;
					}
				}
				long runningTime = endTime - startTime;
				if (runningTime < 0) {
					runningTime = 0;
				}
				reporter.endTest(packageName, name[0], name[1], runningTime);
				extReport.endTest(e.getAttribute("name"), packageName, runningTime, e.getAttribute("message"));
			}
		}
		reporter = null;
		extReport = null;
		FtpServer ftp = FtpServer.getFtpClient();
		String resultLink = ftp.publishResults(new File(reportTempDir, "current"), reportIndex);
		BrowserLauncher.openURL(resultLink);
		FileUtils.deltree(reportTempDir);

	}

}
