/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.publisher;

import java.util.logging.Logger;

import jsystem.runner.agent.publisher.Publisher;

/**
 * This class is used to load the publisher. The publisher class is read from
 * the jsystem.properties file under 'publisher'
 * 
 * @author guy.arieli
 * 
 */
public class PublisherManager {
	private static Logger log = Logger.getLogger(PublisherManager.class.getName());

	private static PublisherManager manager = null;

	/**
	 * Use it to get an instance of the publisher manager.
	 * 
	 * @return PublisherManager
	 */
	public static PublisherManager getInstance() {
		if (manager == null) {
			manager = new PublisherManager();
		}
		return manager;
	}


	private PublisherManager() {

	}

	/**
	 * used to return the publisher
	 * 
	 * @return the publisher object
	 */
	public Publisher getPublisher() {
		return  new DefaultPublisher();
	}

}
