/*
 * Created on Aug 23, 2005
 * 
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.publisher;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Logger;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import jsystem.runner.agent.publisher.PublisherProgress;
import jsystem.runner.agent.reportdb.tables.Run;
import jsystem.utils.DateUtils;



/**
 * @author Uri.Koaz
 */

public class PublisherRunInfoFrame extends JFrame implements ActionListener , RunInfoFrameListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static JTextField fieldSutName;

	private static JTextField fieldVersion;

	private static JTextField fieldBuild;

	private static JTextField fieldStation;

	private static JTextField fieldStartTime;

	private static JTextField fieldRunTest;

	private static JTextField fieldFailTest;

	private static JTextField fieldDescription;

	public static JButton okButton;

	public static JButton cancelButton;

	private JPanel panel1;

	private JPanel panel2;

	private JPanel panel3;

	private JPanel panel4;

	private JPanel panel5;

	private JPanel panel7;

	private JPanel panel8;

	private JPanel panel9;

	private JPanel panel10,main;
   
	Run run;

	boolean cancel = true;

	private JPanel captionPanel;

	private String title="Run Properties";

	private JLabel caption;

	private static JButton dbPropertiesButton;

	private JPanel dbPanel;
	
	private static PublisherProgress progress = new PublisherProgress();
	
	private DefineDbPropertiesDialog db;
	
	private static Frame parent;
	
	/**
	 * this is the actual frame instance that we see
	 */
	private static JDialog actualFrame;

	private boolean canClose=false; 
	
	private static Logger log = Logger.getLogger(PublisherRunInfoFrame.class.getName());
	
	public PublisherRunInfoFrame(Run run) {
		actualFrame = new JDialog(parent,true);
		actualFrame.setResizable(false);
		
		actualFrame.setAlwaysOnTop(true);
        
		db = new DefineDbPropertiesDialog("Database Properties",true,this);
		db.setListener(this);
		this.run = run;
		
		actualFrame.getContentPane().setLayout(new BorderLayout());
		actualFrame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		
		main=new JPanel();
		
		main.setLayout(new GridLayout(11, 3));
		actualFrame.setTitle(title);
		
		actualFrame.setBackground(new Color(0xf6, 0xf6, 0xf6));
		panel1 = new JPanel();
		panel2 = new JPanel();
		panel3 = new JPanel();
		panel4 = new JPanel();
		panel5 = new JPanel();
		panel7 = new JPanel();
		panel8 = new JPanel();
		panel9 = new JPanel();
		panel10 = new JPanel();
         
		
		actualFrame.setBackground(new Color(0xf6, 0xf6, 0xf6));
		panel1.setBackground(new Color(0xf6, 0xf6, 0xf6));
		
		panel2.setBackground(new Color(0xf6, 0xf6, 0xf6));
		
		panel3.setBackground(new Color(0xf6, 0xf6, 0xf6));
		
		panel4.setBackground(new Color(0xf6, 0xf6, 0xf6));
		
		panel5.setBackground(new Color(0xf6, 0xf6, 0xf6));
		
	
		
		panel7.setBackground(new Color(0xf6, 0xf6, 0xf6));
		
		panel8.setBackground(new Color(0xf6, 0xf6, 0xf6));
		
		panel9.setBackground(new Color(0xf6, 0xf6, 0xf6));
		
		panel10.setBackground(new Color(0xf6, 0xf6, 0xf6));
		
		okButton = new JButton("Save");
		cancelButton = new JButton("Cancel");
        dbPropertiesButton=new JButton("Change Database Properties");
		
        /**
         * Pressing the X will be considered as pressing the cancel button
         */
        actualFrame.addWindowListener(new WindowAdapter() {
	           public void windowClosing(WindowEvent event) {
	        	   cancelButton.doClick();
	           } 
	        });
        
		fieldSutName = new JTextField(45);
		fieldSutName.setText(run.getSetupName());
		panel1.setBorder(BorderFactory.createTitledBorder("Sut Name"));
		panel1.add(fieldSutName);

		fieldVersion = new JTextField(45);
		fieldVersion.setText(run.getVersion());
		panel2.setBorder(BorderFactory.createTitledBorder("Version"));
		panel2.add(fieldVersion);

		fieldBuild = new JTextField(45);
		fieldBuild.setText(run.getBuild());
		panel3.setBorder(BorderFactory.createTitledBorder("Build"));
		panel3.add(fieldBuild);

		fieldStation = new JTextField(45);
		fieldStation.setText(run.getStation());
		panel4.setBorder(BorderFactory.createTitledBorder("Station"));
		panel4.add(fieldStation);

		fieldStartTime = new JTextField(45);
		fieldStartTime.setText(DateUtils.getDate(run.getStartTime()));
		fieldStartTime.setBackground(new Color(0xf6, 0xf6, 0xf6));
		fieldStartTime.setEditable(false);
		panel5.setBorder(BorderFactory.createTitledBorder("Start Time"));
		panel5.add(fieldStartTime);


		fieldRunTest = new JTextField(45);
		fieldRunTest.setText(run.getRunTests() + "");
	    fieldRunTest.setBackground(new Color(0xf6, 0xf6, 0xf6));;
		fieldRunTest.setEditable(false);
		panel7.setBorder(BorderFactory.createTitledBorder("Run Test"));
		panel7.add(fieldRunTest);

		fieldFailTest = new JTextField(45);
		fieldFailTest.setText(run.getFailTests() + "");
		fieldFailTest.setBackground(new Color(0xf6, 0xf6, 0xf6));;
		fieldFailTest.setEditable(false);
		panel8.setBorder(BorderFactory.createTitledBorder("Fail Test"));
		panel8.add(fieldFailTest);

		fieldDescription = new JTextField(45);
		fieldDescription.setText(run.getDescription());
		panel9.setBorder(BorderFactory.createTitledBorder("Description"));
		panel9.add(fieldDescription);

		progress.setBarValue(0);
		panel10.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		panel10.add(okButton,c);
		c.gridx = 1;
		panel10.add(cancelButton,c);
		c.gridy = 1;
		c.gridx = 0;
		c.gridwidth = 2;
		panel10.add(progress,c);
		panel10.setSize(48,15);
		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
        dbPropertiesButton.addActionListener(this);

        dbPanel=new JPanel();
        dbPanel.setSize(48,15);
        dbPanel.add(dbPropertiesButton);       
        dbPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
        dbPanel.setBorder(BorderFactory.createTitledBorder(""));
        
        
		captionPanel =new JPanel() ;
		caption =new JLabel(title);
		caption.setForeground( Color.BLUE);
		captionPanel.add(caption);
		captionPanel.setBorder(BorderFactory.createEtchedBorder());
		captionPanel.setBackground(new Color(0xf6, 0xf6, 0xf6));
		main.add( captionPanel);
		main.add(panel9);
		main.add(panel1);
		main.add(panel2);
		main.add(panel3);
		main.add(panel4);
		main.add(panel5);
		main.add(panel7);
		main.add(panel8);
		
		main.add(dbPanel);
		
		main.add(panel10);
		actualFrame.add(main);//actualFrame.getContentPane().add(main,BorderLayout.CENTER);
		
	}
	
	public void addActionListener(ActionListener listener){
		okButton.addActionListener(listener);
		cancelButton.addActionListener(listener);
		db.addActionListener(listener);
	}
	
	/**
	 * set frame to center of the screen
	 *
	 */
	public void setLocation()
	{

	    Point p1 = actualFrame.getLocation();
	    Dimension d1 = Toolkit.getDefaultToolkit().getScreenSize();
	    Dimension d2 = actualFrame.getSize();
	 
	    int xx = p1.x+(d1.width-d2.width)/2;
	    int yy = p1.y+(d1.height-d2.height)/2;
	 
	    if (xx < 0) { xx = 0; }
	    if (yy < 0) { yy = 0; }
	 
	    actualFrame.setLocation(xx,yy);
	} 
	public String getDescription() {
		return fieldDescription.getText();
	}

	public String getVersion() {
		return fieldVersion.getText();
	}

	public String getBuild() {
		return fieldBuild.getText();
	}

	public String getSetupName() {
		return fieldSutName.getText();
	}
	
	public String getStation() {
		return fieldStation.getText();
	}

	public void showMy() {
		actualFrame.pack();
		setLocation();
		actualFrame.setVisible(true);
		actualFrame.setResizable(false);
	}
    
	public synchronized void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
			
		if (source.equals(dbPropertiesButton)) {
			showDBProperties();
		}
	}

	
	public boolean isCanClose()
	{
		return canClose;

	}
	public void setClose(boolean v)
	{
		canClose=v;
	}
	public static enum EnumAnswer
	{
		Save,Cancel;
	}
	
	/**
	 * after call to this function program wait 
	 * until one of the buttons is pressed
	 * @return
	 * @throws InterruptedException
	 */
	public synchronized int getValue() throws InterruptedException
	{
		wait();
		if(cancel)
			return 1;
		else return 0;
	}
 
	public static final void main(String[] args) throws InterruptedException {
		PublisherRunInfoFrame frame = new PublisherRunInfoFrame(new Run());
		frame.showMy();
	}

	public boolean isCancel() {
		return cancel;
	}

	public void setCancel(boolean cancel) {
		this.cancel = cancel;
	}
	public void close() {
		actualFrame.dispose();
	}
	
	public void visible(boolean visible) {
		if(db!=null)
			db.dispose();
	}
	
	public static PublisherProgress getProgress(){
		return progress;
	}
	
	public void enableButtons(boolean enable){
		cancelButton.setEnabled(enable);
		okButton.setEnabled(enable);
		dbPropertiesButton.setEnabled(enable);
		fieldSutName.setEnabled(enable);
		fieldVersion.setEnabled(enable);
		fieldBuild.setEnabled(enable);
		fieldStation.setEnabled(enable);
        fieldStartTime.setEnabled(enable);
		fieldRunTest.setEnabled(enable);
        fieldFailTest.setEnabled(enable);
        fieldDescription.setEnabled(enable);
	}
	
	public void connectionToDbExist(boolean enable){
		dbPropertiesButton.setEnabled(true);
		cancelButton.setEnabled(true);
		okButton.setEnabled(enable);
		fieldSutName.setEnabled(enable);
		fieldVersion.setEnabled(enable);
		fieldBuild.setEnabled(enable);
		fieldStation.setEnabled(enable);
        fieldStartTime.setEnabled(enable);
		fieldRunTest.setEnabled(enable);
        fieldFailTest.setEnabled(enable);
        fieldDescription.setEnabled(enable);
	}
	
	public void setStartedPublish(boolean set){
		enableButtons(!set);
	}
	
	public JDialog getFrame(){
		return actualFrame;
	}
	
	public void dispose(){
		actualFrame.dispose();
	}
	
	public void runSaveDB(){
		db.runSaveDB();
	}
	
	public static void setParent(Frame parent1){
		parent = parent1;
	}
	
	public void showDBProperties(){
		try {
			db.resetToFileData();
		} catch (Exception e) {
			log.severe("Problem reading from db file!");
		}
		db.requestFocus();
		db.setVisible(true);
	}
	
	public Run saveRunData(){
		run.setDescription(getDescription());
		run.setSetupName(getSetupName());
		run.setVersion(getVersion());
		run.setBuild(getBuild());
		run.setStation(getStation());
		cancel = false;
		return run;
	}
	
	public void showForm(boolean show){
		final boolean sh = show;
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				actualFrame.setVisible(sh);
			}
		});
		
	}

	public DefineDbPropertiesDialog getDb() {
		return db;
	}
}
