/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.suteditor.planner;

public enum FilterType {
	ALL, CLASS, NAME, VALUE;
}
