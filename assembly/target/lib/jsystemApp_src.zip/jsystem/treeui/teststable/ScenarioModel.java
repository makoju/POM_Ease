/*
 * Created on 15/10/2006
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.treeui.teststable;

import javax.swing.tree.DefaultTreeModel;

public class ScenarioModel extends DefaultTreeModel {

	private static final long serialVersionUID = 3995271562461451365L;

	public ScenarioModel() {
		super(new ScenarioTreeNode(null));
	}
}
