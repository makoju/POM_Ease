/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.undoredo;

public abstract class BaseUserAction implements UserAction {
	
}
