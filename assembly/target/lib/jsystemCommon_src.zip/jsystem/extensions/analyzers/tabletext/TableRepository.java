/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.extensions.analyzers.tabletext;

public interface TableRepository {
	public TTable getTable() throws Exception;
}
