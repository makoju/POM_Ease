/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.extensions.scenarionamehook;

public interface ScenarioNameHook {
	
	public String getProjectName();
	
	public String getScenarioId();
	
}
