/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsystem.utils.FileUtils;

/**
 * DB properties holds the information of the reports database,
 * The information is read from db.properties file in the current directory.
 * It's read every time the publisher is been read.
 * 
 * @author guy.arieli
 */
public class DBProperties {

	public static final int DB_TYPE_ORACLE = 0;

	public static final int DB_TYPE_MS_SQL = 1;

	public static final int DB_TYPE_MYSQL = 2;
	
	final public static String DESCRIPTION = "Description";

	final public static String VERSION = "Version";

	final public static String BUILD = "Build";

	final public static String INIT_REPORT = "init_report";
	
	final public static String ACTION_TYPE = "action_type";
	
	final public static String SCENARIO_NAME = "scenario_name";
	
	final public static String STATION = "Station";
	
	final public static String SETUP = "Setup";

	public static final String DB_PROPERTIES_FILE = "db.properties";
	
	private static Logger log = Logger.getLogger(DBProperties.class.getName());
	
	Properties dbprop = null;

	private DBProperties() throws Exception{
		dbprop = getDbProperties();
		getDbType();
	}

	public int getDbType() {
		int dbType = DB_TYPE_MYSQL;
		return dbType;
	}

	/**
	 * return a new DBProperties class instance.
	 * not singletone.
	 * @return
	 * @throws Exception
	 */
	public static DBProperties getInstance() throws Exception {
		return new DBProperties();
	}

	public String getProperty(String key) {
		return dbprop.getProperty(key);
	}

	public Connection getConnection() throws Exception {
		return getConnection(dbprop.getProperty("db.driver"),dbprop.getProperty("db.host"),dbprop.getProperty("db.dbname"),dbprop.getProperty("db.type"),dbprop.getProperty("db.user"),dbprop.getProperty("db.password"));
	}
	
	public Connection getConnection(String dbDriver,String dbHost, String dbName, String dbType,String dbUser, String dbPassword) throws Exception {
		Connection conn;
		Class.forName(dbDriver).newInstance();

		String url = null;
		if (DBProperties.getInstance().getDbType() == DBProperties.DB_TYPE_MYSQL){
			url = "jdbc:" + dbType + "://" + dbHost + "/" + dbName;
		}

		if (url == null){
			throw new Exception("Unkown database type");
		}
		conn = DriverManager.getConnection(url, dbUser, dbPassword);
		return conn;
	}
	
	/**
	 * get the properties from the db file, creates a new default values file if doesn't exist
	 * 
	 * @return
	 * @throws IOException
	 */
	public static Properties getDbProperties() throws IOException {
		File dbFile = new File(DB_PROPERTIES_FILE);
		if (!dbFile.exists()){
			// create and put default values
			try {
				dbFile.createNewFile();
				saveRunData("com.mysql.jdbc.Driver", "mysql", "localhost", "jsystem", "root", "root", "8080", "localhost");
			} catch (IOException ioe){
				throw new IOException("Unable to create " + DB_PROPERTIES_FILE, ioe);
			}
			
			
		}
		
		return FileUtils.loadPropertiesFromFile(DB_PROPERTIES_FILE);
	}
	
	
	/**
	 * @return:
	 * 	- True if all data were saved correctly to the db.properties file
	 * 	- False - If not all data were saved correctly to the db.properties file
	 * Description:
	 * Retrieve all the fields values from the dialog, and write down the information into db.properties file
	 */
	public static boolean saveRunData(String dbDriver, String dbType, String dbHost, String dbName, String dbUser, String dbPassword, String applicationServerPort, String applicationServerUrl) {
		boolean dataWasSavedSuccessfully = false;	
		Properties prop = new Properties();
		prop.setProperty("db.driver", dbDriver);
		prop.setProperty("db.type" ,dbType);
		prop.setProperty("db.host",dbHost);
		prop.setProperty("db.dbname" ,dbName);
		prop.setProperty("db.user" ,dbUser);
		prop.setProperty("db.password" ,dbPassword);
		prop.setProperty("browser.port" ,applicationServerPort);
		prop.setProperty("serverIP" ,applicationServerUrl);
		try {
			FileUtils.savePropertiesToFile(prop, DBProperties.DB_PROPERTIES_FILE);
			dataWasSavedSuccessfully = true;
		} catch (Exception e) {
			log.log(Level.SEVERE,"Fail to save " + DBProperties.DB_PROPERTIES_FILE);
		} finally {

		}
		return dataWasSavedSuccessfully;
	}
	
	/**
	 * Description: close a connection (if exists)
	 */
	public static void closeConnectionIfExists(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println("Fail to close the connection to DB");
			}
		}
	}
}
