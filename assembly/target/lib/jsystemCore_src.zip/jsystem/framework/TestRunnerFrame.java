/*
 * Created on 24/09/2006
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework;

import javax.swing.JFrame;

public class TestRunnerFrame {
	public static JFrame guiMainFrame = null;

}
