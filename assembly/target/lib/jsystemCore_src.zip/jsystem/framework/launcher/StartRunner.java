/*
 * Created on 27/04/2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework.launcher;

/**
 * @author guy.arieli
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public interface StartRunner {
	public abstract void startRunner(String[] args);
}