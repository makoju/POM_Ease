/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework.scenario;

public interface NoneParameterProvider extends ParameterProvider {

}
