/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework.scenario;

/**
 * Used to mark data model classes
 * @author guy.arieli
 *
 */
public interface ProviderDataModel {

}
