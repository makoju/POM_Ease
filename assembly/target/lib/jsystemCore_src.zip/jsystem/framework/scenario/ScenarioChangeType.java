/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework.scenario;

public enum ScenarioChangeType {
    NEW, DELETE, MODIFY, CURRENT,SAVE,RESET_DIRTY;
}