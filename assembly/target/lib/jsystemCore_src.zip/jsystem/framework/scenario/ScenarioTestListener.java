/*
 * Created on 15/10/2006
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework.scenario;

public interface ScenarioTestListener {
	public void startScenarioTest();

	public void stopScenarioTest();
}
