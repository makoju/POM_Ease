/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework.scenario;

/**
 * The default data model. Indicate no change in the data model.
 * @author guy.arieli
 *
 */
public interface UseDefaultDataModel extends ProviderDataModel{

}
