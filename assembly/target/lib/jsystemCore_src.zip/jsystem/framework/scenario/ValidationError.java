/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework.scenario;

import java.util.ArrayList;
import java.util.List;

public class ValidationError {
	public enum Originator{
		TEST, RUNNER;
	}
	
	private Originator originator;
	private String title;
	private String message;
	
	public Originator getOriginator() {
		return originator;
	}
	public void setOriginator(Originator originator) {
		this.originator = originator;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public static String collectErrorsDescriptions(ArrayList<ValidationError> errors, boolean full){
		StringBuffer buf = new StringBuffer();
		for(ValidationError error: errors){
			buf.append(error.getTitle()); buf.append("\n");
			if(full){
				buf.append(error.getMessage()); buf.append("\n");
			}
		}
		return buf.toString();
	}
	
	public static void clearValidatorsWithOriginator(List<ValidationError> errors, Originator originator){
		if(errors != null){
			for(int i = 0; i < errors.size(); i++){
				if(originator.equals(errors.get(i).getOriginator())){
					errors.remove(errors.get(i));
					i--;
				}
			}
		}
	}
}
