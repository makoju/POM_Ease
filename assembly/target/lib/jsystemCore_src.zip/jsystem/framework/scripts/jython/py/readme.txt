The *.py files in this directory should be copied to the runner\lib\jython\ 
directory in your jsystem installation by the build script.

~ Gooli