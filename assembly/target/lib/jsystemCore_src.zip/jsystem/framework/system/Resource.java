/*
 * Created on Feb 16, 2006
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework.system;

/**
 * @author guy.arieli & ohad.crystal
 */
public interface Resource {
	public abstract void lockResource();
}
