/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.framework.system;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsystem.framework.IgnoreMethod;
import jsystem.framework.RunProperties;
import jsystem.framework.analyzer.AnalyzerImpl;
import jsystem.framework.report.ListenerstManager;
import jsystem.framework.report.Reporter;
import jsystem.framework.sut.Sut;
import jsystem.framework.sut.SutFactory;
import jsystem.utils.beans.BeanElement;
import jsystem.utils.beans.BeanUtils;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/*
 * import electric.xml.Element; import electric.xml.Text; import
 * electric.xml.Attribute;
 */

/**
 * System Object is a convention to represent the setup/system you are working
 * on with a single object. The steps in the tests will be operations on the
 * setup/system object.
 * 
 * @author Guy Arieli
 */
public abstract class SystemObjectImpl extends AnalyzerImpl implements SystemObject {
	private static Logger log = Logger.getLogger(SystemObjectImpl.class.getName());

	private String tagName = null;

	private String name = null;

	private String path = null;

	private String referencePath = null;

	protected boolean isClosed = false;

	private int lifeTime = SystemObject.PERMANENT_LIFETIME;

	protected SystemObjectManager system = SystemManagerImpl.getInstance();

	protected Sut sut = SutFactory.getInstance().getSutInstance();

	protected Reporter report = ListenerstManager.getInstance();

	/**
	 * Properties service that can be used to save properties and share it with
	 * other tests. Properties that are saved in one test can be read in other
	 * tests as long as they are in the same run.
	 */
	protected RunProperties runProperties = RunProperties.getInstance();

	protected SystemObjectManager systemManager = SystemManagerImpl.getInstance();

	protected Vector<SystemObject> systemObjects = new Vector<SystemObject>();

	protected Properties properties = new Properties();

	SystemObject parent = null;

	private Semaphore lockObject = new Semaphore(1);

	private int checkStatus;

	private int soArrayIndex = -1;

	/**
	 * Set the System Object name.
	 * 
	 * @param name
	 *            The object name.
	 */
	@IgnoreMethod
	public void setTagName(String name) {
		this.tagName = name;
	}

	/**
	 * Get the system object name.
	 * 
	 * @return The system object name.
	 */
	@IgnoreMethod
	public String getName() {
		return name;
	}

	/**
	 * Get the object lifetime. The default lifetime is PERMANENT_LIFETIME.
	 * 
	 * @return the object lifetime.
	 */
	@IgnoreMethod
	public int getLifeTime() {
		return lifeTime;
	}

	/**
	 * Set the object lifetime. Can be one of two: TEST_LIFETIME or
	 * PERMANENT_LIFETIME.
	 * 
	 * @param lifeTime
	 *            The object lifetime.
	 */
	@IgnoreMethod
	public void setLifeTime(int lifeTime) {
		this.lifeTime = lifeTime;
	}

	/**
	 * Get the object XPath in the sut XML file.
	 * 
	 * @return Object XPath.
	 */
	@IgnoreMethod
	public String getXPath() {
		return path;
	}

	/**
	 * Set the object XPath.
	 * 
	 * @param path
	 *            Object XPath.
	 */
	@IgnoreMethod
	public void setXPath(String path) {
		this.path = path;
	}

	/**
	 * see interface doc
	 */
	@IgnoreMethod
	public String getReferenceXPath() {
		return referencePath;
	}

	/**
	 * see interface doc
	 */
	@IgnoreMethod
	public void setReferenceXPath(String path) {
		this.referencePath = path;
	}

	/**
	 * Is the object close.
	 * 
	 * @return Return true if closed else return false.
	 */
	@IgnoreMethod
	public boolean isClosed() {
		return isClosed;
	}

	/**
	 * Set the object isClosed status.
	 * 
	 * @param isClosed
	 *            the isClosed status.
	 */
	@IgnoreMethod
	public void setClose(boolean isClosed) {
		this.isClosed = isClosed;
	}

	/**
	 * Init all the class field from the xml
	 * 
	 * @throws Exception
	 */
	@IgnoreMethod
	protected void initFields() throws Exception {
		Class<?> c = this.getClass();
		Field[] fields = c.getFields();
		for (int i = 0; i < fields.length; i++) {
			String fieldName = fields[i].getName();
			if (SystemObject.class.isAssignableFrom(fields[i].getType())) {
				SystemObject sObject = (SystemObject) fields[i].get(this);
				if (sObject == null || sObject.isClosed()) {
					sObject = getChildSystemObject(fieldName, -1);
					try {
						fields[i].set(this, sObject);
					} catch (Exception t) {
						log.warning("Fail to init field: " + fieldName);
					}
				}
				systemObjects.remove(sObject);
				systemObjects.addElement(sObject);
			} else if (fields[i].getType().isArray() && SystemObject.class.isAssignableFrom(fields[i].getType().getComponentType())) {

				int lastIndex = getObjectLastIndex(getXPath(), fieldName);
				if (lastIndex < 0) {
					continue;
				}
				SystemObject[] array = (SystemObject[]) fields[i].get(this);
				if (array == null) {
					Object o = Array.newInstance(fields[i].getType().getComponentType(), lastIndex + 1);
					for (int j = 0; j <= lastIndex; j++) {
						SystemObject so = getChildSystemObject(fieldName, j);
						Array.set(o, j, so);
						systemObjects.remove(so);
						systemObjects.addElement(so);
						if (so != null) {
							so.setSOArrayIndex(j);
						}
					}
					fields[i].set(this, o);
				} else {
					for (int j = 0; j < array.length; j++) {
						if (array[j] == null || array[j].isClosed()) {
							array[j] = getChildSystemObject(fieldName, j);
							systemObjects.remove(array[j]);
							systemObjects.addElement(array[j]);
						}
					}
				}
			}
		}
	}

	private SystemObject getChildSystemObject(String fieldName, int index) throws Exception {
		SystemObject res = ((SystemManagerImpl) system).getSystemObject(getXPath(), fieldName, index, this, true, getReferenceXPath(), sut);
		return res;
	}

	@IgnoreMethod
	protected void setSetters() {
		// ***
		Class<?> c = this.getClass();
		HashMap<String, BeanElement> beans = BeanUtils.getBeanMap(c, false, true, BeanUtils.getBasicTypes());

		try {
			Enumeration<?> enum1 = properties.keys();
			while (enum1.hasMoreElements()) {
				String name = (String) enum1.nextElement();
				BeanElement bean = beans.get(name);
				if (bean == null) {
					continue;
				}
				try {
					BeanUtils.invoke(this, bean.getSetMethod(), properties.getProperty(name), bean.getType());
				} catch (Throwable tt) {
					log.log(Level.INFO, "Fail to set setters: " + bean.getSetMethod().getName(), tt);
				}

			}
		} catch (Throwable t) {
			log.log(Level.INFO, "Fail to set setters", t);
		}
		// ---
	}

	/**
	 * Please note: If a system object (SystemObject A) is created by reference
	 * to another system object (SystemObject B) when this method is called (at
	 * the initiation of the SystemObject), the getXPath method return the path
	 * to B and the get getReferenceXPath returns the path to A At the end of
	 * the initiation process the paths are replaced by the SystemManagerImpl
	 * 
	 */
	@IgnoreMethod
	protected void initProperties() {
		initPropertiesFromPath(getXPath());
		if (getReferenceXPath() != null && !"".equals(getReferenceXPath().trim())) {
			initPropertiesFromPath(getReferenceXPath());
		}

	}

	private void initPropertiesFromPath(String path) {
		try {
			List<?> list = sut.getAllValues(path + "/*");
			for (int i = 0; i < list.size(); i++) {
				Element element = (Element) list.get(i);
				String name = element.getNodeName();
				String text = null;
				NodeList nlist = element.getChildNodes();
				for (int j = 0; j < nlist.getLength(); j++) {
					Node n = nlist.item(j);
					if (n.getNodeType() == Node.TEXT_NODE) {
						text = n.getNodeValue();
						break;
					}
				}
				if (text != null) {
					properties.setProperty(name, text);
				}
			}
		} catch (Exception e) {
			log.log(Level.INFO, "Fail to init properties", e);
		}

	}

	@IgnoreMethod
	public void init() throws Exception {
		initProperties();
		initFields();
		setSetters();
	}

	/**
	 * Close all children of the system object.
	 */
	@IgnoreMethod
	protected void closeFields() {
		SystemObjectImpl[] sysObjs = systemObjects.toArray(new SystemObjectImpl[systemObjects.size()]);
		for (int i = 0; i < sysObjs.length; i++) {
			if (sysObjs[i] != null) {
				sysObjs[i].close();
			}
		}
		systemObjects = new Vector<SystemObject>();
	}

	/**
	 * Close the system object.
	 */
	@IgnoreMethod
	public void close() {
		// Close all children
		closeFields();
		// Indicate system object is closed
		setClose(true);
		// Remove system object from parent system object
		SystemObject o = getParent();
		if (o != null) {
			o.getChildren().remove(this);
		}
		if (SystemManagerImpl.getInstance() != null) {
			// Remove system object from system objects manager
			SystemManagerImpl.getInstance().removeSystemObject(this);
		}
	}

	protected String fixPath(String relativePath) {
		return pathConcat(path, relativePath);
	}

	@IgnoreMethod
	private String pathConcat(String path1, String path2) {
		if (path1.endsWith("/")) {
			return path1 + path2;
		} else {
			return path1 + "/" + path2;
		}
	}

	@IgnoreMethod
	private int getObjectLastIndex(String path, String name) throws Exception {
		String xPath = path + "/" + name;
		List<?> list = sut.getAllValues(xPath);
		if (list == null || list.size() == 0) {
			return -1;
		}

		// Add all index attributes into indexes array list
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		for (int i = 0; i < list.size(); i++) {
			Element element = (Element) list.get(i);
			String indexAttrib = element.getAttribute("index");
			if (indexAttrib == null) {
				throw new Exception("No index attribute was found");
			}
			try {
				indexes.add(Integer.parseInt(indexAttrib));
			} catch (NumberFormatException e) {
				throw new Exception("index attribute is not integer: " + indexAttrib, e);
			}
		}
		// Sort indexes
		Collections.sort(indexes);
		// Return the last index from the sorted indexes array list
		return indexes.get(indexes.size() - 1);
	}

	/**
	 * @return Returns the tagName.
	 */
	@IgnoreMethod
	public String getTagName() {
		return tagName;
	}

	/**
	 * @param name
	 *            The name to set.
	 */
	@IgnoreMethod
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * return the parent system object null in case of root.
	 */
	@IgnoreMethod
	public SystemObject getParent() {
		return parent;
	}

	@IgnoreMethod
	public void setParent(SystemObject parent) {
		this.parent = parent;
	}

	@IgnoreMethod
	public Properties getProperties() {
		return properties;
	}

	@IgnoreMethod
	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	@IgnoreMethod
	public void setOpenCloseStatusAll(boolean status) {
		setClose(status);
		if (systemObjects != null) {
			for (int i = 0; i < systemObjects.size(); i++) {
				SystemObject o = systemObjects.elementAt(i);
				if (o != null) {
					o.setOpenCloseStatusAll(status);
				}
			}
		}
	}

	@IgnoreMethod
	public Vector<SystemObject> getChildren() {
		return systemObjects;
	}

	@IgnoreMethod
	public String getProperty(String key) {
		return properties.getProperty(key);
	}

	@IgnoreMethod
	public void lock() throws Exception {
		system.lockObject(this);
	}

	@IgnoreMethod
	public void release() {
		system.releaseObject(this);
	}

	public Semaphore getLockObject() {
		return lockObject;
	}

	@IgnoreMethod
	public void check() throws Exception {
		report.report(name + ": Perform Check");
		setCheckStatus(SystemObject.CHECK_NOT_IMPL);
	}

	@IgnoreMethod
	public int getCheckStatus() {
		return checkStatus;
	}

	@IgnoreMethod
	public void setCheckStatus(int checkStatus) {
		this.checkStatus = checkStatus;
	}

	@IgnoreMethod
	public void pause() {
		// defualt empty implementation
	}

	@IgnoreMethod
	public void resume() {
		// defualt empty implementation
	}

	@IgnoreMethod
	public int getSOArrayIndex() {
		return soArrayIndex;
	}

	@IgnoreMethod
	public void setSOArrayIndex(int index) {
		this.soArrayIndex = index;
	}

	private long exitTimeout = 1000;

	/**
	 * @return time to wait for the system object to close
	 */
	public long getExitTimeout() {
		return exitTimeout;
	}

	/**
	 * @param exitTimeout
	 *            time to wait for the system object to close
	 */
	public void setExitTimeout(long exitTimeout) {
		this.exitTimeout = exitTimeout;
	}

}
