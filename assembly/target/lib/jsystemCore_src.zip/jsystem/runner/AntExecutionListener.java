/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner;

import java.io.File;

import jsystem.framework.FrameworkOptions;
import jsystem.framework.JSystemProperties;
import jsystem.framework.RunProperties;
import jsystem.framework.scenario.RunningProperties;
import jsystem.framework.scenario.Scenario;
import jsystem.framework.scenario.ScenariosManager;
import jsystem.utils.StringUtils;

import org.apache.tools.ant.BuildEvent;
import org.apache.tools.ant.BuildListener;

/**
 * Listener that should be added to ant execution commandline when executing scenario using
 * ant interpreter directly.
 * The listener perform some initialization operations which are required for
 * proper execution of the scenario.
 * 
 * @author gderazon
 */
public class AntExecutionListener implements BuildListener {

	@Override
	public void buildStarted(BuildEvent arg0) {
		//Updating jsystem.properties file
		String testsClassesDir = System.getProperty(RunningProperties.SCENARIO_BASE);
		if (!StringUtils.isEmpty(testsClassesDir)){
			File sourceFolder = new File(testsClassesDir);
			sourceFolder = new File(sourceFolder.getParent(),"tests");
			JSystemProperties.getInstance().setPreference(FrameworkOptions.TESTS_CLASS_FOLDER, testsClassesDir);
			JSystemProperties.getInstance().setPreference(FrameworkOptions.TESTS_SOURCE_FOLDER, sourceFolder.getAbsolutePath());			
		}		
		String sutFile = System.getProperty(FrameworkOptions.USED_SUT_FILE.getString());
		if (!StringUtils.isEmpty(sutFile)){
			JSystemProperties.getInstance().setPreference(FrameworkOptions.USED_SUT_FILE, sutFile);
		}
		//it is important to remove the property from system map otherwise,
		//change sut event won' work.
		System.getProperties().remove(FrameworkOptions.USED_SUT_FILE.getString());
		//resetting RunProperties
		RunProperties.getInstance().resetRunProperties();
		
		//loading scenario.
		String scenarioName = System.getProperty(RunningProperties.CURRENT_SCENARIO_NAME);
		try {
			Scenario s = ScenariosManager.getInstance().getScenario(scenarioName);
			ScenariosManager.getInstance().setCurrentScenario(s);
		}catch (Exception e){
			throw new RuntimeException("Failed loading scenario " + scenarioName,e);
		}
	}

	@Override
	public void buildFinished(BuildEvent arg0) {
		//give the reporters thread some time to write the report.
		try {
			Thread.sleep(1000);
		}catch (Exception e){
		}
	}

	@Override
	public void messageLogged(BuildEvent arg0) {
	}

	@Override
	public void targetFinished(BuildEvent arg0) {
	}

	@Override
	public void targetStarted(BuildEvent arg0) {
	}

	@Override
	public void taskFinished(BuildEvent arg0) {
	}

	@Override
	public void taskStarted(BuildEvent arg0) {
	}
}
