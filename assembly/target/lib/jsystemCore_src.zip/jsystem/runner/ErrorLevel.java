/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner;

import java.io.Serializable;

public enum ErrorLevel implements Serializable {
	Error, Warning, Info;
}
