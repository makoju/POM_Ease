/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.runner;

public enum SOCheckStatus{
	INITTING,
	INIT_SUCESS,
	INIT_FAIL,
	CHECK_NOT_IMPLEMENTED,
	CHECK_SUCESS,
	CHECK_FAIL
}
