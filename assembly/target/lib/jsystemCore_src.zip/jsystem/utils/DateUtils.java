/*
 * Created on Dec 5, 2005
 *
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.utils;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author guy.arieli
 * 
 */
public class DateUtils {
	public static String getDate() {
		return Calendar.getInstance(TimeZone.getDefault()).getTime().toString();
	}

	public static String getDate(long date) {
		Calendar c = Calendar.getInstance(TimeZone.getDefault());
		c.setTimeInMillis(date);
		return c.getTime().toString();
	}

	public static String getDate(long date, DateFormat format) {
		Calendar c = Calendar.getInstance(TimeZone.getDefault());
		c.setTimeInMillis(date);
		Date d = c.getTime();
		return format.format(d);

	}
}
