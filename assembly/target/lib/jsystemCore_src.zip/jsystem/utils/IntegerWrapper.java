/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package jsystem.utils;

/**
 * Struct that holds value.
 * 
 * @author uri.koaz
 */
public class IntegerWrapper {

	public int value;
	public boolean allowTowrite = true;
	
}
