package jsystem.sysobj.scripting.python;

import jsystem.extensions.analyzers.text.TextNotFound;
import jsystem.framework.report.Reporter;
import jsystem.framework.system.SystemObjectImpl;


public class PyShell extends SystemObjectImpl {

	private TelnetConnection telnet;
	private String host;
	private int port;
	private String user;
	private String password;
	
	public void init() throws Exception {
		super.init();	
		
		telnet = new TelnetConnection(host, port);
		telnet.Login(user, password, 4000);
		telnet.WriteLine("cd C:\\scapy-2.1.0");
		telnet.WriteLine("python");		
		String result = telnet.Read(">>>");
		telnet.WriteLine("from scapy.all import *");
		result = telnet.Read(">>>");
		telnet.WriteLine("from scapy.layers.l2 import Dot1Q");
		result = telnet.Read(">>>");
		telnet.WriteLine("from scapy.layers.inet import IP");
		result = telnet.Read(">>>");
		telnet.WriteLine("from scapy.layers.ppp import *");
		result = telnet.Read(">>>");
		telnet.WriteLine("from scapy.layers.l2 import *");
		result = telnet.Read(">>>");
		setTestAgainstObject(result);
	}
	
	public void handleCliCommand(String title, String command) throws Exception {
		report.startLevel(title, Reporter.CurrentPlace);
		telnet.WriteLine(command);
		String result = telnet.Read(">>>");
		setTestAgainstObject(result);
		analyze(new TextNotFound("error"));
		report.stopLevel();
	}

	public void handleCliCommand(String title, String[] commands) throws Exception {
		report.startLevel(title, Reporter.CurrentPlace);
		for (String command : commands) {
			telnet.WriteLine(command);
			String result = (telnet.Read(">>>"));
			setTestAgainstObject(result);
			analyze(new TextNotFound("error"));
		}
		report.stopLevel();
	}
	
	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
	
	
}
