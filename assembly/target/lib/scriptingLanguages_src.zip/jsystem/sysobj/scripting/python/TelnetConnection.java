package jsystem.sysobj.scripting.python;

import java.net.Socket;

public class TelnetConnection {
    public final static int WILL = 251;
    public final static int WONT = 252;
    public final static int DO = 253;
    public final static int DONT = 254;
    public final static int IAC = 255;

    public static int SGA = 3;

    Socket tcpSocket;

    int TimeOutMs = 100;

    public TelnetConnection(String Hostname, int Port) throws Exception {
        tcpSocket = new Socket(Hostname, Port);
    }

    public String Login(String Username, String Password, int LoginTimeOutMs) throws Exception {
        int oldTimeOutMs = TimeOutMs;
        TimeOutMs = LoginTimeOutMs;
        String s = Read(":");
        if (!s.trim().endsWith(":"))
            throw new Exception("Failed to connect : no login prompt");
        WriteLine(Username);

        s += Read(":");
        if (!s.trim().endsWith(":"))
            throw new Exception("Failed to connect : no password prompt");
        WriteLine(Password);

        s += Read(">");
        TimeOutMs = oldTimeOutMs;
        return s;
    }

    public void WriteLine(String cmd) throws Exception {
        Write(cmd + "\r\n");
    }

    public void Write(String cmd) throws Exception {
        if (!tcpSocket.isConnected()) return;
        byte[] buf = cmd.replace("\0xFF", "\0xFF\0xFF").getBytes();
        tcpSocket.getOutputStream().write(buf, 0, buf.length);
    }

    public String Read() throws Exception {
        if (!tcpSocket.isConnected()) return null;
        StringBuilder sb = new StringBuilder();
        do
        {
            ParseTelnet(sb);
            Thread.sleep(TimeOutMs);
        } while (tcpSocket.getInputStream().available() > 0);
        return sb.toString();
    }
    
    public String Read(String end) throws Exception {
        if (!tcpSocket.isConnected()) return null;
        StringBuilder sb = new StringBuilder();
        do
        {
            ParseTelnet(sb);
            if (sb.toString().trim().endsWith(end))
            {
                return sb.toString();
            }
            Thread.sleep(100);
        } while (true);
        //return sb.ToString();
    }

    public boolean IsConnected() {
        return tcpSocket.isConnected();
    }

    void ParseTelnet(StringBuilder sb) throws Exception {
        while (tcpSocket.getInputStream().available() > 0) {
            int input = tcpSocket.getInputStream().read();
            switch (input) {
                case -1:
                    break;
                case IAC:
                    // interpret as command
                    int inputverb = tcpSocket.getInputStream().read();
                    if (inputverb == -1) break;
                    switch (inputverb) {
                        case IAC:
                            //literal IAC = 255 escaped, so append char 255 to string
                            sb.append((char)inputverb);
                            System.out.print((char)inputverb);
                            break;
                        case DO:
                        case DONT:
                        case WILL:
                        case WONT:
                            // reply to all commands with "WONT", unless it is SGA (suppres go ahead)
                            int inputoption = tcpSocket.getInputStream().read();
                            if (inputoption == -1) break;
                            tcpSocket.getOutputStream().write(IAC);
                            if (inputoption == SGA)
                                tcpSocket.getOutputStream().write(inputverb == DO ? WILL : DO);
                            else
                                tcpSocket.getOutputStream().write(inputverb == DO ? WONT : DONT);
                            tcpSocket.getOutputStream().write(inputoption);
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    System.out.print((char)input);
                    sb.append((char)input);
                    break;
            }
        }
    }
}
