/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsystem.framework.system.SystemObjectImpl;
import net.percederberg.mibble.Mib;
import net.percederberg.mibble.MibLoader;
import net.percederberg.mibble.MibValue;
import net.percederberg.mibble.MibValueSymbol;
import net.percederberg.mibble.snmp.SnmpObjectType;
import systemobject.snmp.mibSymbolInfo.MibSymbolAccess;
import systemobject.snmp.mibSymbolInfo.MibSymbolInfo;
import systemobject.snmp.mibSymbolInfo.MibSymbolInfoImpl;
import systemobject.snmp.mibSymbolInfo.MibSymbolStatus;
import systemobject.snmp.mibSymbolInfo.MibSymbolTagType;

/**
 * This Class is a default implementation of the "BasicMibCompiler" interface.
 * It uses the Mibble open source project to implement a simple MIB compiler
 * 
 * @author Hovav
 * 
 */
public class DefaultMibCompilerImpl extends SystemObjectImpl implements BasicMibCompiler {

	private static Logger log = Logger.getLogger(DefaultMibCompilerImpl.class.getName());

	protected MibLoader loader = null;

	public DefaultMibCompilerImpl() {
		this(false);
	}

	public DefaultMibCompilerImpl(boolean init) {
		if (init) {
			try {
				init();
			} catch (Exception e) {
				log.log(Level.WARNING, "Fail to init Default MIB Compiler");
			}
		}
	}

	@Override
	public void init() throws Exception {
		init(true);
	}

	public void init(boolean initSuper) throws Exception {
		if (initSuper) {
			super.init();
		}
		loader = new MibLoader();
	}

	@Override
	public void initMaps(Object mib, HashMap<String, MibSymbolInfo> mibByName, HashMap<String, MibSymbolInfo> mibByOid) {
		if (mib instanceof File) {
			String line = null;
			BufferedReader in = null;
			try {
				in = new BufferedReader(new FileReader((File) mib));
				while ((line = in.readLine()) != null) {
					MibSymbolInfoImpl info = new MibSymbolInfoImpl();
					info.initFromString(line);
					mibByName.put(info.getMibName(), info);
					mibByOid.put(info.getOid(), info);
				}
			} catch (Exception e) {
				log.log(Level.WARNING, "Exception While Reading Snmp Mib DB: " + e.getMessage());
			} finally {
				if (in != null) {
					try {
						in.close();
					} catch (Exception e) {
						log.log(Level.WARNING, "Fail to close reader of Snmp Mib DB");
					}
				}
			}
		} else {
			Object[] arr = ((Mib) mib).getAllSymbols().toArray();
			MibValueSymbol symbol = null;
			MibValue value = null;

			MibSymbolInfoImpl info = null;
			for (int i = 0; i < arr.length; i++) {
				if (arr[i] != null && arr[i] instanceof MibValueSymbol) {

					symbol = (MibValueSymbol) arr[i];
					if (symbol != null) {
						value = symbol.getValue();

						// set MIB name, MIB OID and MIB description
						info = new MibSymbolInfoImpl(value.getName(), value.toString(), symbol.getType().toString());

						// set MIB tag type
						info.setTagType(MibSymbolTagType.get(symbol.getType().getTag()));

						// set MIB access and status
						if (symbol.getType() instanceof SnmpObjectType) {
							info.setAccess(MibSymbolAccess.get(((SnmpObjectType) symbol.getType()).getAccess()));
							info.setStatus(MibSymbolStatus.get(((SnmpObjectType) symbol.getType()).getStatus()));
						} else {
							info.setAccess(MibSymbolAccess.get(null));
							info.setStatus(MibSymbolStatus.get(null));
						}
						mibByName.put(info.getMibName(), info);
						mibByOid.put(info.getOid(), info);
					}
				}
			}
		}
	}

	@Override
	public void addDir(File f) {
		loader.addDir(f);
	}

	@Override
	public Object[] getAllMibs() {
		return loader.getAllMibs();
	}

	@Override
	public void load(File f) throws Exception {
		loader.load(f);
	}

}
