/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp;

import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import jsystem.extensions.analyzers.text.CheckTextCounter;
import jsystem.extensions.analyzers.text.FindText;
import jsystem.framework.analyzer.AnalyzerException;
import jsystem.framework.system.SystemObjectImpl;
import junit.framework.AssertionFailedError;
import junit.framework.Test;
import junit.framework.TestListener;

import org.opennms.protocols.snmp.SnmpObjectId;
import org.opennms.protocols.snmp.SnmpParameters;
import org.opennms.protocols.snmp.SnmpPeer;
import org.opennms.protocols.snmp.SnmpSMI;
import org.opennms.protocols.snmp.SnmpSession;
import org.opennms.protocols.snmp.SnmpVarBind;

/**
 * Used as an SNMP MIB browser with set/get/walk...
 * 
 * @author guy
 */
public class Snmp extends SystemObjectImpl implements TestListener {

	/**
	 * This ENUM represent the SNMP community (private/public or undefined)
	 * 
	 * @author Hovav
	 * 
	 */
	public enum Community {
		UNDEFINED("undefined"), PUBLIC("public"), PRIVATE("private");
		Community(String community) {
			this.community = community;
		}

		public static Community get(String community) {
			Community[] arr = values();
			for (int i = 0; i < arr.length; i++) {
				if (arr[i].community().equals(community)) {
					return arr[i];
				}
			}
			return Community.UNDEFINED;
		}

		private String community;

		public String community() {
			return community;
		}
	}

	/**
	 * This ENUM represent the SNMP version (SNMPv1/2 or undefined)
	 * 
	 * @author Hovav
	 * 
	 */
	public enum Version {
		UNDEFINED(Integer.MIN_VALUE), SNMPV1(SnmpSMI.SNMPV1), SNMPV2(SnmpSMI.SNMPV2);
		Version(int version) {
			this.version = version;
		}

		public static Version get(int version) {
			Version[] arr = values();
			for (int i = 0; i < arr.length; i++) {
				if (arr[i].version() == version) {
					return arr[i];
				}
			}
			return Version.UNDEFINED;
		}

		private int version;

		public int version() {
			return version;
		}
	}

	protected String lastOidUsed = null;

	protected String lastMibUsedActualName = null;

	protected String lastValue = null;

	protected boolean lastActionResult = false;

	public SnmpTrap trap;

	public MibReader reader;

	protected BasicMibCompiler mibCompiler = null;

	/**
	 * for each action taken (set/get/getNext/walk) the vector contains the PDU
	 * packets (SnmpVarBind) returned by the device in the response messages
	 */
	Vector<SnmpVarBind> pduVector = null;

	private static Logger log = Logger.getLogger(Snmp.class.getName());

	/**
	 * The version of the SNMP protocol used to communicate
	 */
	private Version version = Version.SNMPV2;

	/**
	 * if true - will create file and add link in the report for each SNMP get
	 * or set action if false - will add a comment in the report only unless the
	 * action failed
	 */
	private boolean addLinkToReport = true;

	/**
	 * The community used to "authenticate" the read request.
	 */
	private String readCommunity = Community.PUBLIC.community();

	/**
	 * The community used to "authenticate" the write request.
	 */
	private String writeCommunity = Community.PRIVATE.community();

	/**
	 * The number of retries to use.
	 */
	private int retries = 5;// SnmpPeer.defaultRetries;

	/**
	 * The time period to wait before considering the last transmission a
	 * failure. This should be in milliseconds.
	 */
	private int timeout = 10000; // SnmpPeer.defaultTimeout;

	/**
	 * The port where request are sent & received from.
	 */
	private int port = SnmpPeer.defaultRemotePort;

	/**
	 * The remote agent to communicate with.
	 */
	private String host = null;

	private SnmpSession session = null;

	public String mibsDir = null;

	/**
	 * if set to false will not start listening to traps on Initialization
	 */
	protected boolean launchOnInit = true;

	public Snmp() {
		this(null, null, false);
	}

	public Snmp(String host, String mibsDir, boolean init) {
		this.lastOidUsed = null;
		this.lastMibUsedActualName = null;
		this.lastValue = null;
		this.lastActionResult = false;
		this.trap = null;
		this.reader = null;
		this.mibCompiler = null;
		this.pduVector = null;
		this.version = Version.SNMPV2;
		this.addLinkToReport = true;
		this.readCommunity = Community.PUBLIC.community();
		this.writeCommunity = Community.PRIVATE.community();
		this.retries = 5;
		this.timeout = 10000;
		this.port = SnmpPeer.defaultRemotePort;
		this.host = host;
		this.session = null;
		this.mibsDir = mibsDir;
		log.fine("Create Snmp object");

		if (init) {
			try {
				init();
			} catch (Exception e) {
				log.warning("Init Snmp object: Exception On init: \"" + e.getMessage() + "\"");
			}
		}
	}

	/**
	 * CCTOR, copy the references to all fields from the given Snmp object to
	 * the current one. NOTE that the fields are being referenced and NOT re -
	 * created
	 * 
	 * @param other
	 *            Snmp, another Snmp object
	 */
	public Snmp(Snmp other) {
		this.lastOidUsed = other.lastOidUsed;
		this.lastMibUsedActualName = other.lastMibUsedActualName;
		this.lastValue = other.lastValue;
		this.lastActionResult = other.lastActionResult;
		this.trap = other.trap;
		this.reader = other.reader;
		this.mibCompiler = other.mibCompiler;
		this.pduVector = other.pduVector;
		this.version = other.version;
		this.addLinkToReport = other.addLinkToReport;
		this.readCommunity = other.readCommunity;
		this.writeCommunity = other.writeCommunity;
		this.retries = other.retries;
		this.timeout = other.timeout;
		this.port = other.port;
		this.host = other.host;
		this.session = other.session;
		this.mibsDir = other.mibsDir;
	}

	public String getMibsDir() {
		return mibsDir;
	}

	public void setMibsDir(String mibsDir) {
		this.mibsDir = mibsDir;
	}

	@Override
	public void init() throws Exception {
		super.init();
		if (launchOnInit) {
			launch();
		}
	}

	/**
	 * Start SNMP trap and load MIB values
	 * 
	 * @throws Exception
	 */
	public void launch() throws Exception {
		if (mibsDir != null) {
			loadMibsToMap();
		}
		initTrapper();
	}

	/**
	 * init the trap object if it is "null".<br>
	 * automatically called in the "launch" method and might be called again by
	 * the user if the "trap" member is "null" which means that the trap init
	 * failed, probably because other trap application already listening on port
	 * 162, it enables the user to "kill" the other application and take
	 * ownership for listening on port 162)
	 */
	public void initTrapper() {
		if (trap == null) {
			try {
				trap = SnmpTrap.getInstance();
				trap.setReader(reader);
			} catch (Exception e) {
				log.log(Level.WARNING, "Fail to init trap listener (close mib browser)\n" + "Exception Message = { " + e.getMessage()
						+ " }");
			}
		}
	}

	/**
	 * Set the SNMP version according to SnmpSMI Class.
	 * 
	 * @param version
	 *            Snmp version according to SnmpSMI Class.
	 * @throws Exception
	 * @deprecated use {@link #setVersion(systemobject.snmp.Snmp.Version)}
	 */
	public void setVersion(int version) throws Exception {
		setVersion(Version.get(version));
	}

	/**
	 * Set the SNMP version.
	 * 
	 * @param version
	 *            Snmp version.
	 * @throws Exception
	 */
	public void setVersion(Version version) throws Exception {
		setVersion(version, false);
	}

	/**
	 * Set the SNMP version.
	 * 
	 * @param version
	 *            Snmp version.
	 * @throws Exception
	 */
	public void setVersion(Version version, boolean initSession) throws Exception {
		this.version = version;
		log.fine("Snmp version was set to: " + version);
		if (initSession) {
			initSession();
		}
	}

	/**
	 * Get the used SNMP version according to SnmpSMI Class.
	 * 
	 * @return SNMP version according to SnmpSMI Class.
	 * @deprecated use {@link #getSnmpVersion()}
	 */
	public int getVersion() {
		return version.version();
	}

	/**
	 * Get the used SNMP version.
	 * 
	 * @return SNMP version.
	 * 
	 */
	public Version getSnmpVersion() {
		return version;
	}

	/**
	 * Set the used community for both read and write.
	 * 
	 * @param community
	 *            Community string according to SnmpSMI Class.
	 * @throws Exception
	 * 
	 * @deprecated use
	 *             {@link #setReadCommunity(systemobject.snmp.Snmp.Community)}
	 *             and
	 *             {@link #setWriteCommunity(systemobject.snmp.Snmp.Community)}
	 */
	public void setCommunity(String community) throws Exception {
		setReadCommunity(Community.get(community));
		setWriteCommunity(Community.get(community));
	}

	/**
	 * Set the used community for read.
	 * 
	 * @param community
	 *            Community Object From The Community ENUM.
	 * @throws Exception
	 */
	public void setReadCommunity(Community community) throws Exception {
		setReadCommunity(community.community());
	}

	/**
	 * Set the used community for read.
	 * 
	 * @param community
	 *            Community String.
	 * @throws Exception
	 */
	public void setReadCommunity(String community) throws Exception {
		setReadCommunity(community, false);
	}

	/**
	 * Set the used community for read.
	 * 
	 * @param community
	 *            Community Object From The Community ENUM.
	 * @throws Exception
	 */
	public void setReadCommunity(Community community, boolean initSession) throws Exception {
		setReadCommunity(community.community(), initSession);
	}

	/**
	 * Set the used community for read.
	 * 
	 * @param community
	 *            Community String.
	 * @throws Exception
	 */
	public void setReadCommunity(String community, boolean initSession) throws Exception {
		this.readCommunity = community;
		log.fine("Snmp read community was set to: " + readCommunity);
		if (initSession) {
			initSession();
		}
	}

	/**
	 * Set the used community for write.
	 * 
	 * @param community
	 *            Community Object From The Community ENUM.
	 * @throws Exception
	 */
	public void setWriteCommunity(Community community) throws Exception {
		setWriteCommunity(community.community());
	}

	/**
	 * Set the used community for write.
	 * 
	 * @param community
	 *            Community String.
	 * @throws Exception
	 */
	public void setWriteCommunity(String community) throws Exception {
		setWriteCommunity(community, false);
	}

	/**
	 * Set the used community for write.
	 * 
	 * @param community
	 *            Community Object From The Community ENUM.
	 * @throws Exception
	 */
	public void setWriteCommunity(Community community, boolean initSession) throws Exception {
		setWriteCommunity(community.community(), initSession);
	}

	/**
	 * Set the used community for write.
	 * 
	 * @param community
	 *            Community String.
	 * @throws Exception
	 */
	public void setWriteCommunity(String community, boolean initSession) throws Exception {
		this.writeCommunity = community;
		log.fine("Snmp write community was set to: " + writeCommunity);
		if (initSession) {
			initSession();
		}
	}

	/**
	 * Get the used read community.
	 * 
	 * @return Community string.
	 */
	public String getReadCommunity() {
		return readCommunity;
	}

	/**
	 * Get the used write community.
	 * 
	 * @return Community string.
	 */
	public String getWriteCommunity() {
		return writeCommunity;
	}

	/**
	 * Set the number of retries.
	 * 
	 * @param retries
	 *            Number of retries.
	 * @throws Exception
	 */
	public void setRetries(int retries) throws Exception {
		setRetries(retries, false);
	}

	/**
	 * Set the number of retries.
	 * 
	 * @param retries
	 *            Number of retries.
	 * @throws Exception
	 */
	public void setRetries(int retries, boolean initSession) throws Exception {
		this.retries = retries;
		log.fine("Snmp retries was set to: " + retries);
		if (initSession) {
			initSession();
		}
	}

	/**
	 * Get the number of retries.
	 * 
	 * @return Number of retries.
	 */
	public int getRetries() {
		return retries;
	}

	/**
	 * Set the transmit timeout
	 * 
	 * @param timeout
	 *            Timeout in milliseconds.
	 * @throws Exception
	 */
	public void setTimeout(int timeout) throws Exception {
		setTimeout(timeout, false);
	}

	/**
	 * Set the transmit timeout
	 * 
	 * @param timeout
	 *            Timeout in milliseconds.
	 * @throws Exception
	 */
	public void setTimeout(int timeout, boolean initSession) throws Exception {
		this.timeout = timeout;
		log.fine("Snmp timeout was set to: " + timeout);
		if (initSession) {
			initSession();
		}
	}

	/**
	 * Get the used timeout.
	 * 
	 * @return Timeout in milliseconds.
	 */
	public int getTimeout() {
		return timeout;
	}

	/**
	 * Set the SNMP port.
	 * 
	 * @param port
	 *            SNMP port.
	 * @throws Exception
	 */
	public void setPort(int port) throws Exception {
		setPort(port, false);
	}

	/**
	 * Set the SNMP port.
	 * 
	 * @param port
	 *            SNMP port.
	 * @throws Exception
	 */
	public void setPort(int port, boolean initSession) throws Exception {
		this.port = port;
		log.fine("Snmp port was set to: " + port);
		if (initSession) {
			initSession();
		}
	}

	/**
	 * Get the SNMP port used.
	 * 
	 * @return SNMP port.
	 */
	public int getPort() {
		return port;
	}

	/**
	 * Set the host (IP address).
	 * 
	 * @param host
	 *            Host name.
	 */
	public void setHost(String host) {
		this.host = host;
		log.fine("Snmp host was set to: " + host);
	}

	/**
	 * Set the host (IP address).
	 * 
	 * @param host
	 *            Host name.
	 * @throws Exception
	 */
	public void setHost(String host, boolean initSession) throws Exception {
		this.host = host;
		log.fine("Snmp host was set to: " + host);
		if (initSession) {
			initSession();
		}
	}

	/**
	 * Get the host used.
	 * 
	 * @return Host name.
	 */
	public String getHost() {
		return host;
	}

	/**
	 * Perform a SNMP walk.
	 * 
	 * @param startFrom
	 *            Start from MIB like ".1.3".
	 * @param silent
	 *            boolean: add or don't add report for this action.
	 * 
	 * @exception Exception
	 */
	public void walk(String startFrom, boolean silent) throws Exception {
		if (session == null) {
			initSession();
		}
		SnmpObjectId id = new SnmpObjectId(startFrom);
		lastOidUsed = id.toString();
		try {
			lastMibUsedActualName = reader.getMibActualName(startFrom);
		} catch (Exception e) {
			lastMibUsedActualName = null;
		}
		SnmpWalker walker = new SnmpWalker(session, id);
		walker.run();
		pduVector = walker.getPduVector();
		String outString = walker.getResults();
		setTestAgainstObject(outString);

		String temp = lastValue;
		lastValue = "";
		report(true, silent, true, "Walk", null, outString);
		lastValue = temp;
	}

	protected void report(boolean pass, boolean silent, boolean addLinkToReport, String operation, String reportString, String message) {
		if (!silent || !pass) { // report if not silent or failed
			if (!addLinkToReport && pass) { // no link if pass and not add link
				// to report
				message = null;
			}
			String reportStr = ("SNMP " + operation + ": " + (lastMibUsedActualName == null ? "" : lastMibUsedActualName + " (")
					+ lastOidUsed + (lastMibUsedActualName == null ? "" : ")") + ": " + lastValue);
			if (reportString == null) {
				if (lastMibUsedActualName == null && reader != null) {
					try {
						lastMibUsedActualName = reader.getMibActualName(lastOidUsed);
					} catch (Exception e) {
						lastMibUsedActualName = null;
					}
				}
				reportString = reportStr;
			}
			if (!pass) {
				if (message == null) {
					message = "";
				}
				message = reportStr + "\n\n" + message;
			}
			report.report(reportString, message, pass);
		}
	}

	/**
	 * Perform a SNMP walk.
	 * 
	 * @param startFrom
	 *            Start from MIB like ".1.3".
	 * 
	 * @exception Exception
	 */
	public void walk(String startFrom) throws Exception {
		walk(startFrom, false);
	}

	/**
	 * Perform a SNMP walk from the root ".1.3".
	 * 
	 * @exception Exception
	 */
	public void walk() throws Exception {
		walk(".1.3");
	}

	/**
	 * Generate SNMP get request for a single object.
	 * 
	 * @param mibName
	 *            The MIB to get.
	 * @param silent
	 *            boolean: add or don't add report for this action.
	 * 
	 * @exception Exception
	 */
	public void get(String mibName, boolean silent) throws Exception {
		get(new String[] { mibName }, silent, null);
	}

	/**
	 * Generate SNMP get request for multiple objects.
	 * 
	 * @param oid
	 *            Array of Strings : represent the OID of the MIB Objects to get
	 * @param silent
	 *            boolean: add or don't add report for this action.
	 * @param reportString
	 *            headline to add to the report about this action - or null for
	 *            use the last get data as headline
	 * @throws Exception
	 */
	public void get(String[] oid, boolean silent, String reportString) throws Exception {
		lastActionResult = false;
		lastOidUsed = oid[0];
		if (session == null) {
			initSession();
		}

		SnmpVarBind[] vb = new SnmpVarBind[oid.length];
		for (int i = 0; i < oid.length; i++) {
			vb[i] = new SnmpVarBind(new SnmpObjectId(oid[i]));
		}

		SnmpGetter getter = new SnmpGetter(reader, session, vb);
		getter.run();
		pduVector = getter.getPduVector();
		String outString = getter.getResults();
		lastActionResult = getter.isLastRunSuccess();
		lastOidUsed = getter.getLastRunOid();
		lastValue = getter.getLastRunValue();
		if (reader != null) {
			lastMibUsedActualName = reader.getMibActualName(lastOidUsed);
		} else {
			lastMibUsedActualName = null;
		}
		setTestAgainstObject(outString);

		report(true, silent, addLinkToReport, "Get", reportString, outString);
	}

	/**
	 * perform a non-silent get action
	 * 
	 * @param mibName
	 *            The MIB to get.
	 * @throws Exception
	 */
	public void get(String mibName) throws Exception {
		get(mibName, false);
	}

	/**
	 * perform a non-silent get next action
	 * 
	 * @param mibName
	 *            The MIB to get the next entry of it.
	 * @return the actual entry of the table that was retrived(Usefull for
	 *         another "getNext" operation in a row)
	 * @throws Exception
	 */
	public String getNext(String mibName) throws Exception {
		return getNext(mibName, false);
	}

	/**
	 * Generate SNMP single get-next request.
	 * 
	 * @param mibName
	 *            The MIB to get the next entry of it.
	 * @param silent
	 *            boolean: add or don't add report for this action.
	 * @return the actual entry of the table that was retrieved(Usefull for
	 *         another "getNext" operation in a row)
	 * @exception Exception
	 */
	public String getNext(String mibName, boolean silent) throws Exception {
		return getNext(new String[] { mibName }, silent, null);
	}

	/**
	 * Generate SNMP multiple get-next request.
	 * 
	 * @param oid
	 *            Array of Strings : represent the OID of the MIB Objects to get
	 *            next
	 * @param silent
	 *            boolean: add or don't add report for this action.
	 * @param reportString
	 *            headline to add to the report about this action - or null for
	 *            use the last get next data as headline
	 * @return the actual entry of the table that was retrieved(Usefull for
	 *         another "getNext" operation in a row)
	 * @throws Exception
	 */
	public String getNext(String[] oid, boolean silent, String reportString) throws Exception {
		lastActionResult = false;
		lastOidUsed = oid[0];
		if (session == null) {
			initSession();
		}
		SnmpVarBind[] vb = new SnmpVarBind[oid.length];
		for (int i = 0; i < oid.length; i++) {
			vb[i] = new SnmpVarBind(new SnmpObjectId(oid[i]));
		}

		SnmpGetter getter = new SnmpGetter(reader, session, vb);
		getter.runGetNext();
		pduVector = getter.getPduVector();
		String outString = getter.getResults();
		lastActionResult = getter.isLastRunSuccess();
		lastOidUsed = getter.getLastRunOid();
		lastValue = getter.getLastRunValue();
		if (reader != null) {
			lastMibUsedActualName = reader.getMibActualName(lastOidUsed);
		} else {
			lastMibUsedActualName = null;
		}
		setTestAgainstObject(outString);

		report(true, silent, addLinkToReport, "Get Next", reportString, outString);

		// return currentEntry;
		return lastOidUsed;
	}

	/**
	 * Generate SNMP set transaction.
	 * 
	 * @param vblist
	 *            VarBind list to set.
	 * @param ignoreFail
	 *            False to validate every "set" action with a following "get"
	 *            action, true to skip the validation with the "get".
	 * @throws Exception
	 */
	public void set(SnmpVarBind[] vblist, boolean ignoreFail) throws Exception {
		set(vblist, ignoreFail, null);
	}

	/**
	 * Generate SNMP set transaction.
	 * 
	 * @param vblist
	 *            VarBind list to set.
	 * @param ignoreFail
	 *            False to validate every "set" action with a following "get"
	 *            action, true to skip the validation with the "get".
	 * @param reportString
	 *            String to add to the report about this set action.
	 * 
	 * @exception Exception
	 */
	public void set(SnmpVarBind[] vblist, boolean ignoreFail, String reportString) throws Exception {
		lastActionResult = false;
		log.fine("Runnit set command");
		if (session == null) {
			initSession();
		}
		SnmpSetter setter = new SnmpSetter(reader, session, vblist);
		lastOidUsed = vblist[vblist.length - 1].toString();
		lastValue = vblist[vblist.length - 1].getValue().toString().trim();
		setter.run();
		pduVector = setter.getPduVector();
		String outString = setter.getResults();
		lastActionResult = setter.isLastRunSuccess();
		lastOidUsed = setter.getLastRunOid();
		if (!lastActionResult) {
			lastValue += " (Set Operation Failed)";
		}
		if (reader != null) {
			lastMibUsedActualName = reader.getMibActualName(lastOidUsed);
		} else {
			lastMibUsedActualName = null;
		}
		setTestAgainstObject(outString);

		report(true, false, addLinkToReport, "Set", reportString, outString);

		// checking if that we getting the same value we have set before.
		// (optional)
		if (!ignoreFail) {
			analyze(new FindText("Done"), true);
			for (int i = 0; i < vblist.length; i++) {
				get(vblist[i].getName().toString(), true);
				CheckTextCounter tc;
				if (vblist[i].getValue().toString().trim().equals("")) {
					// value is empty string or null - check that this is the
					// returned value
					tc = new CheckTextCounter(vblist[i].getName().toString(), "<b>Mib Symbol:</b>");
				} else {
					// value is not null or empty string - check for the
					// specific expected value
					tc = new CheckTextCounter(vblist[i].getName().toString(), vblist[i].getValue().toString());
				}
				analyze(tc, true);
			}
		}
	}

	/**
	 * Generate SNMP set transaction. for each set action it validates that the
	 * expected value actual appears in the MIB by "get" action
	 * 
	 * @param vblist
	 *            VarBind list to set.
	 * @throws Exception
	 */
	public void set(SnmpVarBind[] vblist) throws Exception {
		set(vblist, false);
	}

	/**
	 * Generate SNMP set transaction.
	 * 
	 * @param vblist
	 *            VarBind to set.
	 * @param ignoreFail
	 *            False to validate "set" action with a following "get" action,
	 *            true to skip the validation with the "get".
	 * @throws Exception
	 */
	public void set(SnmpVarBind vb, boolean ignoreFail) throws Exception {
		set(new SnmpVarBind[] { vb }, ignoreFail);
	}

	/**
	 * Generate SNMP set transaction. After it completes the "set" actions it
	 * performs a "get" actions on all given "validation" nodes and compare the
	 * returned value with the value given in the nodes.
	 * 
	 * @param vblist
	 *            VarBind list to set.
	 * @param validate
	 *            VarBind list of nodes to perform a "get" and compare the
	 *            returned value with. the validate mibs will use the current
	 *            "throwException" flag on the analyze process (see
	 *            "isThrowException()" method in "AnalyzerImpl" Class)
	 * @param silentValidation
	 *            false to report the validation "get" actions, true to perform
	 *            a silent validation "get" actions
	 * @throws Exception
	 */
	public void set(SnmpVarBind[] vblist, SnmpVarBind[] validate, boolean silentValidation) throws Exception {
		set(vblist, validate, silentValidation, null);
	}

	/**
	 * Generate SNMP set transaction. After it completes the "set" actions it
	 * performs a "get" actions on all given "validation" nodes and compare the
	 * returned value with the value given in the nodes.
	 * 
	 * @param vblist
	 *            VarBind list to set.
	 * @param validate
	 *            VarBind list of nodes to perform a "get" and compare the
	 *            returned value with. the validate mibs will use the current
	 *            "throwException" flag on the analyze process (see
	 *            "isThrowException()" method in "AnalyzerImpl" Class)
	 * @param silentValidation
	 *            false to report the validation "get" actions, true to perform
	 *            a silent validation "get" actions
	 * @param reportString
	 *            String to add to the report about this set action.
	 * 
	 * @throws Exception
	 */
	public void set(SnmpVarBind[] vblist, SnmpVarBind[] validate, boolean silentValidation, String reportString) throws Exception {
		if (isThrowException()) {
			set(vblist, validate, null, true, reportString);
		} else {
			set(vblist, null, validate, true, reportString);
		}
	}

	/**
	 * Set action using the "SnmpSetAction" Class
	 * 
	 * @param setAction
	 *            SnmpSetAction object represents all parameters for the "set
	 *            action
	 * @throws Exception
	 */
	public void set(SnmpSetAction setAction) throws Exception {
		set(setAction.getVblist(), setAction.getThrowingValidate(), setAction.getNonThrowingValidate(), setAction.isSilentValidation(),
				setAction.getHeadLine());
	}

	/**
	 * Generate SNMP set transaction. After it completes the "set" actions it
	 * performs a "get" actions on all given "validation" nodes and compare the
	 * returned value with the value given in the nodes. if the analyze over the
	 * set action failed and an exception was thrown - it sets the validation to
	 * be non silent, perform the non-throwing validations and than throws the
	 * exception, it enables the "error code" validation before test it stoped -
	 * for failure-debug use.
	 * 
	 * @param vblist
	 *            VarBind list to set.
	 * @param throwingValidate
	 *            VarBind list of nodes to perform a "get" and compare the
	 *            returned value with, will fail the test with error in case of
	 *            analyze fail and will throw Exception.
	 * @param nonThrowingValidate
	 *            VarBind list of nodes to perform a "get" and compare the
	 *            returned value with, will fail the test with error in case of
	 *            analyze fail but will not throw Exception.
	 * @param silentValidation
	 *            false to report the validation "get" actions, true to perform
	 *            a silent validation "get" actions
	 * @param reportString
	 *            String to add to the report about this set action.
	 * 
	 * @throws Exception
	 */
	public void set(SnmpVarBind[] vblist, SnmpVarBind[] throwingValidate, SnmpVarBind[] nonThrowingValidate, boolean silentValidation,
			String reportString) throws Exception {
		set(vblist, true, reportString);

		AnalyzerException thrownException = null;
		CheckTextCounter tc;

		/**
		 * perform an analyze on the last returned value - if one of the "set"
		 * actions failed - the analyze will fail and if it throws Exception -
		 * it will set the silent validation to false, perform the non throwing
		 * validation and than throw the exception.
		 */
		try {
			analyze(new FindText("Done"), true);
		} catch (AnalyzerException e) {
			thrownException = e;
			silentValidation = false;
		}

		/**
		 * check all non-throwing MIBs - will fail the test but will not throw
		 * Exception
		 */
		for (int i = 0; nonThrowingValidate != null && i < nonThrowingValidate.length; i++) {
			get(nonThrowingValidate[i].getName().toString(), silentValidation);
			tc = new CheckTextCounter(nonThrowingValidate[i].getName().toString(), nonThrowingValidate[i].getValue().toString());
			analyze(tc, true, false);
		}

		/**
		 * if the set action failed - it throws the captured exception
		 */
		if (thrownException != null) {
			throw thrownException;
		}
		/**
		 * check all throwing MIBs - will fail the test by throwing Exception in
		 * the analyze
		 */
		for (int i = 0; throwingValidate != null && i < throwingValidate.length; i++) {
			get(throwingValidate[i].getName().toString(), silentValidation);
			tc = new CheckTextCounter(throwingValidate[i].getName().toString(), throwingValidate[i].getValue().toString());
			analyze(tc, true, true);
		}
	}

	/**
	 * Generate SNMP set transaction. After it completes the "set" actions it
	 * performs a silent "get" actions on all given "validation" nodes and
	 * compare the returned value with the value given in the nodes.
	 * 
	 * @param vblist
	 *            VarBind list to set.
	 * @param validate
	 *            VarBind list of nodes to perform a "get" and compare the
	 *            returned value with. the validate mibs will use the current
	 *            "throwException" flag on the analyze process (see
	 *            "isThrowException()" method in "AnalyzerImpl" Class)
	 * @throws Exception
	 */
	public void set(SnmpVarBind[] vblist, SnmpVarBind[] validate) throws Exception {
		set(vblist, validate, true, null);
	}

	/**
	 * Generate SNMP set transaction. After it completes the "set" actions it
	 * performs a silent "get" actions on all given "validation" nodes and
	 * compare the returned value with the value given in the nodes.
	 * 
	 * @param vblist
	 *            VarBind list to set.
	 * @param validate
	 *            VarBind list of nodes to perform a "get" and compare the
	 *            returned value with. the validate mibs will use the current
	 *            "throwException" flag on the analyze process (see
	 *            "isThrowException()" method in "AnalyzerImpl" Class)
	 * @param reportString
	 *            String to add to the report about this set action.
	 * 
	 * @throws Exception
	 */
	public void set(SnmpVarBind[] vblist, SnmpVarBind[] validate, String reportString) throws Exception {
		set(vblist, validate, true, reportString);
	}

	/**
	 * Init the SNMP session.
	 * 
	 * @exception Exception
	 */
	public void initSession() throws Exception {
		log.fine("Running initSession");
		if (session != null) {
			session.close();
		}
		InetAddress remote = null;
		try {
			remote = InetAddress.getByName(host);
		} catch (IllegalArgumentException e) {
			report.report("Snmp: unable to init session address from: " + host, e);
			throw e;
		} catch (UnknownHostException e) {
			report.report("Snmp: unable to init session address from: " + host, e);
			throw e;
		}
		SnmpPeer peer = new SnmpPeer(remote);
		peer.setPort(port);
		log.fine("Port was set: " + port);
		peer.setTimeout(timeout);
		log.fine("timeout was set: " + timeout);
		peer.setRetries(retries);
		log.fine("retries was set: " + retries);
		SnmpParameters parms = peer.getParameters();
		parms.setVersion(version.version());
		log.fine("version was set: " + version);
		parms.setReadCommunity(readCommunity);
		log.fine("read community was set: " + readCommunity);
		parms.setWriteCommunity(writeCommunity);
		log.fine("write community was set: " + writeCommunity);

		//
		// Now create the session, set the initial request
		// and walk the tree!
		//
		try {
			session = new SnmpSession(peer);
		} catch (SocketException e) {
			report.report("Snmp: unable to create session", e);
			throw e;
		}
		log.fine("initSession done");
	}

	/**
	 * Close the SNMP connection.
	 */
	public void close() {
		if (session != null) {
			session.close();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestListener#addError(junit.framework.Test,
	 * java.lang.Throwable)
	 */
	public void addError(Test arg0, Throwable arg1) {
		if (trap == null)
			return;
		trap.addError(arg0, arg1);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestListener#addFailure(junit.framework.Test,
	 * junit.framework.AssertionFailedError)
	 */
	public void addFailure(Test arg0, AssertionFailedError arg1) {
		if (trap == null)
			return;
		trap.addFailure(arg0, arg1);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestListener#endTest(junit.framework.Test)
	 */
	public void endTest(Test arg0) {
		if (trap == null)
			return;
		trap.endTest(arg0);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestListener#startTest(junit.framework.Test)
	 */
	public void startTest(Test arg0) {
		if (trap == null)
			return;
		trap.startTest(arg0);
	}

	/**
	 * The function is building a HashMap of MIB names as key and OID as value.
	 * The map kept at MibReader class.
	 * 
	 * @throws Exception
	 */
	public void loadMibsToMap() throws Exception {
		loadMibsToMap(true);
	}

	/**
	 * The function is building a HashMap of MIB names as key and OID as value.
	 * The map kept at MibReader class.
	 * 
	 * @throws Exception
	 */
	public void loadMibsToMap(boolean initDefaultMibCompiler) throws Exception {
		/**
		 * if the user gave a MIB directory but didn't apply a specific MIB
		 * compiler - use the default MIB compiler
		 */
		if (mibCompiler == null) {
			mibCompiler = new DefaultMibCompilerImpl(initDefaultMibCompiler);
			if (!initDefaultMibCompiler) {
				((DefaultMibCompilerImpl) mibCompiler).init(false);
			}
		}
		reader = new MibReader(mibsDir, mibCompiler);
	}

	/**
	 * return MIB OID for given OID name.
	 * 
	 * @param mibName
	 * @return OID by the actual MIB name
	 */
	public String getOidFromMap(String mibName) {
		return reader.getOid(mibName);
	}

	/**
	 * retrieves the last OID that was in use
	 * 
	 * @return last OID as String, null if wasn't in use yet
	 */
	public String getLastOidUsed() {
		return lastOidUsed;
	}

	/**
	 * informs if the current status is "add link to report" or not
	 * 
	 * @return true if add link, false if not
	 */
	public boolean isAddLinkToReport() {
		return addLinkToReport;
	}

	/**
	 * to set if files will be created and links will be sdded to the report (if
	 * not - it adds only comment to the report instead of link)
	 * 
	 * @param addLinkToReport
	 *            true to create file and add link to report in set/get/get-next
	 *            action
	 */
	public void setAddLinkToReport(boolean addLinkToReport) {
		this.addLinkToReport = addLinkToReport;
	}

	/**
	 * retrieves the last value that was in use
	 * 
	 * @return - last value (get/set/get-next) that was in use, null if wasn't
	 *         in use yet
	 */
	public String getLastValue() {
		return lastValue;
	}

	/**
	 * retrieves the last MIBs actual-name that was in use
	 * 
	 * @return last name as String, null if wasn't in use yet
	 */
	public String getLastMibUsedActualName() {
		return lastMibUsedActualName;
	}

	/**
	 * returns the last action (get/set/getNext) result
	 * 
	 * @return true if the last action (get/set/getNext) succeeded, false if
	 *         failed or unknown
	 */
	public boolean isLastActionResult() {
		return lastActionResult;
	}

	/**
	 * sets the last action result
	 * 
	 * @param lastActionResult
	 *            true for success
	 */
	protected void setLastActionResult(boolean lastActionResult) {
		this.lastActionResult = lastActionResult;
	}

	public BasicMibCompiler getMibCompiler() {
		return mibCompiler;
	}

	public void setMibCompiler(BasicMibCompiler basicMibCompiler) {
		this.mibCompiler = basicMibCompiler;
	}

	/**
	 * returns the returned PDU packets from the last action taken
	 * (set/get/getNext/walk)
	 * 
	 * @return Vector<SnmpVarBind>, vector of all last action returned PDU
	 *         packets
	 */
	public Vector<SnmpVarBind> getPduVector() {
		return pduVector;
	}

	/**
	 * Add a listener to trap events
	 * 
	 * @param listener
	 */
	public void addTrapListener(SnmpTrapListener listener) {
		trap.addListener(listener);
	}

	public boolean isLaunchOnInit() {
		return launchOnInit;
	}

	public void setLaunchOnInit(boolean launchOnInit) {
		this.launchOnInit = launchOnInit;
	}

}
