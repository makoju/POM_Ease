/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp;

import org.opennms.protocols.snmp.SnmpPduPacket;

/**
 * Holds all the possible errors for a SNMP request as declared in"http://www.opennms.org/documentation/HEAD-2006-03-01/javadoc/org/opennms/protocols/snmp/SnmpPduPacket.html#ErrAuthorizationError"
 * 
 * use this enum to get the description of the error by String from its
 * int-value (returnd for each SNMP request)
 * 
 * @author Hovav
 * 
 */
public enum SnmpErrorCode {
	ErrNoError(SnmpPduPacket.ErrNoError, "No error occured in the request, Successful Request."), ErrAuthorizationError(
			SnmpPduPacket.ErrAuthorizationError, "The authorization failed."), ErrBadValue(SnmpPduPacket.ErrBadValue,
			"The object type does not match the object value in the agent's tables."), ErrCommitFailed(SnmpPduPacket.ErrCommitFailed,
			"Unable to commit the required values."), ErrGenError(SnmpPduPacket.ErrGenError, "Generic SNMPv1 error occured."), ErrInconsistentName(
			SnmpPduPacket.ErrInconsistentName, "The passed object identifier is not consistent."), ErrInconsistentValue(
			SnmpPduPacket.ErrInconsistentValue, "The specified value are not consistant."), ErrNoAccess(SnmpPduPacket.ErrNoAccess,
			"The specified SET request could not access the specified instance."), ErrNoCreation(SnmpPduPacket.ErrNoCreation,
			"The manager does not have the permission to create the specified object."), ErrNoSuchName(SnmpPduPacket.ErrNoSuchName,
			"There was no such object identifier defined in the agent's tables."), ErrNotWritable(SnmpPduPacket.ErrNotWritable,
			"The specified instance or table is not writable."), ErrReadOnly(SnmpPduPacket.ErrReadOnly,
			"Attempting to set a read-only object in the agent's tables."), ErrResourceUnavailable(SnmpPduPacket.ErrResourceUnavailable,
			"The requested resource are not available."), ErrTooBig(SnmpPduPacket.ErrTooBig,
			"The PDU was too large for the agent to process."), ErrUndoFailed(SnmpPduPacket.ErrUndoFailed,
			"Unable to perform the undo request."), ErrWrongEncoding(SnmpPduPacket.ErrWrongEncoding,
			"The specified object is not correctly encoded."), ErrWrongLength(SnmpPduPacket.ErrWrongLength,
			"The specified object is not the correct length."), ErrWrongType(SnmpPduPacket.ErrWrongType,
			"The specified object is not the correct type."), ErrWrongValue(SnmpPduPacket.ErrWrongValue,
			"The specified object doe not have the correct value.");

	private int errorCode;

	private String errorMessage;

	private static SnmpErrorCode[] allErrors = values();

	SnmpErrorCode(int errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public static String getErroreMessage(int errorCode) {
		for (int i = 0; i < allErrors.length; i++) {
			if (allErrors[i].errorCode == errorCode) {
				return "\"" + allErrors[i].name() + "\" - " + allErrors[i].errorMessage;
			}
		}
		return "No Such Error Code \"" + errorCode + "\"";
	}
}
