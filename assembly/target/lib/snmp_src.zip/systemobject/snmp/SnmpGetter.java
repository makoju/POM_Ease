/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp;

import java.util.Vector;
import java.util.logging.Logger;

import org.opennms.protocols.snmp.SnmpHandler;
import org.opennms.protocols.snmp.SnmpObjectId;
import org.opennms.protocols.snmp.SnmpPduPacket;
import org.opennms.protocols.snmp.SnmpPduRequest;
import org.opennms.protocols.snmp.SnmpSession;
import org.opennms.protocols.snmp.SnmpSyntax;
import org.opennms.protocols.snmp.SnmpV2Error;
import org.opennms.protocols.snmp.SnmpVarBind;

import systemobject.snmp.mibSymbolInfo.MibSymbolInfo;

public class SnmpGetter extends Object implements SnmpHandler {

	/**
	 * MIB Reader object
	 */
	public MibReader reader = null;

	/**
	 * Logger
	 */
	private static Logger log = Logger.getLogger(SnmpGetter.class.getName());

	/**
	 * Array of SnmpVarBind to get/getNext
	 * (org.opennms.protocols.snmp.SnmpVarBind)
	 */
	SnmpVarBind[] vblist = null;

	/**
	 * the session that will be used in the get/getNext actions
	 * (org.opennms.protocols.snmp.SnmpSession)
	 */
	SnmpSession session = null;

	/**
	 * the buffer of the results, errors and information about the get/getNext
	 * variables
	 */
	StringBuffer sb = null;

	/**
	 * boolean - represents the results of the last run
	 */
	boolean lastRunSuccess = false;

	/**
	 * String - for the last get/getNext action Object ID
	 */
	String lastRunOid = null;

	/**
	 * String - for the last get/getNext action value
	 */
	String lastRunValue = null;

	Vector<SnmpVarBind> pduVector = null;

	/**
	 * Ctor : perform a single get/getNext action
	 * 
	 * @param reader
	 *            MibReader Object initiated by the owner of this class
	 * @param session
	 *            Session object
	 * @param oid
	 *            Object ID as String ("1.1.1.1.1.1.1.1.1" format)
	 */
	public SnmpGetter(MibReader reader, SnmpSession session, String oid) {
		this(reader, session, new SnmpObjectId(oid));
	}

	/**
	 * Ctor : perform a single get/getNext action
	 * 
	 * @param reader
	 *            MibReader Object initiated by the owner of this class
	 * @param session
	 *            Session object
	 * @param id
	 *            Object ID represents the OID to get/getNext
	 */
	public SnmpGetter(MibReader reader, SnmpSession session, SnmpObjectId id) {
		this(reader, session, new SnmpVarBind(id));
	}

	/**
	 * Ctor : perform a single get/getNext action
	 * 
	 * @param reader
	 *            MibReader Object initiated by the owner of this class
	 * @param session
	 *            Session object
	 * @param id
	 *            SnmpVarBind Object represents the OID to get/getNext
	 */
	public SnmpGetter(MibReader reader, SnmpSession session, SnmpVarBind id) {
		this(reader, session, new SnmpVarBind[] { id });
	}

	/**
	 * Ctor : perform a multiple get/getNext action
	 * 
	 * @param reader
	 *            MibReader Object initiated by the owner of this class
	 * @param session
	 *            Session object
	 * @param vblist
	 *            a list of SnmpVarBind Objects to get/getNext - each one
	 *            represents the OID
	 */
	public SnmpGetter(MibReader reader, SnmpSession session, SnmpVarBind[] vblist) {
		this.reader = reader;
		this.session = session;
		this.sb = new StringBuffer();
		this.vblist = vblist;
		this.lastRunOid = this.vblist[0].getName().toString();
		this.lastRunValue = null;
		session.setDefaultHandler(this);

	}

	/**
	 * run the get operation for the given OIDs
	 * 
	 * @throws Exception
	 */
	public void run() throws Exception {
		run(SnmpPduPacket.GET);
	}

	protected void run(int action) throws Exception {
		lastRunSuccess = false;
		SnmpPduRequest pdu = new SnmpPduRequest(action, this.vblist);
		pdu.setRequestId(SnmpPduPacket.nextSequence());
		pduVector = null;
		synchronized (session) {
			log.fine("Send request for: " + this.vblist[0].getName());
			session.send(pdu);
			session.wait();
			reader = null;
		}
		/*
		 * finally { session.close(); }
		 */
	}

	/**
	 * run the getNext operation for the given OIDs
	 * 
	 * @throws Exception
	 */
	public void runGetNext() throws Exception {
		run(SnmpPduPacket.GETNEXT);
	}

	/**
	 * run the getBulk operation for the given OIDs
	 * 
	 * @throws Exception
	 */
	public void runGetBulk() throws Exception {
		run(SnmpPduPacket.GETBULK);
	}

	/**
	 * <P>
	 * This method is invoked when a pdu is successfully returned from the peer
	 * agent. The command argument is recovered from the received pdu.
	 * </P>
	 * 
	 * @param session
	 *            The SNMP session
	 * @param command
	 *            The PDU command
	 * @param pdu
	 *            The SNMP pdu
	 * 
	 */
	public void snmpReceivedPdu(SnmpSession session, int command, SnmpPduPacket pdu) {
		lastRunSuccess = false;
		log.fine("enter snmpReceivedPdu");
		SnmpPduRequest req = null;
		sb.append("<b>Getting the following:</b>\n");
		sb.append("\n<b>---------------------------------------------------------------------------</b>\n\n");
		try {
			if (pdu == null) {
				log.fine("Error: pdu is \"null\"\n");
				sb.append("Error: pdu is \"null\"\n");
			}

			if (pdu instanceof SnmpPduRequest && pdu.getCommand() == SnmpPduPacket.RESPONSE) {
				req = (SnmpPduRequest) pdu;
			} else {
				log.fine("Error: Received non-response command " + pdu.getCommand() + "\n");
				sb.append("Error: Received non-response command " + pdu.getCommand() + "\n");
			}

			if (req.getErrorStatus() != 0) {
				log.fine("End of mib reached, Error no: " + req.getErrorStatus() + " ("
						+ SnmpErrorCode.getErroreMessage(req.getErrorStatus()) + ")\n");
				sb.append("End of mib reached, Error no: " + req.getErrorStatus() + " ("
						+ SnmpErrorCode.getErroreMessage(req.getErrorStatus()) + ")\n");
			}

			if (pdu.getLength() == 0) {
				log.fine("Error: no VarBind in pdu\n");
				sb.append("Error: no VarBind in pdu\n");
			}

			//
			// Passed the checks so lets get the first varbind and
			// print out it's value
			//
			log.fine("Error check finished");
			String comments;
			String mibName;
			for (int i = 0; i < pdu.getLength(); i++) {
				log.fine("Get VarBind at: " + i);
				SnmpVarBind vb = pdu.getVarBindAt(i);
				if (vb == null) {
					log.fine("Error: VarBind is null\n");
					sb = new StringBuffer("Error: VarBind is null\n");
					return;
				}
				SnmpSyntax value = vb.getValue();
				if (value == null) {
					log.fine("Error: VarBind value is null\n");
					sb = new StringBuffer("Error: VarBind value is null\n");
					return;
				}
				if (value instanceof SnmpV2Error) {
					log.fine("Error: " + vb.getValue().toString() + "\n");
					sb = new StringBuffer("Error: " + vb.getValue().toString() + "\n");
					return;
				}
				if (pduVector == null) {
					pduVector = new Vector<SnmpVarBind>();
				}
				pduVector.add(vb);
				comments = "Cannot Extract Comments";
				mibName = "Cannot Extract MIB Name";
				if (reader != null) {
					MibSymbolInfo info = reader.getMibByFullOid(vb.getName().toString());
					if (info != null) {
						comments = info.getDescription();
						mibName = info.getMibName();
					}
				}
				sb.append("\n\n" + mibName + " " + vb.getName() + ": " + vb.getValue());
				sb.append("\n\n<b>Mib Symbol:</b>");
				sb.append("\n\n" + comments);
				sb.append("\n\n<b>---------------------------------------------------------------------------</b>\n\n");
			}

			lastRunSuccess = true;
			lastRunOid = pdu.getVarBindAt(pdu.getLength() - 1).getName().toString();
			lastRunValue = pdu.getVarBindAt(pdu.getLength() - 1).getValue().toString();

			sb.append("Done\n");
			log.fine("Done");
			return;
		} finally {
			synchronized (session) {
				session.notify();
			}
		}
	}

	/**
	 * <P>
	 * This method is invoked when an internal error occurs for the session. To
	 * determine the exact error the err parameter should be compared with all
	 * the error conditions defined in the SnmpSession class.
	 * </P>
	 * 
	 * @param session
	 *            The SNMP session in question
	 * @param err
	 *            The error that occured
	 * @param pdu
	 *            The PDU object that caused the error
	 * 
	 */
	public void snmpInternalError(SnmpSession session, int err, SnmpSyntax pdu) {
		lastRunSuccess = false;
		sb.append("Error: An unexpected error occured with the SNMP Session\n");
		sb.append("The error code is " + err + "\n");
		sb.append("Error: " + SnmpErrorCode.getErroreMessage(err) + "\n");
		synchronized (session) {
			session.notify();
		}
	}

	/**
	 * gets and initiate the results buffer content
	 * 
	 * @return results buffer content as String
	 */
	public String getResults() {
		String toReturn = sb.toString();
		sb = new StringBuffer();
		return toReturn;
	}

	/**
	 * <P>
	 * This method is invoked when an agent fails to respond in the required
	 * time. This method will only be invoked if the total retries exceed the
	 * number defined by the session.
	 * </P>
	 * 
	 * @param session
	 *            The SNMP Session
	 * @param pdu
	 *            The PDU object that timed out
	 * 
	 */
	public void snmpTimeoutError(SnmpSession session, SnmpSyntax pdu) {
		lastRunSuccess = false;
		sb.append("Error: The session timed out trying to communicate with the remote host\n");
		synchronized (session) {
			session.notify();
		}
	}

	/**
	 * returns the last action result (success/failure)
	 * 
	 * @return boolean : true for success, false for failure
	 */
	public boolean isLastRunSuccess() {
		return lastRunSuccess;
	}

	/**
	 * sets the last action result (success/failure)
	 * 
	 * @param lastRunSuccess
	 *            boolean : true for success, false for failure
	 */
	protected void setLastRunSuccess(boolean lastRunSuccess) {
		this.lastRunSuccess = lastRunSuccess;
	}

	/**
	 * returns last run OID as String
	 * 
	 * @return OID as String
	 */
	public String getLastRunOid() {
		return lastRunOid;
	}

	/**
	 * sets the last run OID as String
	 * 
	 * @param lastRunOid
	 *            OID as String
	 */
	protected void setLastRunOid(String lastRunOid) {
		this.lastRunOid = lastRunOid;
	}

	/**
	 * returns last run returned Value as String or null if the last run failed
	 * 
	 * @return returned Value as String or null if run failed
	 */
	public String getLastRunValue() {
		return lastRunValue;
	}

	/**
	 * sets the last run returned Value as String (should be null if the last
	 * run failed)
	 * 
	 * @param lastRunValue
	 *            returned Value as String (should be null if the last run
	 *            failed)
	 */
	protected void setLastRunValue(String lastRunValue) {
		this.lastRunValue = lastRunValue;
	}

	public Vector<SnmpVarBind> getPduVector() {
		return pduVector;
	}
}
