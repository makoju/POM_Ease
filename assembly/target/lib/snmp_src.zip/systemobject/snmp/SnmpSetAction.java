/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp;

import java.util.Vector;

import org.opennms.protocols.snmp.SnmpGauge32;
import org.opennms.protocols.snmp.SnmpInt32;
import org.opennms.protocols.snmp.SnmpObjectId;
import org.opennms.protocols.snmp.SnmpOctetString;
import org.opennms.protocols.snmp.SnmpSyntax;
import org.opennms.protocols.snmp.SnmpVarBind;

/**
 * This Class Should be used for a multiple MIBs set in a row with or without value validation.
 * It contains a lists of set Objects, mandatory validation Objects and non mandatory validation Objects.
 * It also contains (optional) a head line for this operation.
 * 
 * @author Hovav
 * 
 */
public class SnmpSetAction {

	protected String headLine = null;

	protected boolean silentValidation = true;

	protected Vector<SnmpVarBind> vblist = null;

	protected Vector<SnmpVarBind> throwingValidate = null;

	protected Vector<SnmpVarBind> nonThrowingValidate = null;

	/**
	 * Ctor, Empty SnmpSetAction Object All null
	 */
	public SnmpSetAction() {
		this(null, null, null, null);
	}

	/**
	 * Ctor, SnmpSetAction Object with just head line
	 * 
	 * @param headLine
	 *            name of the operation to add to the report
	 */
	public SnmpSetAction(String headLine) {
		this(headLine, null, null, null);
	}

	/**
	 * Ctor, SnmpSetAction Object with a list of objects to set
	 * 
	 * @param vblist
	 *            array of SnmpVarBind, the "set" operation to perform
	 */
	public SnmpSetAction(SnmpVarBind[] vblist) {
		this(null, vblist, null, null);
	}

	/**
	 * Ctor, SnmpSetAction Object with head line and a list of objects to set
	 * 
	 * @param headLine
	 *            name of the operation to add to the report
	 * @param vblist
	 *            array of SnmpVarBind, the "set" operation to perform
	 */
	public SnmpSetAction(String headLine, SnmpVarBind[] vblist) {
		this(headLine, vblist, null, null);
	}

	/**
	 * Ctor, SnmpSetAction Object with a list of objects to set and a list of
	 * throwing objects to validate after set
	 * 
	 * @param vblist
	 *            array of SnmpVarBind, the "set" operation to perform
	 * @param throwingValidate
	 *            array of SnmpVarBind, validate throwing values
	 */
	public SnmpSetAction(SnmpVarBind[] vblist, SnmpVarBind[] throwingValidate) {
		this(null, vblist, throwingValidate, null);
	}

	/**
	 * Ctor, SnmpSetAction Object head line, a list of objects to set and a list
	 * of throwing objects to validate after set
	 * 
	 * @param headLine
	 *            name of the operation to add to the report
	 * @param vblist
	 *            array of SnmpVarBind, the "set" operation to perform
	 * @param throwingValidate
	 *            array of SnmpVarBind, validate throwing values
	 */
	public SnmpSetAction(String headLine, SnmpVarBind[] vblist, SnmpVarBind[] throwingValidate) {
		this(headLine, vblist, throwingValidate, null);
	}

	/**
	 * Ctor, SnmpSetAction Object head line, a list of objects to set, a list of
	 * throwing objects to validate after set and a list of non throwing objects
	 * to validate after set
	 * 
	 * @param headLine
	 *            name of the operation to add to the report
	 * @param vblist
	 *            array of SnmpVarBind, the "set" operation to perform
	 * @param throwingValidate
	 *            array of SnmpVarBind, validate throwing values
	 * @param nonThrowingValidate
	 *            array of SnmpVarBind, validate non throwing values
	 */
	public SnmpSetAction(String headLine, SnmpVarBind[] vblist, SnmpVarBind[] throwingValidate, SnmpVarBind[] nonThrowingValidate) {
		this.headLine = headLine;
		this.vblist = setElements(this.vblist, vblist);
		this.throwingValidate = setElements(this.throwingValidate, throwingValidate);
		this.nonThrowingValidate = setElements(this.nonThrowingValidate, nonThrowingValidate);
	}

	/**
	 * add a new object to the tail of the set list, if the list was not
	 * initiated it will initiate it and than add the object
	 * 
	 * @param append
	 *            SnmpVarBind object to append for the "set" actions, the Object
	 *            will be added to the tail of the list
	 */
	public void append(SnmpVarBind append) {
		if (vblist == null) {
			vblist = new Vector<SnmpVarBind>();
		}
		vblist.addElement(append);
	}

	/**
	 * add a new object to the tail of the throwing validate list, if the list
	 * was not initiated it will initiate it and than add the object
	 * 
	 * @param append
	 *            SnmpVarBind object to append for the "throwing validate"
	 *            actions, the Object will be added to the tail of the list
	 */
	public void appendThrowingValidate(SnmpVarBind append) {
		if (throwingValidate == null) {
			throwingValidate = new Vector<SnmpVarBind>();
		}
		throwingValidate.addElement(append);
	}

	/**
	 * add a new object to the tail of the non throwing validate list, if the
	 * list was not initiated it will initiate it and than add the object
	 * 
	 * @param append
	 *            SnmpVarBind object to append for the "non throwing validate"
	 *            actions, the Object will be added to the tail of the list
	 */
	public void appendNonThrowingValidate(SnmpVarBind append) {
		if (nonThrowingValidate == null) {
			nonThrowingValidate = new Vector<SnmpVarBind>();
		}
		nonThrowingValidate.addElement(append);
	}

	/**
	 * add a new object to the tail of the set list, if the list was not
	 * initiated it will initiate it and than add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            set value as SnmpSyntax Object (all Snmp value Objects derives
	 *            from this Object)
	 */
	public void append(String oid, SnmpSyntax value) {
		append(new SnmpVarBind(new SnmpObjectId(oid), value));
	}

	/**
	 * add a new object to the tail of the throwing validate list, if the list
	 * was not initiated it will initiate it and than add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value as SnmpSyntax Object (all Snmp value Objects
	 *            derives from this Object)
	 */
	public void appendThrowingValidate(String oid, SnmpSyntax value) {
		appendThrowingValidate(new SnmpVarBind(new SnmpObjectId(oid), value));
	}

	/**
	 * add a new object to the tail of the non throwing validate list, if the
	 * list was not initiated it will initiate it and than add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value as SnmpSyntax Object (all Snmp value Objects
	 *            derives from this Object)
	 */
	public void appendNonThrowingValidate(String oid, SnmpSyntax value) {
		appendNonThrowingValidate(new SnmpVarBind(new SnmpObjectId(oid), value));
	}

	/**
	 * add a new SnmpInt32 / Integer-object to the tail of the set list, if the
	 * list was not initiated it will initiate it and than add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            set value of the "SnmpInt32" as int
	 */
	public void append(String oid, int value) {
		append(oid, new SnmpInt32(value));
	}

	/**
	 * add a new SnmpInt32 / Integer-object to the tail of the throwing validate
	 * list, if the list was not initiated it will initiate it and than add the
	 * object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value of the "SnmpInt32" as int
	 */
	public void appendThrowingValidate(String oid, int value) {
		appendThrowingValidate(oid, new SnmpInt32(value));
	}

	/**
	 * add a new SnmpInt32 / Integer-object to the tail of the non throwing
	 * validate list, if the list was not initiated it will initiate it and than
	 * add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value of the "SnmpInt32" as int
	 */
	public void appendNonThrowingValidate(String oid, int value) {
		appendNonThrowingValidate(oid, new SnmpInt32(value));
	}

	/**
	 * add a new SnmpGauge32 / Long-object to the tail of the set list, if the
	 * list was not initiated it will initiate it and than add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            set value of the "SnmpGauge32" as long
	 */
	public void append(String oid, long value) {
		append(oid, new SnmpGauge32(value));
	}

	/**
	 * add a new SnmpGauge32 / Long-object to the tail of the throwing validate
	 * list, if the list was not initiated it will initiate it and than add the
	 * object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value of the "SnmpGauge32" as long
	 */
	public void appendThrowingValidate(String oid, long value) {
		appendThrowingValidate(oid, new SnmpGauge32(value));
	}

	/**
	 * add a new SnmpGauge32 / Long-object to the tail of the non throwing
	 * validate list, if the list was not initiated it will initiate it and than
	 * add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value of the "SnmpGauge32" as long
	 */
	public void appendNonThrowingValidate(String oid, long value) {
		appendNonThrowingValidate(oid, new SnmpGauge32(value));
	}

	/**
	 * add a new SnmpOctetString / byte[]-object to the tail of the set list, if
	 * the list was not initiated it will initiate it and than add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            set value of the "SnmpOctetString" as byte[]
	 */
	public void append(String oid, byte[] value) {
		append(oid, new SnmpOctetString(value));
	}

	/**
	 * add a new SnmpOctetString / byte[]-object to the tail of the throwing
	 * validate list, if the list was not initiated it will initiate it and than
	 * add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value of the "SnmpOctetString" as byte[]
	 */
	public void appendThrowingValidate(String oid, byte[] value) {
		appendThrowingValidate(oid, new SnmpOctetString(value));
	}

	/**
	 * add a new SnmpOctetString / byte[]-object to the tail of the non throwing
	 * validate list, if the list was not initiated it will initiate it and than
	 * add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value of the "SnmpOctetString" as byte[]
	 */
	public void appendNonThrowingValidate(String oid, byte[] value) {
		appendNonThrowingValidate(oid, new SnmpOctetString(value));
	}

	/**
	 * add a new SnmpOctetString / byte[]-object (using String Object) to the
	 * tail of the set list, if the list was not initiated it will initiate it
	 * and than add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            set value of the "SnmpOctetString" as String
	 */
	public void append(String oid, String value) {
		SnmpOctetString os = new SnmpOctetString();
		os.setString(value);
		append(oid, os);
	}

	/**
	 * add a new SnmpOctetString / byte[]-object (using String Object) to the
	 * tail of the throwing validate list, if the list was not initiated it will
	 * initiate it and than add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value of the "SnmpOctetString" as String
	 */
	public void appendThrowingValidate(String oid, String value) {
		SnmpOctetString os = new SnmpOctetString();
		os.setString(value);
		appendThrowingValidate(oid, os);
	}

	/**
	 * add a new SnmpOctetString / byte[]-object (using String Object) to the
	 * tail of the non throwing validate list, if the list was not initiated it
	 * will initiate it and than add the object
	 * 
	 * @param oid
	 *            Object id of the Snmp MIB ("1.1.1.1.1.1" format)
	 * @param value
	 *            expected value of the "SnmpOctetString" as String
	 */
	public void appendNonThrowingValidate(String oid, String value) {
		SnmpOctetString os = new SnmpOctetString();
		os.setString(value);
		appendNonThrowingValidate(oid, os);
	}

	/**
	 * returns the set list as a SnmpVarBind array
	 * 
	 * @return the content of SnmpVarBind Objects from the set list
	 */
	public SnmpVarBind[] getVblist() {
		if (vblist != null && vblist.size() > 0) {
			return (vblist.toArray(new SnmpVarBind[vblist.size()]));
		}
		return null;
	}

	/**
	 * returns the throwing validate list as a SnmpVarBind array
	 * 
	 * @return the content of SnmpVarBind Objects from the throwing validate
	 *         list
	 */
	public SnmpVarBind[] getThrowingValidate() {
		if (throwingValidate != null && throwingValidate.size() > 0) {
			return (throwingValidate.toArray(new SnmpVarBind[throwingValidate.size()]));
		}
		return null;
	}

	/**
	 * returns the non throwing validate list as a SnmpVarBind array
	 * 
	 * @return the content of SnmpVarBind Objects from the non throwing validate
	 *         list
	 */
	public SnmpVarBind[] getNonThrowingValidate() {
		if (nonThrowingValidate != null && nonThrowingValidate.size() > 0) {
			return (nonThrowingValidate.toArray(new SnmpVarBind[nonThrowingValidate.size()]));
		}
		return null;
	}

	/**
	 * returns the current head line
	 * 
	 * @return String or null
	 */
	public String getHeadLine() {
		return headLine;
	}

	/**
	 * sets the current head line
	 * 
	 * @param headLine
	 *            String or null
	 */
	public void setHeadLine(String headLine) {
		this.headLine = headLine;
	}

	/**
	 * add a list of SnmpVarBind Objects to the set list
	 * 
	 * @param vblist
	 *            array of SnmpVarBind
	 */
	public void setVblist(SnmpVarBind[] vblist) {
		this.vblist = setElements(this.vblist, vblist);
	}

	/**
	 * add a list of SnmpVarBind Object to the throwing validate list
	 * 
	 * @param throwingValidate
	 *            array of SnmpVarBind
	 */
	public void setThrowingValidate(SnmpVarBind[] throwingValidate) {
		this.throwingValidate = setElements(this.throwingValidate, throwingValidate);
	}

	/**
	 * add a list of SnmpVarBind Object to the non throwing validate list
	 * 
	 * @param nonThrowingValidate
	 *            array of SnmpVarBind
	 */
	public void setNonThrowingValidate(SnmpVarBind[] nonThrowingValidate) {
		this.nonThrowingValidate = setElements(this.nonThrowingValidate, nonThrowingValidate);
	}

	/**
	 * add a list of elements to the given vector, if the list is "null - the
	 * vector will be set to null, if not: initiate the vector if null and add
	 * all elements to the vector
	 * 
	 * @param v
	 *            Vector to add the elements to
	 * @param e
	 *            array of SnmpVarBind
	 * @return the given Vector after adding all elements
	 */
	protected Vector<SnmpVarBind> setElements(Vector<SnmpVarBind> v, SnmpVarBind[] e) {
		if (e == null) {
			v = null;
		} else if (e.length == 0) {
			v = new Vector<SnmpVarBind>(0);
		} else {
			if (v == null) {
				v = new Vector<SnmpVarBind>();
			}
			for (int i = 0; i < e.length; i++) {
				v.addElement(e[i]);
			}
		}
		return v;
	}

	/**
	 * returns the current validation report status - if true - the validation
	 * will be silent and if false the validation "get" options will be written
	 * in the report log
	 * 
	 * @return the current silent validation status
	 */
	public boolean isSilentValidation() {
		return silentValidation;
	}

	/**
	 * returns the current validation report status - if true - the validation
	 * will be silent and if false the validation "get" options will be written
	 * in the report log
	 * 
	 * @param silentValidation
	 *            boolean, true for silent, false for non silent
	 */
	public void setSilentValidation(boolean silentValidation) {
		this.silentValidation = silentValidation;
	}
}
