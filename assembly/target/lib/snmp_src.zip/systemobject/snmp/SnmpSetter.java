/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp;

import java.util.Vector;
import java.util.logging.Logger;

import org.opennms.protocols.snmp.SnmpHandler;
import org.opennms.protocols.snmp.SnmpObjectId;
import org.opennms.protocols.snmp.SnmpPduPacket;
import org.opennms.protocols.snmp.SnmpPduRequest;
import org.opennms.protocols.snmp.SnmpSession;
import org.opennms.protocols.snmp.SnmpSyntax;
import org.opennms.protocols.snmp.SnmpV2Error;
import org.opennms.protocols.snmp.SnmpVarBind;

import systemobject.snmp.mibSymbolInfo.MibSymbolInfo;

/**
 * Used to set SNMP mibs
 * 
 * @author guy
 */
public class SnmpSetter extends Object implements SnmpHandler {

	/**
	 * MIB Reader object
	 */
	public MibReader reader = null;

	/**
	 * Logger
	 */
	private static Logger log = Logger.getLogger(SnmpSetter.class.getName());

	/**
	 * Array of SnmpVarBind to set (org.opennms.protocols.snmp.SnmpVarBind)
	 */
	SnmpVarBind[] vblist = null;

	/**
	 * the session that will be used in the set actions
	 * (org.opennms.protocols.snmp.SnmpSession)
	 */
	SnmpSession session = null;

	/**
	 * the buffer of the results, errors and information about the set variables
	 */
	StringBuffer sb = null;

	/**
	 * boolean - represents the results of the last run
	 */
	boolean lastRunSuccess = false;

	/**
	 * String - for the last set action Object ID
	 */
	String lastRunOid = null;

	/**
	 * String - for the last set action value
	 */
	String lastRunValue = null;

	Vector<SnmpVarBind> pduVector = null;

	/**
	 * Ctor : perform a single set action
	 * 
	 * @param reader
	 *            MibReader Object initiated by the owner of this class
	 * @param session
	 *            Session object
	 * @param oid
	 *            Object ID as String ("1.1.1.1.1.1.1.1.1" format)
	 * @param value
	 *            value to set in the given OID
	 */
	public SnmpSetter(MibReader reader, SnmpSession session, String oid, SnmpSyntax value) {
		this(reader, session, new SnmpVarBind(new SnmpObjectId(oid), value));
	}

	/**
	 * Ctor : perform a single set action
	 * 
	 * @param reader
	 *            MibReader Object initiated by the owner of this class
	 * @param session
	 *            Session object
	 * @param vb
	 *            a single SnmpVarBind to set - represents the OID and value
	 */
	public SnmpSetter(MibReader reader, SnmpSession session, SnmpVarBind vb) {
		this(reader, session, new SnmpVarBind[] { vb });
	}

	/**
	 * Ctor : perform a multiple set actions
	 * 
	 * @param reader
	 *            MibReader Object initiated by the owner of this class
	 * @param session
	 *            Session object
	 * @param vb
	 *            a list of SnmpVarBind Objects to set - each one represents the
	 *            OID and value
	 */
	public SnmpSetter(MibReader reader, SnmpSession session, SnmpVarBind[] vb) {
		this.reader = reader;
		this.session = session;
		this.vblist = vb;
		this.sb = new StringBuffer();
		this.lastRunOid = this.vblist[vblist.length - 1].getName().toString();
		this.lastRunValue = null;
		session.setDefaultHandler(this);
		log.fine("init SnmpSetter");

	}

	/**
	 * run the set operation for the given OIDs with the given values
	 * 
	 * @throws Exception
	 */
	public void run() throws Exception {
		lastRunSuccess = false;
		log.fine("running setter run");
		if (vblist == null || vblist.length == 0) {
			sb.append("Error: VarBind is null\n");
			log.fine("VarBind is null");
			return;
		} else {
			sb.append("<b>Setting the following:</b>\n");
			sb.append("\n<b>---------------------------------------------------------------------------</b>\n\n");
			log.fine("Printing VarBind array: " + vblist.length);
			String comments;
			String mibName;
			for (int i = 0; i < vblist.length; i++) {
				log.fine("About to print var: " + i);
				log.fine(vblist[i].getName() + ": " + vblist[i].getValue());
				comments = "Cannot Extract Comments";
				mibName = "Cannot Extract MIB Name";
				if (reader != null) {
					MibSymbolInfo info = reader.getMibByFullOid(vblist[i].getName().toString());
					if (info != null) {
						comments = info.getDescription();
						mibName = info.getMibName();
					}
				}
				sb.append("\n\n" + mibName + " " + vblist[i].getName() + ": " + vblist[i].getValue());
				sb.append("\n\n<b>Mib Symbol:</b>");
				sb.append("\n\n" + comments);
				sb.append("\n\n<b>---------------------------------------------------------------------------</b>\n\n");
			}
		}
		log.fine("Setting pdu");
		SnmpPduRequest pdu = new SnmpPduRequest(SnmpPduPacket.SET, vblist);
		log.fine("pdu was set");
		pdu.setRequestId(SnmpPduPacket.nextSequence());
		pduVector = null;
		synchronized (session) {
			log.fine("Send request\n");
			session.send(pdu);
			session.wait();
			reader = null;
		}
		/*
		 * finally { session.close(); }
		 */
	}

	/**
	 * <P>
	 * This method is invoked when a pdu is successfully returned from the peer
	 * agent. The command argument is recovered from the received pdu.
	 * </P>
	 * 
	 * @param session
	 *            The SNMP session
	 * @param command
	 *            The PDU command
	 * @param pdu
	 *            The SNMP pdu
	 * 
	 */
	public void snmpReceivedPdu(SnmpSession session, int command, SnmpPduPacket pdu) {
		lastRunSuccess = false;
		log.fine("enter snmpReceivedPdu");
		SnmpPduRequest req = null;
		if (pdu instanceof SnmpPduRequest && pdu.getCommand() == SnmpPduPacket.RESPONSE) {
			req = (SnmpPduRequest) pdu;
		} else {
			log.fine("Error: Received non-response command " + pdu.getCommand());
			sb.append("Error: Received non-response command " + pdu.getCommand() + "\n");
			synchronized (session) {
				session.notify();
			}
			return;
		}

		if (req.getErrorStatus() != 0) {
			log.fine("End of mib reached, Error no: " + req.getErrorStatus());
			sb.append("End of mib reached, Error no: " + req.getErrorStatus() + " (" + SnmpErrorCode.getErroreMessage(req.getErrorStatus())
					+ ")\n");
			synchronized (session) {
				session.notify();
			}
			return;
		}

		SnmpVarBind[] vb = pdu.toVarBindArray();
		if (vb == null || vb.length <= 0) {
			log.fine("Error: VarBind is null or empty\n");
			sb.append("Error: VarBind is null or empty\n");
			return;
		}

		SnmpSyntax value;
		for (int i = 0; i < vb.length; i++) {
			value = vb[i].getValue();
			if (value == null) {
				log.fine("Error: Index." + i + ": VarBind value is null\n");
				sb.append("Error: Index." + i + ": VarBind value is null\n");
				return;
			}
			if (value instanceof SnmpV2Error) {
				log.fine("Error: Index." + i + ": " + vb[i].getValue().toString() + "\n");
				sb.append("Error: Index." + i + ": " + vb[i].getValue().toString() + "\n");
				return;
			}
			if (!vb[i].getName().toString().equals(vblist[i].getName().toString())) {
				log.fine("Error: Index." + i + ": Expected Name: " + vblist[i].getValue().toString() + ", Actual Name: "
						+ vb[i].getValue().toString() + "\n");
				sb.append("Error: Index." + i + ": Expected Name: " + vblist[i].getValue().toString() + ", Actual Name: "
						+ vb[i].getValue().toString() + "\n");
				return;
			}
			if (!vb[i].getValue().toString().equals(vblist[i].getValue().toString())) {
				log.fine("Error: Index." + i + ": Expected Value: " + vblist[i].getValue().toString() + ", Actual Value: "
						+ vb[i].getValue().toString() + "\n");
				sb.append("Error: Index." + i + ": Expected Value: " + vblist[i].getValue().toString() + ", Actual Value: "
						+ vb[i].getValue().toString() + "\n");
				return;
			}
			if (pduVector == null) {
				pduVector = new Vector<SnmpVarBind>();
			}
			pduVector.add(vb[i]);
		}

		lastRunSuccess = true;
		lastRunOid = vb[vb.length - 1].getName().toString();
		lastRunValue = vb[vb.length - 1].getValue().toString();

		sb.append("Done\n");
		log.fine("Done");

		synchronized (session) {
			session.notify();
		}
		return;

	}

	/**
	 * <P>
	 * This method is invoked when an internal error occurs for the session. To
	 * determine the exact error the err parameter should be compared with all
	 * the error conditions defined in the SnmpSession class.
	 * </P>
	 * 
	 * @param session
	 *            The SNMP session in question
	 * @param err
	 *            The error that occured
	 * @param pdu
	 *            The PDU object that caused the error
	 * 
	 */
	public void snmpInternalError(SnmpSession session, int err, SnmpSyntax pdu) {
		lastRunSuccess = false;
		sb.append("Error: An unexpected error occured with the SNMP Session\n");
		sb.append("The error code is " + err + "\n");
		sb.append("Error: " + SnmpErrorCode.getErroreMessage(err) + "\n");
		synchronized (session) {
			session.notify();
		}
	}

	/**
	 * gets and initiate the results buffer content
	 * 
	 * @return results buffer content as String
	 */
	public String getResults() {
		String toReturn = sb.toString();
		sb = new StringBuffer();
		return toReturn;
	}

	/**
	 * <P>
	 * This method is invoked when an agent fails to respond in the required
	 * time. This method will only be invoked if the total retries exceed the
	 * number defined by the session.
	 * </P>
	 * 
	 * @param session
	 *            The SNMP Session
	 * @param pdu
	 *            The PDU object that timed out
	 * 
	 */
	public void snmpTimeoutError(SnmpSession session, SnmpSyntax pdu) {
		lastRunSuccess = false;
		sb.append("Error: The session timed out trying to communicate with the remote host\n");
		synchronized (session) {
			session.notify();
		}
	}

	/**
	 * returns the last action result (success/failure)
	 * 
	 * @return boolean : true for success, false for failure
	 */
	public boolean isLastRunSuccess() {
		return lastRunSuccess;
	}

	/**
	 * sets the last action result (success/failure)
	 * 
	 * @param lastRunSuccess
	 *            boolean : true for success, false for failure
	 */
	protected void setLastRunSuccess(boolean lastRunSuccess) {
		this.lastRunSuccess = lastRunSuccess;
	}

	/**
	 * returns the last run OID as String
	 * 
	 * @return OID as String
	 */
	public String getLastRunOid() {
		return lastRunOid;
	}

	/**
	 * sets the last run OID as String
	 * 
	 * @param lastRunOid
	 *            OID as String
	 */
	protected void setLastRunOid(String lastRunOid) {
		this.lastRunOid = lastRunOid;
	}

	/**
	 * returns the last run returned Value as String or null if the last run
	 * failed
	 * 
	 * @return returned Value as String or null if run failed
	 */
	public String getLastRunValue() {
		return lastRunValue;
	}

	/**
	 * sets the last run returned Value as String (should be null if the last
	 * run failed)
	 * 
	 * @param lastRunValue
	 *            returned Value as String (should be null if the last run
	 *            failed)
	 */
	protected void setLastRunValue(String lastRunValue) {
		this.lastRunValue = lastRunValue;
	}

	public Vector<SnmpVarBind> getPduVector() {
		return pduVector;
	}
}
