/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp;

import org.opennms.protocols.snmp.SnmpOctetString;
import org.opennms.protocols.snmp.SnmpPduPacket;
import org.opennms.protocols.snmp.SnmpPduTrap;
import org.opennms.protocols.snmp.SnmpTrapSession;

/**
 * The SNMP object gathers all trap data to a table. <br>
 * In order to get trap event when a trap indication, the following interface
 * should be implemented, and the listener should be registered via the SNMP
 * object;
 * 
 * @author Nizan Freedman
 * 
 */
public interface SnmpTrapListener {

	/**
	 * A Version 2 PACKET info
	 * 
	 * @param pdu
	 */
	public void v2PacketRecieved(SnmpTrapSession session, java.net.InetAddress agent, int port, SnmpOctetString community, SnmpPduPacket pdu);

	/**
	 * A Version 1 TRAP info
	 * 
	 * @param pdu
	 */
	public void v1trapRecieved(SnmpTrapSession session, java.net.InetAddress agent, int port, SnmpOctetString community, SnmpPduTrap pdu);
}
