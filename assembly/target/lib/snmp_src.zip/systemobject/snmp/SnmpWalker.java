/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp;

import java.util.Vector;
import java.util.logging.Logger;

import org.opennms.protocols.snmp.SnmpEndOfMibView;
import org.opennms.protocols.snmp.SnmpHandler;
import org.opennms.protocols.snmp.SnmpObjectId;
import org.opennms.protocols.snmp.SnmpPduPacket;
import org.opennms.protocols.snmp.SnmpPduRequest;
import org.opennms.protocols.snmp.SnmpSession;
import org.opennms.protocols.snmp.SnmpSyntax;
import org.opennms.protocols.snmp.SnmpV2Error;
import org.opennms.protocols.snmp.SnmpVarBind;

public class SnmpWalker extends Object implements SnmpHandler {

	/**
	 * Logger
	 */
	private static Logger log = Logger.getLogger(SnmpWalker.class.getName());

	SnmpObjectId startId = null;

	/**
	 * Stop ID as String for IDs greater than 2^31
	 */
	String stopId = null;

	SnmpSession session = null;

	StringBuffer sb = null;

	Vector<SnmpVarBind> pduVector = null;

	public SnmpWalker(SnmpSession session, SnmpObjectId id) {
		this.session = session;
		sb = new StringBuffer();
		this.startId = id;
		// log.fine("Start id: " + startId);
		int[] ids = ((SnmpObjectId) startId.clone()).getIdentifiers();
		++ids[ids.length - 1];
		stopId = (new SnmpObjectId(ids)).toString();
		session.setDefaultHandler(this);
		log.fine("Start id: " + startId.toString());
		log.fine("Stop id:  " + stopId);

	}

	public void run() throws Exception {
		SnmpVarBind[] vblist = { new SnmpVarBind(startId) };
		SnmpPduRequest pdu = new SnmpPduRequest(SnmpPduPacket.GETNEXT, vblist);
		pdu.setRequestId(SnmpPduPacket.nextSequence());
		pduVector = null;
		synchronized (session) {
			log.fine("Send request for: " + vblist[0].getName());
			session.send(pdu);
			session.wait();
		}
		/*
		 * finally { session.close(); }
		 */
	}

	/**
	 * <P>
	 * This method is invoked when a pdu is successfully returned from the peer
	 * agent. The command argument is recovered from the received pdu.
	 * </P>
	 * 
	 * @param session
	 *            The SNMP session
	 * @param command
	 *            The PDU command
	 * @param pdu
	 *            The SNMP pdu
	 * 
	 */
	public void snmpReceivedPdu(SnmpSession session, int command, SnmpPduPacket pdu) {
		// log.fine("enter snmpReceivedPdu");
		SnmpPduRequest req = null;

		if (pdu == null) {
			sb.append("Error: pdu is \"null\"\n");
			return;
		}

		if (pdu instanceof SnmpPduRequest) {
			req = (SnmpPduRequest) pdu;
		}

		if (pdu.getCommand() != SnmpPduPacket.RESPONSE) {
			sb.append("Error: Received non-response command " + pdu.getCommand() + "\n");
			synchronized (session) {
				session.notify();
			}
			return;
		}

		if (req.getErrorStatus() != 0) {
			sb.append("End of mib reached, Error no: " + req.getErrorStatus() + "\n");
			synchronized (session) {
				session.notify();
			}
			return;
		}

		//
		// Passed the checks so lets get the first varbind and
		// print out it's value
		//
		SnmpVarBind vb = pdu.getVarBindAt(0);
		if (vb == null) {
			sb.append("Error: VarBind is null\n");
			synchronized (session) {
				session.notify();
			}
			return;
		}
		SnmpSyntax value = vb.getValue();
		if (value == null) {
			sb.append("Error: VarBind value is null\n");
			synchronized (session) {
				session.notify();
			}
			return;
		}
		if (value instanceof SnmpV2Error) {
			sb.append("Error: " + vb.getValue().toString() + "\n");
			synchronized (session) {
				session.notify();
			}
			return;
		}

		/**
		 * use String compare for OID values greater than 2^31 which referred as
		 * negative values due to 2's compliment
		 */
		if (vb.getValue().typeId() == SnmpEndOfMibView.ASNTYPE || (stopId != null && stopId.compareTo(vb.getName().toString()) <= 0)) {
			sb.append("Done\n");
			synchronized (session) {
				session.notify();
			}
			return;
		}
		if (pduVector == null) {
			pduVector = new Vector<SnmpVarBind>();
		}
		pduVector.add(vb);
		sb.append(vb.getName().toString() + ": " + value.toString() + "\n");

		//
		// make the next pdu
		//
		SnmpVarBind[] vblist = { new SnmpVarBind(vb.getName()) };
		SnmpPduRequest newReq = new SnmpPduRequest(SnmpPduPacket.GETNEXT, vblist);
		newReq.setRequestId(SnmpPduPacket.nextSequence());
		// log.fine("Send request for: " + vblist[0].getName());
		session.send(newReq);
	}

	/**
	 * <P>
	 * This method is invoked when an internal error occurs for the session. To
	 * determine the exact error the err parameter should be compared with all
	 * the error conditions defined in the SnmpSession class.
	 * </P>
	 * 
	 * @param session
	 *            The SNMP session in question
	 * @param err
	 *            The error that occured
	 * @param pdu
	 *            The PDU object that caused the error
	 * 
	 */
	public void snmpInternalError(SnmpSession session, int err, SnmpSyntax pdu) {
		sb.append("Error: An unexpected error occured with the SNMP Session\n");
		sb.append("The error code is " + err + "\n");
		synchronized (session) {
			session.notify();
		}
	}

	public String getResults() {
		String toReturn = sb.toString();
		sb = new StringBuffer();
		return toReturn;
	}

	/**
	 * <P>
	 * This method is invoked when an agent fails to respond in the required
	 * time. This method will only be invoked if the total retries exceed the
	 * number defined by the session.
	 * </P>
	 * 
	 * @param session
	 *            The SNMP Session
	 * @param pdu
	 *            The PDU object that timed out
	 * 
	 */
	public void snmpTimeoutError(SnmpSession session, SnmpSyntax pdu) {
		sb.append("Error: The session timed out trying to communicate with the remote host\n");
		synchronized (session) {
			session.notify();
		}
	}

	public Vector<SnmpVarBind> getPduVector() {
		return pduVector;
	}
}
