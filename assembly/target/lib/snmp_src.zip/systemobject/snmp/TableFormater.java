/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp;

import java.util.Vector;

public class TableFormater {
	private Vector<Vector<String>> table = null;

	private int[] columnMaxSize = null;

	public TableFormater(String[] headers) {
		table = new Vector<Vector<String>>();
		Vector<String> header = new Vector<String>();
		for (int i = 0; i < headers.length; i++) {
			header.add(headers[i]);
		}
		table.add(header);
	}

	public TableFormater() {
		table = new Vector<Vector<String>>();
	}

	public void setHeader(Vector<String> header) {
		table.add(0, header);
	}

	public void setHeader(String[] array) {
		Vector<String> v = new Vector<String>();
		for (int i = 0; i < array.length; i++) {
			v.add(array[i]);
		}
		setHeader(v);
	}

	public void log(String[] fields) {
		Vector<String> tmp = new Vector<String>();
		for (int i = 0; i < fields.length; i++) {
			tmp.add(fields[i]);
		}
		table.add(tmp);
	}

	public void log(Vector<String> fields) {
		table.add(fields);
	}

	private String getChars(int spaceCount, String s) {
		StringBuffer b = new StringBuffer(spaceCount);
		for (int i = 0; i < spaceCount; i++) {
			b.append(s);
		}
		return b.toString();
	}

	private void initColumnMaxSizes() {
		columnMaxSize = new int[(table.elementAt(0)).size()];
		for (int i = 0; i < columnMaxSize.length; i++) {
			columnMaxSize[i] = 0;
		}
		for (int i = 0; i < table.size(); i++) {
			Vector<String> row = table.elementAt(i);
			for (int j = 0; j < row.size(); j++) {
				int fieldSize = ((String) row.elementAt(j)).length();
				if (fieldSize > columnMaxSize[j]) {
					columnMaxSize[j] = fieldSize;
				}
			}
		}
	}

	public String toString() {
		initColumnMaxSizes();
		StringBuffer buff = new StringBuffer();
		for (int i = 0; i < table.size(); i++) {
			Vector<String> row = table.elementAt(i);
			if (i == 1) {
				for (int j = 0; j < row.size(); j++) {
					buff.append(getChars(columnMaxSize[j] + 1, "-") + " ");
				}
				buff.append("\n");
			}
			for (int j = 0; j < row.size(); j++) {
				String addTmp = row.elementAt(j).toString();
				buff.append(addTmp + getChars(columnMaxSize[j] + 2 - addTmp.length(), " "));
			}
			buff.append("\n");
		}
		return buff.toString();
	}

}
