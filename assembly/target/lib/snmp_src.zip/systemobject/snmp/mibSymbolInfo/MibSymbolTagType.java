/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp.mibSymbolInfo;

import net.percederberg.mibble.MibTypeTag;

/**
 * This ENUM represents a MIB entry tag type. the built in values are for the
 * "UNIVERSAL" category. in case of APPLICATION/CONTEXT_SPECIFIC/PRIVATE
 * CATEGORY the value represented by the global category name.
 * 
 * @author Hovav
 * 
 */
public enum MibSymbolTagType {
	NOT_AVAILABLE(null),
	APPLICATION_CATEGORY(null),
	CONTEXT_SPECIFIC_CATEGORY(null),
	PRIVATE_CATEGORY(null),
	BOOLEAN(MibTypeTag.BOOLEAN),
	INTEGER(MibTypeTag.INTEGER),
	BIT_STRING(MibTypeTag.BIT_STRING),
	OCTET_STRING(MibTypeTag.OCTET_STRING),
	NULL(MibTypeTag.NULL),
	OBJECT_IDENTIFIER(MibTypeTag.OBJECT_IDENTIFIER),
	REAL(MibTypeTag.REAL),
	SEQUENCE(MibTypeTag.SEQUENCE),
	SET(MibTypeTag.SET);

	private MibTypeTag access;

	MibSymbolTagType(MibTypeTag access) {
		this.access = access;
	}

	/**
	 * returns the matching MibSymbolTagType to the given MibTypeTag object.
	 * 
	 * @param snmpTypeTag
	 *            MibTypeTag object or null
	 * @return the matching MibSymbolTagType to the given MibTypeTag object or
	 *         MibSymbolTagType.NOT_AVAILABLE if the given parameter is "null"
	 */
	public static MibSymbolTagType get(MibTypeTag snmpTypeTag) {
		if (snmpTypeTag != null) {
			if (snmpTypeTag.getCategory() == MibTypeTag.APPLICATION_CATEGORY) {
				return MibSymbolTagType.APPLICATION_CATEGORY;
			} else if (snmpTypeTag.getCategory() == MibTypeTag.CONTEXT_SPECIFIC_CATEGORY) {
				return MibSymbolTagType.CONTEXT_SPECIFIC_CATEGORY;
			} else if (snmpTypeTag.getCategory() == MibTypeTag.PRIVATE_CATEGORY) {
				return MibSymbolTagType.PRIVATE_CATEGORY;
			} else {
				MibSymbolTagType[] arr = values();
				for (int i = 0; i < arr.length; i++) {
					if (arr[i].access == snmpTypeTag) {
						return arr[i];
					}
				}
			}
		}
		return MibSymbolTagType.NOT_AVAILABLE;
	}

	/**
	 * returns the category value as integer
	 * {@link MibTypeTag#UNIVERSAL_CATEGORY}
	 * {@link MibTypeTag#APPLICATION_CATEGORY}
	 * {@link MibTypeTag#CONTEXT_SPECIFIC_CATEGORY}
	 * {@link MibTypeTag#PRIVATE_CATEGORY} {@link MibTypeTag#getCategory()}
	 * 
	 * @return category as integer
	 */
	public int getCategory() {
		if (access == null) {
			return -1;
		}
		return access.getCategory();
	}

	/**
	 * returns the category value as integer {@link MibTypeTag#getValue()}
	 * 
	 * @return category as integer
	 */
	public int getValue() {
		if (access == null) {
			return -1;
		}
		return access.getValue();
	}

}
