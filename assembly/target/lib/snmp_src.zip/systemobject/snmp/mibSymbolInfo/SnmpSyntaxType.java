/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package systemobject.snmp.mibSymbolInfo;

import org.opennms.protocols.snmp.SnmpSyntax;

public enum SnmpSyntaxType {

	SnmpCounter64(new org.opennms.protocols.snmp.SnmpCounter64(), null),
	SnmpInt32(new org.opennms.protocols.snmp.SnmpInt32(), null),
	SnmpNull(new org.opennms.protocols.snmp.SnmpNull(), null),
	SnmpObjectId(new org.opennms.protocols.snmp.SnmpObjectId(), null),
	SnmpOctetString(new org.opennms.protocols.snmp.SnmpOctetString(), null),
	SnmpIpAddress(new org.opennms.protocols.snmp.SnmpIPAddress(), SnmpSyntaxType.SnmpOctetString),
	SnmpOpaque(new org.opennms.protocols.snmp.SnmpOpaque(),	SnmpSyntaxType.SnmpOctetString),
	SnmpPduBulk(new org.opennms.protocols.snmp.SnmpPduBulk(), null),
	SnmpPduRequest(new org.opennms.protocols.snmp.SnmpPduRequest(), null),
	SnmpPduTrap(new org.opennms.protocols.snmp.SnmpPduTrap(), null),
	SnmpUInt32(new org.opennms.protocols.snmp.SnmpUInt32(), null),
	SnmpCounter32(new org.opennms.protocols.snmp.SnmpCounter32(), SnmpSyntaxType.SnmpUInt32),
	SnmpGauge32(new org.opennms.protocols.snmp.SnmpGauge32(), SnmpSyntaxType.SnmpUInt32),
	SnmpTimeTicks(new org.opennms.protocols.snmp.SnmpTimeTicks(), SnmpSyntaxType.SnmpUInt32),
	SnmpV2PartyClock(new org.opennms.protocols.snmp.SnmpV2PartyClock(),	SnmpSyntaxType.SnmpUInt32),
	SnmpEndOfMibView(new org.opennms.protocols.snmp.SnmpEndOfMibView(), null),
	SnmpNoSuchInstance(new org.opennms.protocols.snmp.SnmpNoSuchInstance(),	null),
	SnmpNoSuchObject(new org.opennms.protocols.snmp.SnmpNoSuchObject(), null),
	SnmpVarBind(new org.opennms.protocols.snmp.SnmpVarBind(), null);

	SnmpSyntaxType(SnmpSyntax snmpSyntax, SnmpSyntaxType father) {
		this.father = father;
		this.snmpSyntax = snmpSyntax;
	}

	private SnmpSyntax snmpSyntax;

	private SnmpSyntaxType father;

	public boolean isInstance(SnmpSyntax syntax) {
		if (snmpSyntax.getClass().isInstance(syntax)) {
			if (father == null || !father.isInstance(syntax)) {
				return true;
			}
		}
		return false;
	}

	public static SnmpSyntaxType get(SnmpSyntax syntax) {
		SnmpSyntaxType[] arr = values();
		for (int i = 0; i < arr.length; i++) {
			if (arr[i].isInstance(syntax)) {
				return arr[i];
			}
		}
		return null;
	}

	public SnmpSyntax get() {
		return snmpSyntax.duplicate();
	}

}
