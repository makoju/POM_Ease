/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package com.aqua.stations;

import jsystem.framework.system.SystemObjectImpl;

public class StationsManager extends SystemObjectImpl {
	public Station[] stations;
}
