/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package org.jsystem.objects.handlers;

public interface HandlersList {
	
	public HandlerBasic[] getHandlersList();
	
}
