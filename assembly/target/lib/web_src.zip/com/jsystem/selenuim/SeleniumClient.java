/**
 * Copyright 2008, JSystem Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsystem.selenuim;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Properties;

import javax.imageio.ImageIO;

import jsystem.framework.report.Reporter;

import com.thoughtworks.selenium.CommandProcessor;
import com.thoughtworks.selenium.DefaultSelenium;

/**
 * This class implements everything that we have in the default
 * selenium client driver. All JSystem specific functionality should be added
 * here. Such functionality should be: reports, analyzers, logs, etc.
 * 
 * @author Michael Oziransky
 */
public class SeleniumClient extends DefaultSelenium {

	public enum BrowserType {
		FIREFOX,
		EXPLORER
	}

	private static Reporter reporter;
	private Properties linkMap;
	private String timeout;
	private BrowserType browser;
	private boolean autoMapEnabled;
	private String autoMapPrefix;
	private int retries = 5;
	
	public SeleniumClient(String serverHost, int serverPort,
			String browserStartCommand, String browserURL) {
		super(serverHost, serverPort, browserStartCommand, browserURL);
		
		// Create a map file that will hold all links
		linkMap = new Properties();		
		// Set the default timeout
		timeout = "30000";
		// Default browser is firefox
		if(browserStartCommand.equals("*firefox")){
			browser = BrowserType.FIREFOX;
		} else if(browserStartCommand.equals("*iexplore")){
			browser = BrowserType.EXPLORER;
		}
	}

	/**
	 * Creates a map of links based on given properties file.
	 * The structure of the file should be <key>=<value>
	 * @param fileName
	 * 			Name of the file to load the properties from
	 */
	public void initLinksProperties(String fileName) throws Exception {
		try {			
			linkMap.load(new FileInputStream(fileName));
		} catch (IOException e) {
			report("Unable to load links properties file");
			throw e;
		}
	}
	
	/**
	 * Returns a link from the link properties.
	 * The returned link can be used directly in the selenium client
	 * functions that require a locator.
	 * @param key
	 * 			Key to find a link
	 * @param arguments
	 * 			Optional arguments
	 * @return
	 * 			String 
	 */
	public String getLink(String key, Object... arguments) {
		if (arguments == null || arguments.length == 0) {
			return linkMap.getProperty(key);
		}
		for (int i=0; i< arguments.length; i++){
			arguments[i] = arguments[i].toString();
		}
		return MessageFormat.format(linkMap.getProperty(key), arguments);
	}
	
	/**
	 * Adds a screen shot to the report.
	 * The screenshot will be taken by focusing on the upper window
	 * at the time of the call. The files will be located under \"Screenshots\"
	 * directory in the test folder. The name of the file will be created from 
	 * the given name and the time that the screenshot was taken.
	 * @param label
	 * 			Label for the report
	 * @param fileName
	 * 			Name of the file
	 */
	public void addScreenshot(String label, String fileName) {
		String path = reporter.getCurrentTestFolder() + "\\Screenshots";

		// Check if this directory exists and if not create it
		File file = new File(path);
		if (!file.exists()) {
			file.mkdir();
			reporter.report("Created " + path, true);
		}

		// Create a file for the screenshot
		fileName = fileName.concat("_" + System.currentTimeMillis() + ".png");

	     try {
	 		final BufferedImage screencapture = new Robot().createScreenCapture(
			           new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()) );

			     // Save as JPEG
		     final File file1 = new File(path + "\\" + fileName);
		    new Thread(){
		    	public void run(){
					try {
						ImageIO.write(screencapture, "png", file1);
					} catch (IOException e) {
						e.printStackTrace();
						return;
					}
		    	}
		    }.start();
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		reporter.addLink(label, "Screenshots\\" + fileName);
	}
	
	/**
	 * Waits for a specified string to appear on the screen
	 * @param stringToSearch
	 * 			The string that we are waiting for
	 * @param timeOut
	 * 			Timeout indicating maximum time to wait
	 * @throws Exception
	 */
	public void waitForString(String stringToSearch, int timeOut) throws Exception {
		int i = 0;
		boolean result = false;
		Thread.sleep(1000);

		while (i < timeOut && !result) {
			result = isTextPresent(stringToSearch);
			i += 1000;
			Thread.sleep(1000);
		}
		if (!result) {
			System.out.println("String not found " + stringToSearch);
		}
		Thread.sleep(2000);
	}

	/**
	 * 
	 * @param stringToType
	 * @return
	 * @throws AWTException
	 */
	public void typeString(String stringToType) throws Exception {
		report("Starting to type sequence: " + stringToType);
		
		stringToType = stringToType.toUpperCase();
		char chars[] = stringToType.toCharArray();
		for (char c : chars) {
			int keyValue;
			// Handle special characters
			if (c == '@') {
				keyDownNative("" + KeyEvent.VK_SHIFT);
				keyPressNative("" + KeyEvent.VK_2);
				keyUpNative("" + KeyEvent.VK_SHIFT);
			} else {
				keyValue = new Integer(c).intValue();
				keyPressNative("" + keyValue);
			}
		}
		Thread.sleep(1000);
	}
	
	/**
	 * Presses on the tab given number of times
	 * @param numTabs
	 * 			Number of times to press on the tab
	 * @throws Exception
	 */
	public void tab(int numTabs) throws Exception {
		for (int j = 0; j < numTabs; j++) {
			keyPressNative("" + KeyEvent.VK_TAB);
		}
		Thread.sleep(1000);
	}
	
	/**
	 * Presses the enter given number of times
	 * @param numEnter
	 * 			Number of times to press on the enter
	 * @throws Exception
	 */
	public void enter(int numEnter) throws Exception {
		for (int j = 0; j < numEnter; j++) {
			keyPressNative("" + KeyEvent.VK_ENTER);
		}
		Thread.sleep(1000);

	}
	
	/**
	 * Performing upload phase.
	 * using xxx to focus on the upload window before typing
	 * the file name and absolute path.
	 * @param fullFileName
	 * @throws Exception
	 */
	public void uploadFile(String fullFileName) throws Exception{
		// Check that this is a browser that we can handle
		if ((browser != BrowserType.FIREFOX) && (browser != BrowserType.EXPLORER)) {
			report("Download file operation is not supported for this browser");
			return;
		}

		String windowName;
		Robot robot = new Robot();	
		robot.delay(3000);
		
		if (browser == BrowserType.FIREFOX) {
			windowName = "File Upload";
		} else {
			windowName = "Choose file";
		} 
		
		typePhraseIntoWindow(fullFileName.toCharArray(), windowName);		
		robot.keyPress(KeyEvent.VK_ENTER);
	}
	
	/**
	 * Download file process
	 * @param dirPath
	 * @param fileName
	 * @throws Exception
	 */
	public void downloadFile(String dirPath, String fileName) throws Exception {
		// Check that this is a browser that we can handle
		if ((browser != BrowserType.FIREFOX) && (browser != BrowserType.EXPLORER)) {
			report("Download file operation is not supported for this browser");
			return;
		}
		
		String pathAndFile = dirPath + fileName;
		Robot robot = new Robot();		
		robot.delay(3000);
		
		if (browser == BrowserType.FIREFOX) {
		} else {
			reporter.report("using IE");
			robot.keyPress(KeyEvent.VK_SHIFT);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_SHIFT);
		}
		
		robot.keyPress(KeyEvent.VK_ENTER);
		String windowName;
		
		if (browser == BrowserType.FIREFOX) {
			windowName = "Enter name of file to save to...";
		} else {
			windowName = "Save As";
		} 

		typePhraseIntoWindow(pathAndFile.toCharArray(),windowName);
		
		robot.keyPress(KeyEvent.VK_ENTER);
		
		if (browser == BrowserType.FIREFOX) {
			robot.keyPress(KeyEvent.VK_ESCAPE);
		} else {
			robot.keyPress(KeyEvent.VK_ENTER);
		} 
	}

	/**
	 * Type String to the activate window.
	 * @param phrase - Char Array
	 * @param windowName - String
	 * @throws Exception
	 */
	private void typePhraseIntoWindow(char[] phrase, String windowName) throws Exception {
		Robot robot = new Robot();
		robot.delay(3000);
		for (char key : phrase) {
			if (key == ':') {
				robot.keyPress(KeyEvent.VK_SHIFT);
				robot.keyPress(KeyEvent.VK_SEMICOLON);
				robot.keyRelease(KeyEvent.VK_SEMICOLON);
				robot.keyRelease(KeyEvent.VK_SHIFT);
			} else {
				if (key == '~') {
					robot.keyPress(KeyEvent.VK_SHIFT);
					robot.keyPress(KeyEvent.VK_BACK_QUOTE);
					robot.keyRelease(KeyEvent.VK_BACK_QUOTE);
					robot.keyRelease(KeyEvent.VK_SHIFT);
				} else {
					if (Character.isUpperCase(key)) {
						robot.keyPress(KeyEvent.VK_SHIFT);
						robot.keyPress(key);
						robot.keyRelease(key);
						robot.keyRelease(KeyEvent.VK_SHIFT);
					} else {
						robot.keyPress(Character.toUpperCase(key));
						robot.keyRelease(Character.toUpperCase(key));
					}
				}
			}
		}
	}

	/**
	 * Returns the used command processor for direct access to the commands
	 * @return
	 * 		CommandProcessor that is being used by the client
	 */
	public CommandProcessor getCommandProcessor() {
		return this.commandProcessor;
	}

	/**
	 * Blocks for a given time
	 * @param timeoutMs
	 * 			Timeout to block (in ms.)
	 * @throws Exception
	 */
	public void sleep(long timeoutMs) throws Exception {
		report("Blocking for: " + timeoutMs + "ms.");
		Thread.sleep(timeoutMs);
	}
	
	/**
	 * Below are the overwritten function from the default selenium implementation
	 */
	
	/**
	 * Returns the formalized link after checking it.
	 * In case the auto mapping mode is enabled, we need the following to exist:
	 * 1. The key should start with the set <code>autoMapPrefix</code>
	 * 2. There should be "." after the <code>autoMapPrefix</code>
	 */
	private String getElement(String key, Object... arguments) {
		if (autoMapEnabled) {
			// Check that key start with prefix
			if (key.startsWith(autoMapPrefix, 0)) {
				// Check that key has a "." after the prefix
				if (key.charAt(autoMapPrefix.length()) == '.') {
					return getLink(key, arguments);
				}
			}
		}
		
		return key;
	}
	
	@Override
	public void addSelection(String locator, String optionLocator) {		
		locator = getElement(locator);
		report("addSelection (locator=" + locator + " optionLocator=" + optionLocator);
		super.addSelection(locator, optionLocator);
	}

	@Override
	public void answerOnNextPrompt(String answer) {
		report("answerOnNextPromt (answer=" + answer + ")");
		super.answerOnNextPrompt(answer);
	}

	@Override
	public void check(String locator) {
		locator = getElement(locator);
		report("check (locator=" + locator + ")");
		int i=0;
		while (i<retries){
			try{
				super.check(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		
	}
	
	public void check(String locator, Object ...arguments) {
		locator = getElement(locator, arguments);
		report("check (locator=" + locator + ")");
		check(locator);
	}

	@Override
	public void chooseCancelOnNextConfirmation() {
		report("chooseCancelOnNextConfirmation");
		super.chooseCancelOnNextConfirmation();
	}

	
	@Override
	public void click(String locator) {
		locator = getElement(locator);
		report("click (locator=" + locator + ")");
		int i=0;
		while (i<retries){
			try{
				super.click(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		waitForPageToLoad(timeout);
	}
	
	/**
	 * Clicks on a given locator. Waits for the page to load based on given
	 * flag. The timeout that will be used for waiting is the default one.
	 * @param locator
	 * 			Locator to click on
	 * @param wait
	 * 			Flag indicating whether to wait for page to load
	 * @throws Exception
	 */
	public void click(String locator, boolean wait, Object... arguments) {
		locator = getElement(locator, arguments);
		report("click (locator=" + locator + ")");
		int i=0;
		while (i<retries){
			try{
				super.click(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		
		if (wait) {
			waitForPageToLoad(timeout);
		} else {
			report("Blocking for 500 ms.");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {}
		}
	}
	
	@Override
	public void close() {
		report("close");
		super.close();
	}

	@Override
	public void fireEvent(String locator, String eventName) {
		locator = getElement(locator);
		report("fireEvent (locator=" + locator + " eventName=" + eventName + ")");
		int i=0;
		while (i<retries){
			try{
				super.fireEvent(locator, eventName);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
	}
	
	public void fireEvent(String locator, String eventName, Object ...arguments) {
		locator = getElement(locator,arguments);
		fireEvent(locator, eventName);
	}

	@Override
	public String getAlert() {
		report("getAlert");
		return super.getAlert();
	}

	@Override
	public String[] getAllButtons() {
		report("getAllButtons");
		return super.getAllButtons();
	}

	@Override
	public String[] getAllFields() {
		report("getAllFields");
		return super.getAllFields();
	}

	@Override
	public String[] getAllLinks() {
		report("getAllLinks");
		return super.getAllLinks();
	}

	@Override
	public String getAttribute(String attributeLocator) {
		attributeLocator = getElement(attributeLocator);
		report("getAttributes (attributeLocator=" + attributeLocator + ")");
		return super.getAttribute(attributeLocator);
	}
	
	public String getAttribute(String attributeLocator, Object ...arguments) {
		attributeLocator = getElement(attributeLocator, arguments);
		report("getAttributes (attributeLocator=" + attributeLocator + ")");
		return super.getAttribute(attributeLocator);
	}

	@Override
	public String getBodyText() {
		report("getBodyText");
		return super.getBodyText();
	}

	@Override
	public String getConfirmation() {
		report("getConfirmation");
		return super.getConfirmation();
	}

	@Override
	public Number getCursorPosition(String locator) {
		locator = getElement(locator);
		report("getCurserPosition (locator=" + locator + ")");
		return super.getCursorPosition(locator);
	}

	@Override
	public String getEval(String script) {
		report("getEval (script=" + script + ")");
		return super.getEval(script);
	}

	@Override
	public String getExpression(String expression) {
		report("getExpression (expression=" + expression + ")");
		return super.getExpression(expression);
	}

	@Override
	public String getHtmlSource() {
		report("getHtmlSource");
		return super.getHtmlSource();
	}

	@Override
	public String getLocation() {
		report("getLocation");
		return super.getLocation();
	}

	@Override
	public String getPrompt() {
		report("getPromt");
		return super.getPrompt();
	}

	@Override
	public String getSelectedId(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("getSelectedId (selectionLocator=" + selectLocator + ")");
		return super.getSelectedId(selectLocator);
	}
	
	public String getSelectedId(String selectLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		report("getSelectedId (selectionLocator=" + selectLocator + ")");
		return super.getSelectedId(selectLocator);
	}

	@Override
	public String[] getSelectedIds(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("getSelectedIds (selectionLocator=" + selectLocator + ")");
		return super.getSelectedIds(selectLocator);
	}
	
	public String[] getSelectedIds(String selectLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		report("getSelectedIds (selectionLocator=" + selectLocator + ")");
		return super.getSelectedIds(selectLocator);
	}

	@Override
	public String getSelectedIndex(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("getSelectedIndex (selectionLocator=" + selectLocator + ")");
		return super.getSelectedIndex(selectLocator);
	}
	
	public String getSelectedIndex(String selectLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		report("getSelectedIndex (selectionLocator=" + selectLocator + ")");
		return super.getSelectedIndex(selectLocator);
	}

	@Override
	public String[] getSelectedIndexes(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("getSelectedIndexes (selectionLocator=" + selectLocator + ")");
		return super.getSelectedIndexes(selectLocator);
	}
	
	public String[] getSelectedIndexes(String selectLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		report("getSelectedIndexes (selectionLocator=" + selectLocator + ")");
		return super.getSelectedIndexes(selectLocator);
	}

	@Override
	public String getSelectedLabel(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("getSelectedLabel (selectionLocator=" + selectLocator + ")");
		return super.getSelectedLabel(selectLocator);
	}
	
	public String getSelectedLabel(String selectLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		report("getSelectedLabel (selectionLocator=" + selectLocator + ")");
		return super.getSelectedLabel(selectLocator);
	}

	@Override
	public String[] getSelectedLabels(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("getSelectedLabels (selectionLocator=" + selectLocator + ")");
		return super.getSelectedLabels(selectLocator);
	}
	
	public String[] getSelectedLabels(String selectLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		report("getSelectedLabels (selectionLocator=" + selectLocator + ")");
		return super.getSelectedLabels(selectLocator);
	}

	@Override
	public String getSelectedValue(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("getSelectedValue (selectionLocator=" + selectLocator + ")");
		return super.getSelectedValue(selectLocator);
	}
	
	public String getSelectedValue(String selectLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		report("getSelectedValue (selectionLocator=" + selectLocator + ")");
		return super.getSelectedValue(selectLocator);
	}

	@Override
	public String[] getSelectedValues(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("getSelectedValues (selectionLocator=" + selectLocator + ")");
		return super.getSelectedValues(selectLocator);
	}
	
	public String[] getSelectedValues(String selectLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		report("getSelectedValues (selectionLocator=" + selectLocator + ")");
		return super.getSelectedValues(selectLocator);
	}

	@Override
	public String[] getSelectOptions(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("getSelectOptions (selectionLocator=" + selectLocator + ")");
		return super.getSelectOptions(selectLocator);
	}
	
	public String[] getSelectOptions(String selectLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		report("getSelectOptions (selectionLocator=" + selectLocator + ")");
		return super.getSelectOptions(selectLocator);
	}

	@Override
	public String getTable(String tableCellAddress) {
		report("getTable (tableCellAddress=" + tableCellAddress + ")");
		return super.getTable(tableCellAddress);
	}

	@Override
	public String getText(String locator) {
		locator = getElement(locator);
		report("getText (locator=" + locator + ")");
		String text = null;
		int i=0;
		while (i<retries){
			try{
				text = super.getText(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		return text;
	}
	
	public String getText(String locator, Object ...arguments) {
		locator = getElement(locator, arguments);
		return getText(locator);
	}

	@Override
	public String getTitle() {
		report("getTitle");
		return super.getTitle();
	}

	@Override
	public String getValue(String locator) {
		locator = getElement(locator);
		report("getValue (locator=" + locator + ")");
		String value = null;
		int i=0;
		while (i<retries){
			try{
				value = super.getValue(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		return value;
	}
	
	public String getValue(String locator, Object ...arguments) {
		locator = getElement(locator, arguments);
		return getValue(locator);
	}

	@Override
	public void goBack() {
		report("goBack");
		super.goBack();
	}

	@Override
	public boolean isAlertPresent() {
		report("isAlertPresent");
		return super.isAlertPresent();
	}

	@Override
	public boolean isChecked(String locator) {
		locator = getElement(locator);
		report("isChecked (locator=" + locator + ")");
		boolean isChecked = false;
		int i=0;
		while (i<retries){
			try{
				isChecked = super.isChecked(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		return isChecked;

	}
	
	public boolean isChecked(String locator, Object ...arguments) {
		locator = getElement(locator, arguments);
		return isChecked(locator);
	}

	@Override
	public boolean isConfirmationPresent() {
		report("isConfirmationPresent");
		return super.isConfirmationPresent();
	}

	@Override
	public boolean isEditable(String locator) {
		locator = getElement(locator);
		report("isEditable (locator=" + locator + ")");
		boolean isEditable = false;
		int i=0;
		while (i<retries){
			try{
				isEditable = super.isEditable(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		return isEditable;
	}
	
	public boolean isEditable(String locator, Object ...arguments) {
		locator = getElement(locator, arguments);
		return isEditable(locator);
	}

	@Override
	public boolean isElementPresent(String locator) {		
		locator = getElement(locator);
		report("isElementPresent  (locator=" + locator + ")");
		boolean isPresent = false;
		int i=0;
		while (i<retries){
			try{
				isPresent = super.isElementPresent(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		return isPresent;
	}
	
	public boolean isElementPresent(String locator, Object ...arguments) {		
		locator = getElement(locator, arguments);
		return isElementPresent(locator);
	}

	@Override
	public boolean isPromptPresent() {
		report("isPromptPresent");
		return super.isPromptPresent();
	}

	@Override
	public boolean isSomethingSelected(String selectLocator) {
		selectLocator = getElement(selectLocator);
		report("isSomethingSelected (selectLocator=" + selectLocator + ")");
		return super.isSomethingSelected(selectLocator);
	}

	@Override
	public boolean isTextPresent(String pattern) {
		report("isTextPresent (pattern=" + pattern + ")");
		return super.isTextPresent(pattern);
	}

	@Override
	public boolean isVisible(String locator) {
		locator = getElement(locator);
		report("isVisible (locator=" + locator + ")");
		boolean isVisible = false;
		int i=0;
		while (i<retries){
			try{
				isVisible = super.isVisible(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		return isVisible;
	}
	
	public boolean isVisible(String locator, Object ...arguments) {
		locator = getElement(locator, arguments);
		return isVisible(locator);
	}

	@Override
	public void keyDown(String locator, String keycode) {
		locator = getElement(locator);
		report("keyDown (locator=" + locator + " keycode" + keycode + ")");
		super.keyDown(locator, keycode);
	}
	
	public void keyDown(String locator, String keycode, Object ...arguments) {
		locator = getElement(locator ,arguments);
		report("keyDown (locator=" + locator + " keycode" + keycode + ")");
		super.keyDown(locator, keycode);
	}

	@Override
	public void keyPress(String locator, String keycode) {
		locator = getElement(locator);
		report("keyPress (locator=" + locator + " keycode" + keycode + ")");
		super.keyPress(locator, keycode);
	}
	
	public void keyPress(String locator, String keycode, Object ...arguments) {
		locator = getElement(locator, arguments);
		report("keyPress (locator=" + locator + " keycode" + keycode + ")");
		super.keyPress(locator, keycode);
	}

	@Override
	public void keyUp(String locator, String keycode) {
		locator = getElement(locator);
		report("keyUp (locator=" + locator + " keycode" + keycode + ")");
		super.keyUp(locator, keycode);
	}
	
	public void keyUp(String locator, String keycode, Object ...arguments) {
		locator = getElement(locator, arguments);
		report("keyUp (locator=" + locator + " keycode" + keycode + ")");
		super.keyUp(locator, keycode);
	}

	@Override
	public void mouseDown(String locator) {
		locator = getElement(locator);
		report("mouseDown (locator=" + locator + ")");
		super.mouseDown(locator);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {}
	}
	
	public void mouseDown(String locator, Object ...arguments) {
		locator = getElement(locator, arguments);
		report("mouseDown (locator=" + locator + ")");
		super.mouseDown(locator);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {}
	}

	@Override
	public void mouseOver(String locator) {
		locator = getElement(locator);
		report("mouseOver (locator=" + locator + ")");
		super.mouseOver(locator);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {}
	}
	
	public void mouseOver(String locator, Object ...arguments) {
		locator = getElement(locator, arguments);
		report("mouseOver (locator=" + locator + ")");
		super.mouseOver(locator);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {}
	}

	@Override
	public void open(String url) {
		url = getElement(url);
		report("open (url=" + url + ")");
		super.open(url);
	}
	
	/**
	 * Opens a link based on a given url with arguments
	 * @param url
	 * @param arguments
	 */
	public void open(String url, Object... arguments) {
		url = getElement(url, arguments);
		report("open (url=" + url + ")");
		super.open(url);
	}

	@Override
	public void refresh() {
		report("refresh");
		super.refresh();
	}

	@Override
	public void removeSelection(String locator, String optionLocator) {
		locator = getElement(locator);
		report("removeSelection (locator" + locator + " optionLocator" + optionLocator + ")");
		super.removeSelection(locator, optionLocator);
	}
	
	public void removeSelection(String locator, String optionLocator, Object ...arguments) {
		locator = getElement(locator, arguments);
		report("removeSelection (locator" + locator + " optionLocator" + optionLocator + ")");
		super.removeSelection(locator, optionLocator);
	}

	@Override
	public void select(String selectLocator, String optionLocator) {
		selectLocator = getElement(selectLocator);
		report("select (selectLocator" + selectLocator + " optionLocator" + optionLocator + ")");
		int i=0;
		while (i<retries){
			try{
				super.select(selectLocator, optionLocator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
	}
	
	public void select(String selectLocator, String optionLocator, Object ...arguments) {
		selectLocator = getElement(selectLocator, arguments);
		select(selectLocator, optionLocator);
	}

	@Override
	public void selectWindow(String windowID) {
		report("selectWindow (windowID=" + windowID + ")");
		super.selectWindow(windowID);
	}

	@Override
	public void setCursorPosition(String locator, String position) {
		locator = getElement(locator);
		report("setCursorPosition (locator=" + locator + " position=" + position + ")");
		super.setCursorPosition(locator, position);
	}
	
	public void setCursorPosition(String locator, String position, Object ...arguments) {
		locator = getElement(locator, arguments);
		report("setCursorPosition (locator=" + locator + " position=" + position + ")");
		super.setCursorPosition(locator, position);
	}

	@Override
	public void setTimeout(String timeout) {
		report("setTimeout (timeout=" + timeout + ")");
		super.setTimeout(timeout);
		this.timeout = timeout;
	}

	@Override
	public void start() {
		report("start");
		super.start();
	}

	@Override
	public void stop() {
		report("stop");
		super.stop();
	}

	@Override
	public void submit(String formLocator) {
		formLocator = getElement(formLocator);
		report("submit (formLocator=" + formLocator + ")");
		super.submit(formLocator);
	}
	
	public void submit(String formLocator, Object ...arguments) {
		formLocator = getElement(formLocator, arguments);
		report("submit (formLocator=" + formLocator + ")");
		super.submit(formLocator);
	}

	@Override
	public void type(String locator, String value) {
		locator = getElement(locator);
		report("type (locator=" + locator + " value=" + value + ")");
		int i=0;
		while (i<retries){
			try{
				super.type(locator, value);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		
	}

	/**
	 * Type given value into HTML element identified by given locator
	 * @param locator
	 * 			HTML locator
	 * @param value
	 * 			Value to type
	 * @param arguments
	 * 			Formatting arguments for the locator
	 */
	public void type(String locator, String value, Object... arguments) {
		locator = getElement(locator, arguments);
		type(locator, value);
	}
	
	@Override
	public void uncheck(String locator) {
		locator = getElement(locator);
		report("uncheck (locator=" + locator + ")");
		int i=0;
		while (i<retries){
			try{
				super.uncheck(locator);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
	}
	
	public void uncheck(String locator, Object ...arguments) {
		locator = getElement(locator, arguments);
		uncheck(locator);
	}

	@Override
	public void waitForCondition(String script, String timeout) {
		report("waitForCondition (script=" + script + " timeout=" + timeout + ")");
		super.waitForCondition(script, timeout);
	}

	@Override
	public void waitForPageToLoad(String timeout) {
		report("waitForPageToLoad (timeout=" + timeout + ")");
		super.waitForPageToLoad(timeout);
	}

	@Override
	public void waitForPopUp(String windowID, String timeout) {
		report("waitForPopUp (windowID=" + windowID + " timeout=" + timeout + ")");
		super.waitForPopUp(windowID, timeout);
	}

	@Override
	public void runScript(String script) {
		try {
			runScript(script, 1000);
		} catch (Exception e) {
			reporter.report("Failed to run javascript: " + script, Reporter.FAIL);
		}
	}
	
	/**
	 * This function executes given script and block for a given timeout
	 * before continuing execution
	 * @param timeout
	 * 			The timeout in ms. to block after script execution
	 * @param script
	 * 			The javascript code to execute
	 */
	public void runScript(String script, long timeout, Object... arguments) throws Exception {
		script = getElement(script, arguments);
		report("Running javascript: " + script);
		int i=0;
		while (i<retries){
			try{
				super.runScript(script);
				break;
			}catch (Exception e) {
				i++;
				if (i==retries){
					reporter.report(e.getMessage(), Reporter.FAIL);
				}
			}
		}
		report("Blocking for " + timeout + " ms.");
		Thread.sleep(timeout);
	}
	
	@Override
	public void contextMenu(String locator) {
		locator = getElement(locator);
		report("context menu (locator=" + locator + ")");
		super.contextMenu(locator);
	}
	
	
	public void contextMenu(String locator, Object...arguments) {
		locator = getElement(locator, arguments);
		report("context menu (locator=" + locator + ")");
		super.contextMenu(locator);
	}
	
	/**
	 * Adds a report to a test
	 * @param report
	 */
	private void report(String report) {
		reporter.report(report);
	}	

	/**
	 * Setup a reporter for the selenium client
	 * @param reporter
	 */
	public static void createReporter(Reporter reporter) {
		SeleniumClient.reporter = reporter;
	}

	public BrowserType getBrowser() {
		return browser;
	}

	public void setBrowser(BrowserType browser) {
		this.browser = browser;
	}

	public boolean isAutoMapEnabled() {
		return autoMapEnabled;
	}

	public void setAutoMapEnabled(boolean autoMapEnabled) {
		this.autoMapEnabled = autoMapEnabled;
	}

	public String getAutoMapPrefix() {
		return autoMapPrefix;
	}

	public void setAutoMapPrefix(String autoMapPrefix) {
		this.autoMapPrefix = autoMapPrefix;
	}

	public int getRetries() {
		return retries;
	}

	public void setRetries(int retries) {
		this.retries = retries;
	}
		
}
