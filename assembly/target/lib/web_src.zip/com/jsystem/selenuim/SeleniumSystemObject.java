/**
 * Copyright 2008, JSystem Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsystem.selenuim;

import java.io.File;

import jsystem.framework.system.SystemObjectImpl;

import org.openqa.selenium.server.RemoteControlConfiguration;
import org.openqa.selenium.server.SeleniumServer;

/**
 * This class implements the selenium system object. This class is responsible
 * for communication between the client and the remote control of the selenium
 * platform.
 * 
 * @author Nizan Freedman
 * 
 */
public class SeleniumSystemObject extends SystemObjectImpl {

	private SeleniumServer server = null;
	private String serverIp = "localhost";
	private String domain = "";
	private String webBrowser = "*firefox";
	private int port = 4444;
	private String propFile = null;
	private String profileDir = null;
	private String extFile = null;
	private String autoMap = null;
	private boolean multiWindow = false;
	private boolean openServer = true;

	public void init() throws Exception {
		super.init();

		// Check if we need to start the server
		if (openServer) {
			// Check if we have user configuration
			RemoteControlConfiguration configuration = new RemoteControlConfiguration();

			// User javascript extensions
			if (extFile != null) {
				report.addLink("Setting user configuration file", extFile);
				configuration.setUserExtensions(new File(extFile));
			}

			// Custom Firefox profiles
			if (profileDir != null) {
				report.report("Setting Firefox custom profile directory: " + profileDir);
				configuration.setFirefoxProfileTemplate(new File(profileDir));
				if (!configuration.getFirefoxProfileTemplate().exists()) {
					throw new Exception("Firefox profile template doesn't exist: "
							+ configuration.getFirefoxProfileTemplate().getAbsolutePath());
				}
			}

			configuration.setSingleWindow(!multiWindow);
			configuration.setPort(port);

			// Create the server
			report.report("Creating Selenium server");
			server = new SeleniumServer(false, configuration);
		}
	}

	/**
	 * Starts selenium server
	 * 
	 * @throws Exception
	 */
	public void startSelenuimServer() throws Exception {
		if (openServer) {
			report.report("Starting Selenium server");
			server.start();
		}
	}

	/**
	 * Stops selenium server
	 * 
	 * @throws Exception
	 */
	public void stopSelenuimServer() throws Exception {
		if (openServer) {
			server.stop();
		}
	}

	/**
	 * Creates selenium client
	 * 
	 * @param serverIp
	 *            The RC server ip
	 * @param port
	 *            The RC server port
	 * @param browserString
	 *            The type of the browser to use
	 * @param domain
	 *            The root domain
	 * @return SeleniumClient
	 * @throws Exception
	 */
	public SeleniumClient getBrowserInstance(String serverIp, int port, String browserString, String domain)
			throws Exception {
		report.report("Starting selenium client");
		SeleniumClient s = new SeleniumClient(serverIp, port, browserString, domain);
		SeleniumClient.createReporter(report);
		s.start();
		setAutoMapping(s);
		return s;
	}

	/**
	 * Creates selenium client using SUT parameters
	 * 
	 * @return SeleniumClient
	 * @throws Exception
	 */
	public SeleniumClient getBrowserInstance() throws Exception {
		return getBrowserInstance(serverIp, port, webBrowser, domain);
	}

	/**
	 * Creates selenium client using most SUT parameters
	 * 
	 * @param browserString
	 *            The type of the browser to open
	 * @return
	 * @throws Exception
	 */
	public SeleniumClient getBrowserInstance(String browserString) throws Exception {
		return getBrowserInstance(serverIp, port, browserString, domain);
	}

	/**
	 * Sets the status of the links auto mapping
	 */
	private void setAutoMapping(SeleniumClient s) {
		if (autoMap != null) {
			s.setAutoMapEnabled(true);
			s.setAutoMapPrefix(autoMap);
		} else {
			s.setAutoMapEnabled(false);
		}
	}

	/**
	 * Closes given selenium client driver instance
	 * 
	 * @param s
	 *            SeleniumClienbt
	 * @throws Exception
	 */
	public void closeBrowserInstance(SeleniumClient s) throws Exception {
		report.report("Stoping selenium client");
		if (s != null) {
			s.stop();
		}
	}

	/**
	 * Setters/Getters
	 */

	public String getDomain() {
		return domain;
	}

	/**
	 * Sets the startup domain for the browser.
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getWebBrowser() {
		return webBrowser;
	}

	/**
	 * Sets the type of the browser
	 */
	public void setWebBrowser(String webBrowser) {
		this.webBrowser = webBrowser;
	}

	public String getPropFile() {
		return propFile;
	}

	/**
	 * Sets properties file. This file should contain the links mapping the
	 * following format: property=XPath/Html/Javascript
	 */
	public void setPropFile(String propFile) {
		this.propFile = propFile;
	}

	public String getExtFile() {
		return extFile;
	}

	/**
	 * Sets the external javascript extensions file. This file will be used by
	 * the Selenium server.
	 */
	public void setExtFile(String extFile) {
		this.extFile = extFile;
	}

	/**
	 * Returns the internal Selenium server. This method should be used only for
	 * testing.
	 * 
	 * @return SeleniumServer
	 */
	public SeleniumServer getServer() {
		return server;
	}

	public int getPort() {
		return port;
	}

	/**
	 * Set the Selenium server port
	 */
	public void setPort(int port) {
		this.port = port;
	}

	public String getProfileDir() {
		return profileDir;
	}

	/**
	 * Sets the profile directory for the Firefox. This feature is applicable
	 * only for Firefox.
	 */
	public void setProfileDir(String profileDir) {
		this.profileDir = profileDir;
	}

	public String getAutoMap() {
		return autoMap;
	}

	/**
	 * Sets the link auto map mode. This mode allows using not links but
	 * directly properties. For example: jsystem.documents.tutorial. In this
	 * case the <code>autoMap</code> should be <b>jsystem</b>
	 */
	public void setAutoMap(String autoMap) {
		this.autoMap = autoMap;
	}

	public String getServerIp() {
		return serverIp;
	}

	/**
	 * Sets the RC server ip address
	 */
	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}

	public boolean isMultiWindow() {
		return multiWindow;
	}

	/**
	 * Sets the multiwindow status
	 * 
	 * @param multiWindow
	 */
	public void setMultiWindow(boolean multiWindow) {
		this.multiWindow = multiWindow;
	}

	public boolean isOpenServer() {
		return openServer;
	}

	/**
	 * If set to true, will open the RC server
	 * 
	 * @param openServer
	 */
	public void setOpenServer(boolean openServer) {
		this.openServer = openServer;
	}
}
