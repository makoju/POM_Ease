/**
 * Copyright 2008, JSystem Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsystem.selenuim;

import java.util.regex.Pattern;

import junit.framework.Assert;
import junit.framework.AssertionFailedError;
import junit.framework.SystemTestCase;

/**
 * This class implements a selenium system test case.
 * The class is based on SystemTestCase (JUnit 3).
 * This class will allow using selenium recorded tests without any change.
 * 
 * @author Michael Oziransky
 */
public class SeleniumSystemTestCase extends SystemTestCase {
	
	protected SeleniumSystemObject sysObj;
    protected SeleniumClient selenium;  
    
    /**
     * Defaults constructor that associates a fixture with
     * each selenium system test case
     */
    public SeleniumSystemTestCase() {
    	report.report("Constructing SeleniumSystemTestCase");
    }
    
    /**
     * Creates a new DefaultSelenium object and starts it using browser string
     * @param browserString the browser to use, e.g. *firefox
     * @throws Exception
     */    
    public void setUp(String browserString) throws Exception {
    	setUp(null, browserString);
    }
    
    /**
     * Creates a new DefaultSelenium object and starts it using the specified baseUrl and browser string
     * @param url the baseUrl for your tests
     * @param browserString the browser to use, e.g. *firefox
     * @throws Exception
     */
    public void setUp(String url, String browserString) throws Exception {        
        // Get the selenium object and see if we have a URL to set
        sysObj = (SeleniumSystemObject)system.getSystemObject("selenium");
        if (url != null) {
        	sysObj.setDomain(url);
        }
        sysObj.startSelenuimServer();
        
        // Start the client    
        selenium = sysObj.getBrowserInstance(browserString);        
    }

    public void tearDown() throws Exception {		
    	sysObj.closeBrowserInstance(selenium);
    }
    
    /** Like assertTrue, but fails at the end of the test (during tearDown) 
     * @throws Exception */
    public void verifyTrue(boolean b) throws Exception {
    	report.report("varifyTrue, given: " + b);
    	Assert.assertTrue(b);
    }
    
    /** Like assertFalse, but fails at the end of the test (during tearDown) 
     * @throws Exception */
    public void verifyFalse(boolean b) throws Exception {
    	report.report("varifyFalse, given: " + b);
    	Assert.assertFalse(b);
    }
    
    /** Returns the body text of the current page */
    public String getText() {
        return selenium.getEval("this.page().bodyText()");
    }

    /** Like assertEquals, but fails at the end of the test (during tearDown) */
    public void verifyEquals(Object s1, Object s2) throws Exception {
        assertEquals(s1, s2);
    }
    
    /** Like assertEquals, but fails at the end of the test (during tearDown) */
    public void verifyEquals(boolean s1, boolean s2) throws Exception {
        assertEquals(new Boolean(s1), new Boolean(s2));
    }

    /** Like JUnit's Assert.assertEquals, but knows how to compare string arrays */
    public static void assertEquals(Object s1, Object s2) {
        if (s1 instanceof String && s2 instanceof String) {
            assertEquals((String)s1, (String)s2);
        } else if (s1 instanceof String && s2 instanceof String[]) {
            assertEquals((String)s1, (String[])s2);
        } else if (s1 instanceof String && s2 instanceof Number) {
            assertEquals((String)s1, ((Number)s2).toString());
        }
        else {
            if (s1 instanceof String[] && s2 instanceof String[]) {
                
                String[] sa1 = (String[]) s1;
                String[] sa2 = (String[]) s2;
                if (sa1.length!=sa2.length) {
                    throw new AssertionFailedError("Expected " + sa1 + " but saw " + sa2);
                }
                for (int j = 0; j < sa1.length; j++) {
                    Assert.assertEquals(sa1[j], sa2[j]);
                }
            }
        }
    }
    
    /** Like JUnit's Assert.assertEquals, but handles "regexp:" strings like HTML Selenese */ 
    public static void assertEquals(String s1, String s2) {
		Assert.assertTrue("Expected \"" + s1 + "\" but saw \"" + s2 + "\" instead", seleniumEquals(s1, s2));
    }
    
    /** Like JUnit's Assert.assertEquals, but joins the string array with commas, and 
     * handles "regexp:" strings like HTML Selenese
     * @throws Exception 
     */
    public static void assertEquals(String s1, String[] s2) {
    	assertEquals(s1, stringArrayToSimpleString(s2));
    }
    
    /** Compares two strings, but handles "regexp:" strings like HTML Selenese
     * 
     * @param expectedPattern
     * @param actual
     * @return true if actual matches the expectedPattern, or false otherwise
     */
    public static boolean seleniumEquals(String expectedPattern, String actual) {
        if (actual.startsWith("regexp:") || actual.startsWith("regex:")) {
            // swap 'em
        	String tmp = actual;
            actual = expectedPattern;
            expectedPattern = tmp;
        }
        if (expectedPattern.startsWith("regexp:")) {
            String expectedRegEx = expectedPattern.replaceFirst("regexp:", ".*") + ".*";
            if (!actual.matches(expectedRegEx)) {
                System.out.println("expected " + actual + " to match regexp " + expectedPattern);
                return false;                    
            }
            return true;
        }
        if (expectedPattern.startsWith("regex:")) {
            String expectedRegEx = expectedPattern.replaceFirst("regex:", ".*") + ".*";
            if (!actual.matches(expectedRegEx)) {
                System.out.println("expected " + actual + " to match regex " + expectedPattern);
                return false;
            }
            return true;
        }
        
        if (expectedPattern.startsWith("exact:")) {
            String expectedExact = expectedPattern.replaceFirst("exact:", "");
            if (!expectedExact.equals(actual)) {
                System.out.println("expected " + actual + " to match " + expectedPattern);
                return false;
            }
            return true;
        }
        
        String expectedGlob = expectedPattern.replaceFirst("glob:", "");
        expectedGlob = expectedGlob.replaceAll("([\\]\\[\\\\{\\}$\\(\\)\\|\\^\\+.])", "\\\\$1");

        expectedGlob = expectedGlob.replaceAll("\\*", ".*");
        expectedGlob = expectedGlob.replaceAll("\\?", ".");
        if (!Pattern.compile(expectedGlob, Pattern.DOTALL).matcher(actual).matches()) {
            System.out.println("expected \"" + actual + "\" to match glob \"" + expectedPattern + "\" (had transformed the glob into regexp \"" + expectedGlob + "\"");
            return false;
        }
        return true;
    }
    
    /** Compares two objects, but handles "regexp:" strings like HTML Selenese
     * @see #seleniumEquals(String, String)
     * @return true if actual matches the expectedPattern, or false otherwise
     */
    public static boolean seleniumEquals(Object expected, Object actual) {
        if (expected instanceof String && actual instanceof String) {
            return seleniumEquals((String)expected, (String)actual);
        }
        return expected.equals(actual);
    }
    
    /** Asserts that two string arrays have identical string contents */
    public static void assertEquals(String[] s1, String[] s2) {
        String comparisonDumpIfNotEqual = verifyEqualsAndReturnComparisonDumpIfNot(s1, s2);
        if (comparisonDumpIfNotEqual!=null) {
            throw new AssertionFailedError(comparisonDumpIfNotEqual);
        }
    }
    
    /** Asserts that two string arrays have identical string contents (fails at the end of the test, during tearDown) 
     * @throws Exception */
    public void verifyEquals(String[] s1, String[] s2) throws Exception {
        String comparisonDumpIfNotEqual = verifyEqualsAndReturnComparisonDumpIfNot(s1, s2);
        if (comparisonDumpIfNotEqual != null) {
            throw new Exception("Strings not equal");
        }
    }
    
    private static String verifyEqualsAndReturnComparisonDumpIfNot(String[] s1, String[] s2) {
        boolean misMatch = false;
        if (s1.length != s2.length) {
            misMatch = true;
        }
        for (int j = 0; j < s1.length; j++) {
            if (!seleniumEquals(s1[j], s2[j])) {
                misMatch = true;
                break;
            }
        }
        if (misMatch) {
            return "Expected " + stringArrayToString(s1) + " but saw " + stringArrayToString(s2);
        }
        return null;
    }
    
    private static String stringArrayToString(String[] sa) {
        StringBuffer sb = new StringBuffer("{");
        for (int j = 0; j < sa.length; j++) {
            sb.append(" ")
            .append("\"")
            .append(sa[j])
            .append("\"");            
        }
        sb.append(" }");
        return sb.toString();
    }
    
    private static String stringArrayToSimpleString(String[] sa) {
        StringBuffer sb = new StringBuffer();
        for (int j = 0; j < sa.length; j++) {
            sb.append(sa[j]);
            if (j < sa.length -1) {
            	sb.append(',');
            }          
        }
        return sb.toString();
    }

    /** Like assertNotEquals, but fails at the end of the test (during tearDown) */
    public void verifyNotEquals(Object s1, Object s2) throws Exception {
        assertNotEquals(s1, s2);
    }
    
    /** Like assertNotEquals, but fails at the end of the test (during tearDown) */
    public void verifyNotEquals(boolean s1, boolean s2) throws Exception {
        assertNotEquals(new Boolean(s1), new Boolean(s2));
    }
    
    /** Asserts that two objects are not the same (compares using .equals()) */
    public static void assertNotEquals(Object obj1, Object obj2) throws Exception {
        if (obj1.equals(obj2)) {
            throw new Exception("did not expect values to be equal (" + obj1.toString() + ")");
        }
    }
    
    /** Asserts that two booleans are not the same */
    public static void assertNotEquals(boolean b1, boolean b2) throws Exception {
        assertNotEquals(new Boolean(b1), new Boolean(b2));
    }
}
