/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package com.aqua.sysobj.wGet;

import jsystem.framework.system.SystemObjectImpl;

public class WGetManager extends SystemObjectImpl {
	public WGet[] wGets;
}
