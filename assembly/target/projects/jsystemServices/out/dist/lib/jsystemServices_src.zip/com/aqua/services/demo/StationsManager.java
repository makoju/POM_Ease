/*
 * Copyright 2005-2010 Ignis Software Tools Ltd. All rights reserved.
 */
package com.aqua.services.demo;

import jsystem.framework.system.SystemObjectImpl;

public class StationsManager extends SystemObjectImpl {
	public WindowsStation[] stations;
}
